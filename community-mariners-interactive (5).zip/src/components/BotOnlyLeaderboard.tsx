import React, { useState, useEffect } from 'react';
import { Card, Badge } from '@/components/MinimalComponents';
import { Trophy, TrendingUp, Target, Calendar } from 'lucide-react';

const BotOnlyLeaderboard = () => {
  const [botStats, setBotStats] = useState([
    {
      name: 'Marty',
      avatar: '🤖',
      totalPoints: 2150,
      weeklyPoints: 180,
      accuracy: '76%',
      streak: 5,
      predictions: 89,
      rank: 1,
      trend: 'up'
    },
    {
      name: 'Captain',
      avatar: '⚓',
      totalPoints: 1980,
      weeklyPoints: 165,
      accuracy: '73%',
      streak: 3,
      predictions: 87,
      rank: 2,
      trend: 'up'
    },
    {
      name: 'Spartan',
      avatar: '🛡️',
      totalPoints: 1850,
      weeklyPoints: 155,
      accuracy: '71%',
      streak: 2,
      predictions: 85,
      rank: 3,
      trend: 'down'
    }
  ]);

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'text-yellow-500';
      case 2: return 'text-gray-400';
      case 3: return 'text-amber-600';
      default: return 'text-gray-600';
    }
  };

  const getTrendIcon = (trend: string) => {
    return trend === 'up' ? '📈' : '📉';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Trophy className="h-6 w-6 text-yellow-500" />
        <h2 className="text-2xl font-bold">AI Bot Leaderboard</h2>
        <Badge variant="outline">Exclusive Bot Competition</Badge>
      </div>

      <div className="grid gap-4">
        {botStats.map((bot, index) => (
          <Card key={bot.name} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className={`text-2xl font-bold ${getRankColor(bot.rank)}`}>
                    #{bot.rank}
                  </span>
                  <span className="text-3xl">{bot.avatar}</span>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold">{bot.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Target className="h-4 w-4" />
                      {bot.accuracy}
                    </span>
                    <span>Streak: {bot.streak}</span>
                    <span>{bot.predictions} predictions</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl font-bold">{bot.totalPoints.toLocaleString()}</span>
                  <span className="text-lg">{getTrendIcon(bot.trend)}</span>
                </div>
                <Badge variant="secondary">
                  +{bot.weeklyPoints} this week
                </Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Weekly Competition Stats
        </h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-blue-600">12</div>
            <div className="text-sm text-gray-600">Games Predicted</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-600">8</div>
            <div className="text-sm text-gray-600">Correct Predictions</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-purple-600">67%</div>
            <div className="text-sm text-gray-600">Average Accuracy</div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default BotOnlyLeaderboard;