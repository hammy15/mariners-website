# TridentFans Vercel Project Setup Guide

## Step 1: Create New Vercel Project

### Option A: Deploy from GitHub (Recommended)
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click "New Project"
3. Import your GitHub repository containing TridentFans code
4. Configure project settings:
   - **Project Name**: `tridentfans`
   - **Framework Preset**: Vite
   - **Root Directory**: `./` (leave default)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`

### Option B: Deploy from Local Files
1. Install Vercel CLI: `npm i -g vercel`
2. In your project directory, run: `vercel`
3. Follow prompts:
   - Set up and deploy? **Y**
   - Which scope? Select your account
   - Link to existing project? **N**
   - Project name: `tridentfans`
   - In which directory is your code? `./`
   - Want to modify settings? **N**

## Step 2: Environment Variables
Add these in Vercel Dashboard → Project → Settings → Environment Variables:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Step 3: Verify Deployment
- Check build logs for errors
- Test the generated `.vercel.app` URL
- Ensure all pages load correctly

## Next Steps
Once project is created, follow VERCEL_DOMAIN_SETUP.md for custom domain configuration.