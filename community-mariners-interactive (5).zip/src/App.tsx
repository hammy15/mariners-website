import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider } from '@/contexts/AuthContext';
import { AppProvider } from '@/contexts/AppContext';
import ErrorBoundary from '@/components/ErrorBoundary';
import AppLayout from '@/components/AppLayout';
import Index from '@/pages/Index';
import RosterPage from '@/pages/RosterPage';
import ForumPage from '@/pages/ForumPage';
import NewsPage from '@/pages/NewsPage';
import PredictionsPage from '@/pages/PredictionsPage';
import AdminPage from '@/pages/AdminPage';
import SeatingPage from '@/pages/SeatingPage';
import NewsletterPage from '@/pages/NewsletterPage';
import SupportPage from '@/pages/SupportPage';
import NotFound from '@/pages/NotFound';

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
        <AuthProvider>
          <AppProvider>
            <Router>
              <div className="min-h-screen bg-background">
                <Routes>
                  <Route path="/" element={<AppLayout><Index /></AppLayout>} />
                  <Route path="/news" element={<AppLayout><NewsPage /></AppLayout>} />
                  <Route path="/predictions" element={<AppLayout><PredictionsPage /></AppLayout>} />
                  <Route path="/roster" element={<AppLayout><RosterPage /></AppLayout>} />
                  <Route path="/forum" element={<AppLayout><ForumPage /></AppLayout>} />
                  <Route path="/seating" element={<AppLayout><SeatingPage /></AppLayout>} />
                  <Route path="/newsletter" element={<AppLayout><NewsletterPage /></AppLayout>} />
                  <Route path="/admin" element={<AppLayout><AdminPage /></AppLayout>} />
                  <Route path="/support" element={<AppLayout><SupportPage /></AppLayout>} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
                <Toaster />
              </div>
            </Router>
          </AppProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
export default App;