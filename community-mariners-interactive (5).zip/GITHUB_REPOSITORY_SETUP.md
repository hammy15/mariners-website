# GitHub Repository Setup for TridentFans

## The Problem
Vercel error: "The provided GitHub repository does not contain the requested branch or commit reference. Please ensure the repository is not empty."

This means your GitHub repository is empty and needs the codebase pushed to it.

## Solution: Initialize and Push Your Code

### Step 1: Initialize Git Repository Locally
```bash
# Navigate to your project directory
cd tridentfans

# Initialize git (if not already done)
git init

# Add all files
git add .

# Make your first commit
git commit -m "Initial commit - TridentFans React app"
```

### Step 2: Connect to GitHub Repository
```bash
# Add your GitHub repository as remote origin
git remote add origin https://github.com/YOUR_USERNAME/tridentfans.git

# Verify the remote was added
git remote -v
```

### Step 3: Push Code to GitHub
```bash
# Push to main branch (creates the branch)
git push -u origin main
```

If you get an error about `main` branch not existing:
```bash
# Create and switch to main branch
git branch -M main
git push -u origin main
```

### Step 4: Verify on GitHub
1. Go to your GitHub repository
2. Refresh the page
3. You should now see all your files
4. The repository should show "main" branch with your commit

### Step 5: Try Vercel Import Again
1. Go back to Vercel dashboard
2. Click "Import Project"
3. Select your GitHub repository
4. It should now work since the repository has content

## Alternative: Create Repository with Code
If you haven't created the GitHub repository yet:

1. Go to GitHub.com
2. Click "New repository"
3. Name it "tridentfans"
4. **DO NOT** initialize with README, .gitignore, or license
5. Click "Create repository"
6. Follow the "push an existing repository" commands shown

## Troubleshooting

### If you get authentication errors:
```bash
# Use GitHub CLI (recommended)
gh auth login

# Or use personal access token
# Generate at: https://github.com/settings/tokens
```

### If main branch doesn't exist:
```bash
git checkout -b main
git push -u origin main
```

### If you have existing commits on different branch:
```bash
git branch -M master main
git push -u origin main
```

## Next Steps
Once your code is pushed to GitHub:
1. Return to Vercel
2. Import the repository
3. Deploy your app
4. Configure custom domain (see VERCEL_DOMAIN_SETUP.md)