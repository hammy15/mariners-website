import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MartyIcon } from './MartyIcon';
import { MessageCircle, X, Compass, Sword, Bot } from 'lucide-react';
import { aiLearningSystem } from '@/lib/aiLearning';

const MartyBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const bots = [
    { name: 'Marty BoomStick', icon: Bot, color: 'blue' },
    { name: 'Wes Tillwaiting', icon: Compass, color: 'green' },
    { name: 'Don Tlose', icon: Sword, color: 'red' }
  ];

  const handleBotClick = (botName: string) => {
    const starters = aiLearningSystem.getConversationStarters(botName);
    console.log(`${botName} says: ${starters[0] || 'Hello there!'}`);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end space-y-3">
      {isOpen && (
        <Card className="w-80 h-96 mb-4 p-4 shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold">TridentFans AI Team</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-3">
            {bots.map((bot, index) => (
              <div key={index} className={`p-3 border-l-4 border-l-${bot.color}-500 bg-gray-50 rounded-lg`}>
                <div className="flex items-center space-x-2 mb-2">
                  {React.createElement(bot.icon, { className: `w-4 h-4 text-${bot.color}-600` })}
                  <span className="font-medium text-sm">{bot.name}</span>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleBotClick(bot.name)}
                  className="text-xs"
                >
                  Start Chat
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
      
      {/* Individual bot buttons aligned to the right */}
      {bots.map((bot, index) => (
        <Button
          key={index}
          onClick={() => handleBotClick(bot.name)}
          className={`rounded-full w-12 h-12 bg-${bot.color}-600 hover:bg-${bot.color}-700 shadow-lg`}
          title={`Chat with ${bot.name}`}
        >
          {React.createElement(bot.icon, { className: "h-6 w-6" })}
        </Button>
      ))}
      
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-full w-14 h-14 bg-purple-600 hover:bg-purple-700 shadow-lg"
        title="Open AI Team Panel"
      >
        <MessageCircle className="h-7 w-7" />
      </Button>
    </div>
  );
};

export default MartyBot;