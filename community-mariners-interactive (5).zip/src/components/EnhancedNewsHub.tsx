import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const EnhancedNewsHub = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  const categories = [
    { id: 'all', name: 'All News', icon: '📰' },
    { id: 'mariners', name: 'Mariners', icon: '⚾' },
    { id: 'trades', name: 'Trades', icon: '🔄' },
    { id: 'injuries', name: 'Injuries', icon: '🏥' },
    { id: 'prospects', name: 'Prospects', icon: '🌟' },
    { id: 'analysis', name: 'Analysis', icon: '📊' }
  ];

  useEffect(() => {
    fetchNews();
  }, [activeCategory]);

  const fetchNews = async () => {
    setLoading(true);
    try {
      // Mock news data - in real app would fetch from MLB news API
      const mockNews = [
        {
          id: 1,
          title: "Mariners Sign New Pitcher to Multi-Year Deal",
          summary: "Seattle bolsters rotation with veteran right-hander...",
          category: "mariners",
          source: "MLB.com",
          publishedAt: "2024-01-20T10:30:00Z",
          imageUrl: "/placeholder.svg",
          readTime: "3 min read"
        },
        {
          id: 2,
          title: "Top Prospect Promoted to Triple-A",
          summary: "Rising star moves one step closer to the majors...",
          category: "prospects",
          source: "ESPN",
          publishedAt: "2024-01-20T08:15:00Z",
          imageUrl: "/placeholder.svg",
          readTime: "2 min read"
        },
        {
          id: 3,
          title: "Trade Deadline Analysis: What's Next for Seattle",
          summary: "Breaking down potential moves and team needs...",
          category: "analysis",
          source: "The Athletic",
          publishedAt: "2024-01-19T16:45:00Z",
          imageUrl: "/placeholder.svg",
          readTime: "5 min read"
        },
        {
          id: 4,
          title: "Injury Update: Star Player Expected Back Soon",
          summary: "Latest on recovery timeline and impact on lineup...",
          category: "injuries",
          source: "Seattle Times",
          publishedAt: "2024-01-19T14:20:00Z",
          imageUrl: "/placeholder.svg",
          readTime: "4 min read"
        }
      ];

      const filteredNews = activeCategory === 'all' 
        ? mockNews 
        : mockNews.filter(article => article.category === activeCategory);
      
      setNews(filteredNews);
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Mariners News Hub</h2>
        <Badge variant="secondary">Live Updates</Badge>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map(category => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? 'default' : 'outline'}
            onClick={() => setActiveCategory(category.id)}
            className="text-sm"
          >
            {category.icon} {category.name}
          </Button>
        ))}
      </div>

      {/* News Articles */}
      {loading ? (
        <div className="text-center py-8">Loading news...</div>
      ) : (
        <div className="grid gap-6">
          {news.map((article: any) => (
            <Card key={article.id} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex gap-4">
                <img 
                  src={article.imageUrl} 
                  alt={article.title}
                  className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-semibold line-clamp-2">
                      {article.title}
                    </h3>
                    <Badge variant="outline" className="ml-2 flex-shrink-0">
                      {categories.find(c => c.id === article.category)?.icon}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
                    {article.summary}
                  </p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center gap-4">
                      <span>{article.source}</span>
                      <span>{formatDate(article.publishedAt)}</span>
                      <span>{article.readTime}</span>
                    </div>
                    <Button variant="outline" size="sm">
                      Read More
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {news.length === 0 && !loading && (
        <Card className="p-8 text-center">
          <p className="text-gray-500">No news articles found for this category.</p>
        </Card>
      )}

      {/* News Sources */}
      <Card className="p-6 bg-gray-50 dark:bg-gray-800/50">
        <h3 className="text-lg font-semibold mb-3">News Sources</h3>
        <div className="flex flex-wrap gap-2">
          {['MLB.com', 'ESPN', 'The Athletic', 'Seattle Times', 'Lookout Landing'].map(source => (
            <Badge key={source} variant="secondary">{source}</Badge>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default EnhancedNewsHub;