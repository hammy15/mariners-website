import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Target, TrendingUp, Calendar, Bot, Compass, Sword } from 'lucide-react';

interface BotPrediction {
  botName: string;
  icon: React.ComponentType<any>;
  prediction: 'win' | 'loss';
  confidence: number;
  reasoning: string;
  color: string;
}

interface GamePrediction {
  gameId: string;
  opponent: string;
  gameDate: Date;
  botPredictions: BotPrediction[];
  actualResult?: 'win' | 'loss';
}

interface BotStats {
  botName: string;
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number;
  streak: number;
  icon: React.ComponentType<any>;
  color: string;
}

const PredictionsHub: React.FC = () => {
  const [predictions, setPredictions] = useState<GamePrediction[]>([]);
  const [botStats, setBotStats] = useState<BotStats[]>([
    { botName: 'Marty BoomStick', totalPredictions: 45, correctPredictions: 28, accuracy: 62.2, streak: 3, icon: Bot, color: 'blue' },
    { botName: 'Wes Tillwaiting', totalPredictions: 45, correctPredictions: 31, accuracy: 68.9, streak: 5, icon: Compass, color: 'green' },
    { botName: 'Don Tlose', totalPredictions: 45, correctPredictions: 26, accuracy: 57.8, streak: -2, icon: Sword, color: 'red' }
  ]);

  const generateBotPredictions = (opponent: string): BotPrediction[] => {
    return [
      {
        botName: 'Marty BoomStick',
        icon: Bot,
        prediction: Math.random() > 0.4 ? 'win' : 'loss',
        confidence: Math.floor(Math.random() * 30) + 70,
        reasoning: 'BOOM! Our power hitting lineup is gonna explode against their pitching!',
        color: 'blue'
      },
      {
        botName: 'Wes Tillwaiting',
        icon: Compass,
        prediction: Math.random() > 0.3 ? 'win' : 'loss',
        confidence: Math.floor(Math.random() * 25) + 75,
        reasoning: 'Well, the analytics show we match up mighty fine against their rotation.',
        color: 'green'
      },
      {
        botName: 'Don Tlose',
        icon: Sword,
        prediction: Math.random() > 0.5 ? 'win' : 'loss',
        confidence: Math.floor(Math.random() * 40) + 60,
        reasoning: 'Ay! We never back down from a fight - victory will be ours!',
        color: 'red'
      }
    ];
  };

  useEffect(() => {
    // Generate upcoming games with bot predictions
    const upcomingGames: GamePrediction[] = [
      {
        gameId: '1',
        opponent: 'Houston Astros',
        gameDate: new Date(Date.now() + 86400000),
        botPredictions: generateBotPredictions('Houston Astros')
      },
      {
        gameId: '2',
        opponent: 'Texas Rangers',
        gameDate: new Date(Date.now() + 2 * 86400000),
        botPredictions: generateBotPredictions('Texas Rangers')
      },
      {
        gameId: '3',
        opponent: 'Los Angeles Angels',
        gameDate: new Date(Date.now() + 3 * 86400000),
        botPredictions: generateBotPredictions('Los Angeles Angels')
      }
    ];
    setPredictions(upcomingGames);
  }, []);

  const PredictionCard = ({ game }: { game: GamePrediction }) => (
    <Card className="mb-4">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg">vs {game.opponent}</CardTitle>
          <Badge variant="outline">
            <Calendar className="w-4 h-4 mr-1" />
            {game.gameDate.toLocaleDateString()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {game.botPredictions.map((pred, index) => (
            <div key={index} className={`p-3 border-l-4 border-l-${pred.color}-500 bg-gray-50 rounded-lg`}>
              <div className="flex items-center space-x-2 mb-2">
                {React.createElement(pred.icon, { className: `w-5 h-5 text-${pred.color}-600` })}
                <span className="font-medium text-sm">{pred.botName}</span>
              </div>
              <div className="flex items-center space-x-2 mb-2">
                <Badge variant={pred.prediction === 'win' ? 'default' : 'destructive'}>
                  {pred.prediction.toUpperCase()}
                </Badge>
                <span className="text-sm text-gray-600">{pred.confidence}% confident</span>
              </div>
              <p className="text-xs text-gray-700">{pred.reasoning}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const BotStatsCard = ({ bot }: { bot: BotStats }) => (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center space-x-3 mb-3">
          {React.createElement(bot.icon, { className: `w-6 h-6 text-${bot.color}-600` })}
          <h3 className="font-semibold">{bot.botName}</h3>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Accuracy</span>
            <span className="font-medium">{bot.accuracy}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Predictions</span>
            <span className="font-medium">{bot.correctPredictions}/{bot.totalPredictions}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-600">Current Streak</span>
            <Badge variant={bot.streak > 0 ? 'default' : 'destructive'}>
              {bot.streak > 0 ? `+${bot.streak}` : bot.streak}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">TridentFans Predictions Hub</h1>
        <p className="text-gray-600">Our AI bots make their picks before every game!</p>
      </div>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming">Upcoming Games</TabsTrigger>
          <TabsTrigger value="leaderboard">Bot Leaderboard</TabsTrigger>
          <TabsTrigger value="history">Prediction History</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="mt-6">
          <div className="space-y-4">
            {predictions.map((game) => (
              <PredictionCard key={game.gameId} game={game} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {botStats
              .sort((a, b) => b.accuracy - a.accuracy)
              .map((bot, index) => (
                <div key={bot.botName} className="relative">
                  {index === 0 && (
                    <Trophy className="absolute -top-2 -right-2 w-6 h-6 text-yellow-500" />
                  )}
                  <BotStatsCard bot={bot} />
                </div>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Prediction Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Prediction history will appear here as games are completed.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PredictionsHub;