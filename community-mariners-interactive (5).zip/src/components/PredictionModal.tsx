import React, { useState } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

interface PredictionModalProps {
  isOpen: boolean;
  onClose: () => void;
  game: {
    id: number;
    opponent: string;
    date: string;
    time: string;
    location: string;
  } | null;
  onPredictionMade: () => void;
}

const PredictionModal: React.FC<PredictionModalProps> = ({ 
  isOpen, 
  onClose, 
  game, 
  onPredictionMade 
}) => {
  const [prediction, setPrediction] = useState<'win' | 'loss' | null>(null);
  const [marinersScore, setMarinersScore] = useState('');
  const [opponentScore, setOpponentScore] = useState('');
  const [confidence, setConfidence] = useState(50);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prediction || !game) return;

    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('game_predictions')
        .insert({
          game_id: game.id,
          user_id: 'anonymous', // TODO: Get from auth context
          prediction_type: prediction,
          mariners_score: marinersScore ? parseInt(marinersScore) : null,
          opponent_score: opponentScore ? parseInt(opponentScore) : null,
          confidence_level: confidence,
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      resetForm();
      onPredictionMade();
      onClose();
    } catch (error) {
      console.error('Error saving prediction:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setPrediction(null);
    setMarinersScore('');
    setOpponentScore('');
    setConfidence(50);
  };

  if (!isOpen || !game) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Make Prediction</h2>
          <Button variant="ghost" onClick={onClose}>×</Button>
        </div>

        <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded">
          <h3 className="font-medium">Mariners vs {game.opponent}</h3>
          <p className="text-sm text-gray-600">{game.date} at {game.time}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Prediction</label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={prediction === 'win' ? 'default' : 'outline'}
                onClick={() => setPrediction('win')}
                className="flex-1"
              >
                Mariners Win
              </Button>
              <Button
                type="button"
                variant={prediction === 'loss' ? 'default' : 'outline'}
                onClick={() => setPrediction('loss')}
                className="flex-1"
              >
                Mariners Lose
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-sm font-medium mb-1">Mariners Score</label>
              <input
                type="number"
                value={marinersScore}
                onChange={(e) => setMarinersScore(e.target.value)}
                placeholder="0"
                min="0"
                max="20"
                className="w-full p-2 border rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">{game.opponent} Score</label>
              <input
                type="number"
                value={opponentScore}
                onChange={(e) => setOpponentScore(e.target.value)}
                placeholder="0"
                min="0"
                max="20"
                className="w-full p-2 border rounded-md"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Confidence: {confidence}%
            </label>
            <input
              type="range"
              min="1"
              max="100"
              value={confidence}
              onChange={(e) => setConfidence(parseInt(e.target.value))}
              className="w-full"
            />
          </div>

          <div className="flex gap-2">
            <Button type="submit" disabled={!prediction || isSubmitting} className="flex-1">
              {isSubmitting ? 'Submitting...' : 'Submit Prediction'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default PredictionModal;