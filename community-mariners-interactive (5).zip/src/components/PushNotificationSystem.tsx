import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Bell, BellOff, MessageSquare, TrendingUp, Users, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface NotificationSettings {
  chatMessages: boolean;
  gameUpdates: boolean;
  predictionAlerts: boolean;
  forumActivity: boolean;
  breaking_news: boolean;
}

interface PushNotification {
  id: string;
  title: string;
  body: string;
  type: 'chat' | 'game' | 'prediction' | 'forum' | 'news';
  timestamp: Date;
  read: boolean;
  data?: any;
}

const PushNotificationSystem: React.FC = () => {
  const { user } = useAuth();
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [notifications, setNotifications] = useState<PushNotification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>({
    chatMessages: true,
    gameUpdates: true,
    predictionAlerts: false,
    forumActivity: false,
    breaking_news: true
  });

  useEffect(() => {
    checkNotificationSupport();
    loadNotifications();
    setupRealtimeSubscriptions();
  }, [user]);

  const checkNotificationSupport = () => {
    if ('Notification' in window && 'serviceWorker' in navigator) {
      setIsSupported(true);
      setIsSubscribed(Notification.permission === 'granted');
    }
  };

  const requestNotificationPermission = async () => {
    if (!isSupported) return;

    try {
      const permission = await Notification.requestPermission();
      setIsSubscribed(permission === 'granted');
      
      if (permission === 'granted') {
        await registerServiceWorker();
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
    }
  };

  const registerServiceWorker = async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered:', registration);
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  };

  const loadNotifications = async () => {
    if (!user) return;

    try {
      // Load recent notifications from database or create mock data
      const mockNotifications: PushNotification[] = [
        {
          id: '1',
          title: 'New Chat Message',
          body: 'Marty BoomStick: BOOM! Great game discussion!',
          type: 'chat',
          timestamp: new Date(Date.now() - 300000),
          read: false
        },
        {
          id: '2',
          title: 'Game Prediction Alert',
          body: 'ML Algorithm updated: Mariners 78% win probability',
          type: 'prediction',
          timestamp: new Date(Date.now() - 600000),
          read: false
        },
        {
          id: '3',
          title: 'Breaking News',
          body: 'Mariners announce roster changes',
          type: 'news',
          timestamp: new Date(Date.now() - 900000),
          read: true
        }
      ];
      
      setNotifications(mockNotifications);
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const setupRealtimeSubscriptions = () => {
    if (!user) return;

    // Subscribe to chat messages
    const chatSubscription = supabase
      .channel('chat_notifications')
      .on('postgres_changes', 
        { event: 'INSERT', schema: 'public', table: 'chat_messages' },
        (payload) => {
          if (settings.chatMessages && payload.new.user_id !== user.id) {
            showNotification({
              title: 'New Chat Message',
              body: `${payload.new.username}: ${payload.new.message.substring(0, 50)}...`,
              type: 'chat',
              data: payload.new
            });
          }
        }
      )
      .subscribe();

    // Subscribe to forum posts
    const forumSubscription = supabase
      .channel('forum_notifications')
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'forum_posts' },
        (payload) => {
          if (settings.forumActivity && payload.new.user_id !== user.id) {
            showNotification({
              title: 'New Forum Post',
              body: `New post: ${payload.new.title}`,
              type: 'forum',
              data: payload.new
            });
          }
        }
      )
      .subscribe();

    return () => {
      chatSubscription.unsubscribe();
      forumSubscription.unsubscribe();
    };
  };

  const showNotification = (notificationData: Omit<PushNotification, 'id' | 'timestamp' | 'read'>) => {
    const notification: PushNotification = {
      ...notificationData,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false
    };

    // Add to local state
    setNotifications(prev => [notification, ...prev.slice(0, 9)]);

    // Show browser notification if subscribed
    if (isSubscribed && document.hidden) {
      new Notification(notification.title, {
        body: notification.body,
        icon: '/placeholder.svg',
        badge: '/placeholder.svg',
        tag: notification.type,
        requireInteraction: false,
        silent: false
      });
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const updateSettings = (key: keyof NotificationSettings, value: boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    
    // Save to user preferences
    if (user) {
      supabase.from('profiles').upsert({
        id: user.id,
        notification_settings: { ...settings, [key]: value }
      });
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'chat': return MessageSquare;
      case 'game': return Zap;
      case 'prediction': return TrendingUp;
      case 'forum': return Users;
      case 'news': return Bell;
      default: return Bell;
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center">
          <Bell className="mr-2 h-5 w-5" />
          Push Notifications
          {unreadCount > 0 && (
            <Badge className="ml-2 bg-red-500">{unreadCount}</Badge>
          )}
        </h2>
        
        {isSupported && (
          <Button
            onClick={requestNotificationPermission}
            variant={isSubscribed ? "default" : "outline"}
            size="sm"
          >
            {isSubscribed ? (
              <>
                <Bell className="mr-2 h-4 w-4" />
                Enabled
              </>
            ) : (
              <>
                <BellOff className="mr-2 h-4 w-4" />
                Enable
              </>
            )}
          </Button>
        )}
      </div>

      {!isSupported && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <p className="text-yellow-800 text-sm">
            Push notifications are not supported in your browser.
          </p>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <h3 className="font-semibold mb-4">Notification Settings</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <MessageSquare className="h-4 w-4 text-blue-600" />
                <span className="text-sm">Chat Messages</span>
              </div>
              <Switch
                checked={settings.chatMessages}
                onCheckedChange={(checked) => updateSettings('chatMessages', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="h-4 w-4 text-green-600" />
                <span className="text-sm">Game Updates</span>
              </div>
              <Switch
                checked={settings.gameUpdates}
                onCheckedChange={(checked) => updateSettings('gameUpdates', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-purple-600" />
                <span className="text-sm">Prediction Alerts</span>
              </div>
              <Switch
                checked={settings.predictionAlerts}
                onCheckedChange={(checked) => updateSettings('predictionAlerts', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-orange-600" />
                <span className="text-sm">Forum Activity</span>
              </div>
              <Switch
                checked={settings.forumActivity}
                onCheckedChange={(checked) => updateSettings('forumActivity', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-4 w-4 text-red-600" />
                <span className="text-sm">Breaking News</span>
              </div>
              <Switch
                checked={settings.breaking_news}
                onCheckedChange={(checked) => updateSettings('breaking_news', checked)}
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-semibold mb-4">Recent Notifications</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {notifications.length === 0 ? (
              <p className="text-gray-500 text-sm text-center py-4">
                No notifications yet
              </p>
            ) : (
              notifications.map((notif) => {
                const IconComponent = getNotificationIcon(notif.type);
                return (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      notif.read ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'
                    }`}
                    onClick={() => markAsRead(notif.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <IconComponent className="h-4 w-4 mt-1 text-gray-600" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm">{notif.title}</p>
                        <p className="text-xs text-gray-600 mt-1">{notif.body}</p>
                        <p className="text-xs text-gray-400 mt-1">
                          {notif.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                      {!notif.read && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PushNotificationSystem;