import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Cloud, Sun, CloudRain, Wind, Thermometer } from 'lucide-react';

const WeatherWidget: React.FC = () => {
  const [weather, setWeather] = useState({
    temp: 72,
    condition: 'sunny',
    humidity: 45,
    windSpeed: 8,
    stadium: 'T-Mobile Park'
  });

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny': return <Sun className="h-6 w-6 text-yellow-500" />;
      case 'cloudy': return <Cloud className="h-6 w-6 text-gray-500" />;
      case 'rainy': return <CloudRain className="h-6 w-6 text-blue-500" />;
      default: return <Sun className="h-6 w-6 text-yellow-500" />;
    }
  };

  return (
    <Card className="bg-gradient-to-br from-sky-50 to-blue-50 dark:from-sky-900/20 dark:to-blue-900/20">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          {getWeatherIcon(weather.condition)}
          Game Day Weather
        </CardTitle>
        <p className="text-sm text-gray-600 dark:text-gray-400">{weather.stadium}</p>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="text-3xl font-bold">{weather.temp}°F</div>
          <div className="text-right">
            <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">{weather.condition}</p>
            <p className="text-xs text-gray-500">Perfect for baseball!</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Wind className="h-4 w-4 text-gray-500" />
            <span>{weather.windSpeed} mph</span>
          </div>
          <div className="flex items-center gap-2">
            <Thermometer className="h-4 w-4 text-gray-500" />
            <span>{weather.humidity}% humidity</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WeatherWidget;