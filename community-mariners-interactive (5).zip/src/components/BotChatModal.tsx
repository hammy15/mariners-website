import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface BotChatModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  botName: string;
  botIcon: React.ReactNode;
  botColor: string;
}

const BotChatModal: React.FC<BotChatModalProps> = ({ 
  open, 
  onOpenChange, 
  botName, 
  botIcon, 
  botColor 
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `Hey there! I'm ${botName}. How can I help you today?`,
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const sendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = inputValue;
    setInputValue('');

    // Get bot response asynchronously
    const responseText = await getBotResponse(currentInput, botName);
    const botResponse: Message = {
      id: (Date.now() + 1).toString(),
      text: responseText,
      isUser: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, botResponse]);
  };

  const getBotResponse = async (input: string, bot: string): Promise<string> => {
    try {
      // Get bot prompt from database and generate AI response
      const { data, error } = await supabase.functions.invoke('admin-bot-management', {
        body: {
          action: 'getBotResponse',
          botName: bot,
          userMessage: input
        }
      });

      if (error) throw error;
      return data.response || getDefaultResponse(bot);
    } catch (error) {
      console.error('Bot response error:', error);
      return getDefaultResponse(bot);
    }
  };

  const getDefaultResponse = (bot: string): string => {
    const responses = {
      'Marty': [
        "That's a great question! Let me think about that...",
        "Interesting perspective! Here's what I think...",
        "You know what? That reminds me of a game I saw..."
      ],
      'Captain': [
        "Ahoy! Let me chart a course through that question...",
        "By the trident! That's a tactical question...",
        "Navigate wisely, matey. Here's my take..."
      ],
      'Spartan': [
        "Warrior! Your question demands a strategic response...",
        "In battle and baseball, preparation is key...",
        "Victory comes to those who plan. Here's my analysis..."
      ]
    };
    
    const botResponses = responses[bot as keyof typeof responses] || responses.Marty;
    return botResponses[Math.floor(Math.random() * botResponses.length)];
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md h-[500px] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className={`p-1 rounded-full bg-${botColor}-100`}>
              {botIcon}
            </div>
            Chat with {botName}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.isUser
                      ? 'bg-blue-500 text-white'
                      : `bg-${botColor}-100 text-gray-800`
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        
        <div className="flex gap-2 pt-4 border-t">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message..."
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          />
          <Button onClick={sendMessage} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BotChatModal;