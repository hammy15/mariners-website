# GitHub Build & Output Setup Guide

## 1. Repository Setup

### Create New Repository
1. Go to https://github.com/new
2. Repository name: `mariners-fan-hub`
3. Set to **Public**
4. ✅ Add README file
5. ✅ Add .gitignore (Node)
6. Click **Create repository**

### Upload Your Code
**Method 1: Drag & Drop**
1. Download your project as ZIP
2. Extract files
3. Go to your GitHub repo
4. Click **uploading an existing file**
5. Drag all project files
6. Commit changes

**Method 2: Git Commands**
```bash
git clone https://github.com/yourusername/mariners-fan-hub.git
cd mariners-fan-hub
# Copy your project files here
git add .
git commit -m "Initial commit"
git push origin main
```

## 2. Build Configuration

### Package.json Build Script
Ensure your `package.json` has:
```json
{
  "scripts": {
    "build": "vite build",
    "preview": "vite preview"
  }
}
```

### Build Output Directory
- **Vite builds to**: `dist/`
- **Output files**: `dist/index.html`, `dist/assets/`

## 3. GitHub Actions (Auto-Deploy)

### Create Workflow File
Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm install
      
    - name: Build
      run: npm run build
      
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

## 4. GitHub Pages Setup

1. Go to repo **Settings**
2. Scroll to **Pages**
3. Source: **Deploy from a branch**
4. Branch: **gh-pages**
5. Folder: **/ (root)**
6. Click **Save**

## 5. Environment Variables

### For Supabase Integration
1. Go to repo **Settings** → **Secrets and variables** → **Actions**
2. Add secrets:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

## 6. Build Commands Reference

### Local Build
```bash
npm install
npm run build
npm run preview
```

### Build Output Structure
```
dist/
├── index.html
├── assets/
│   ├── index-[hash].js
│   ├── index-[hash].css
│   └── [other assets]
└── [other static files]
```

## 7. Deployment URLs

After setup, your site will be available at:
- **GitHub Pages**: `https://yourusername.github.io/mariners-fan-hub`
- **Custom Domain**: Configure in Pages settings

## 8. Troubleshooting

### Build Fails
- Check `package.json` dependencies
- Verify Node.js version (use 18+)
- Check for TypeScript errors

### Deploy Fails
- Ensure `gh-pages` branch exists
- Check GitHub Actions logs
- Verify build output in `dist/`

### 404 Errors
- Check routing configuration
- Ensure `index.html` in root of `dist/`
- Add `404.html` for SPA routing

## Quick Deploy Links

**One-Click Vercel**: 
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/mariners-fan-hub)

**One-Click Netlify**:
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/yourusername/mariners-fan-hub)