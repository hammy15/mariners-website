import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, Heart, Crown } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tier: 'supporter' | 'champion' | null;
  customAmount?: number;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ 
  open, 
  onOpenChange, 
  tier,
  customAmount 
}) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');

  const getAmount = () => {
    if (tier === 'supporter') return 5;
    if (tier === 'champion' && customAmount) return customAmount;
    return 0;
  };

  const getTierInfo = () => {
    if (tier === 'supporter') {
      return {
        name: 'Site Supporter',
        icon: <Heart className="w-5 h-5" />,
        description: 'Monthly donation to help keep TridentFans running',
        badge: 'Supporter Badge'
      };
    }
    if (tier === 'champion') {
      return {
        name: 'Site Champion',
        icon: <Crown className="w-5 h-5" />,
        description: 'Custom donation to help add new features',
        badge: 'Champion Badge'
      };
    }
    return null;
  };

  const handlePayment = async () => {
    if (!email) {
      toast.error('Please enter your email address');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('stripe-payments', {
        body: {
          amount: getAmount() * 100, // Convert to cents
          email,
          tier,
          isRecurring: tier === 'supporter'
        }
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error: any) {
      console.error('Payment error:', error);
      toast.error('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const tierInfo = getTierInfo();
  if (!tierInfo) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            {tierInfo.icon}
            <span>Support TridentFans - {tierInfo.name}</span>
          </DialogTitle>
          <DialogDescription>
            {tierInfo.description}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">Amount:</span>
              <span className="text-xl font-bold text-blue-600">
                ${getAmount()}{tier === 'supporter' ? '/month' : ''}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="font-medium">You'll receive:</span>
              <span className="text-sm bg-blue-600 text-white px-2 py-1 rounded">
                {tierInfo.badge}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <p className="text-xs text-gray-500">
              We'll send your receipt and badge information here
            </p>
          </div>

          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handlePayment}
              disabled={loading || !email}
              className="flex-1"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              {loading ? 'Processing...' : `Donate $${getAmount()}`}
            </Button>
          </div>

          <p className="text-xs text-center text-gray-500">
            Secure payment powered by Stripe. Your support helps keep TridentFans free for everyone!
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;