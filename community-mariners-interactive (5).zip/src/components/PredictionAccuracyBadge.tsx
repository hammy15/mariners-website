import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Trophy, Target, TrendingUp, Award } from 'lucide-react';

interface PredictionAccuracyBadgeProps {
  accuracy: number;
  totalPredictions: number;
  streak?: number;
  className?: string;
}

const PredictionAccuracyBadge: React.FC<PredictionAccuracyBadgeProps> = ({
  accuracy,
  totalPredictions,
  streak = 0,
  className = ''
}) => {
  const getBadgeInfo = (accuracy: number) => {
    if (accuracy >= 90) return { 
      icon: Trophy, 
      color: 'bg-yellow-500 text-white', 
      title: 'Oracle',
      description: 'Legendary Predictor' 
    };
    if (accuracy >= 80) return { 
      icon: Award, 
      color: 'bg-purple-500 text-white', 
      title: 'Expert',
      description: 'Elite Analyst' 
    };
    if (accuracy >= 70) return { 
      icon: Target, 
      color: 'bg-blue-500 text-white', 
      title: 'Sharp',
      description: 'Skilled Predictor' 
    };
    if (accuracy >= 60) return { 
      icon: TrendingUp, 
      color: 'bg-green-500 text-white', 
      title: 'Rising',
      description: 'Improving Analyst' 
    };
    return { 
      icon: Target, 
      color: 'bg-gray-500 text-white', 
      title: 'Rookie',
      description: 'Learning the Game' 
    };
  };

  const badgeInfo = getBadgeInfo(accuracy);
  const Icon = badgeInfo.icon;

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <Badge className={`${badgeInfo.color} flex items-center space-x-1 px-2 py-1`}>
        <Icon className="h-3 w-3" />
        <span className="text-xs font-semibold">{badgeInfo.title}</span>
      </Badge>
      
      <div className="text-xs text-gray-600 dark:text-gray-400">
        <div>{accuracy.toFixed(1)}% ({totalPredictions} games)</div>
        {streak > 0 && (
          <div className="text-green-600 dark:text-green-400">
            🔥 {streak} streak
          </div>
        )}
      </div>
    </div>
  );
};

export default PredictionAccuracyBadge;