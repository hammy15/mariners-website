import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Heart, Coffee, DollarSign, HelpCircle } from 'lucide-react';

const SupportContribute = () => {
  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {/* Support Button */}
      <Card className="glass-effect p-2">
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center gap-2 text-xs hover:bg-primary/10"
          onClick={() => window.location.href = '/support'}
        >
          <HelpCircle className="h-3 w-3" />
          Support
        </Button>
      </Card>

      {/* Contribute Button */}
      <Card className="glass-effect p-2">
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center gap-2 text-xs hover:bg-green-500/10 text-green-600 dark:text-green-400"
          onClick={() => window.open('https://ko-fi.com/marinersai', '_blank')}
        >
          <Coffee className="h-3 w-3" />
          Buy Coffee
        </Button>
      </Card>

      {/* Donate Button */}
      <Card className="glass-effect p-2">
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center gap-2 text-xs hover:bg-blue-500/10 text-blue-600 dark:text-blue-400"
          onClick={() => window.open('https://paypal.me/marinersai', '_blank')}
        >
          <Heart className="h-3 w-3 text-red-500" />
          Donate
        </Button>
      </Card>
    </div>
  );
};

export default SupportContribute;