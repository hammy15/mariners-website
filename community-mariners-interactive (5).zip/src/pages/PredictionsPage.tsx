import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import EnhancedPredictionModal from '@/components/EnhancedPredictionModal';
import PredictionLeaderboards from '@/components/PredictionLeaderboards';
import BotLeaderboard from '@/components/BotLeaderboard';
import { supabase } from '@/lib/supabase';

const PredictionsPage = () => {
  const [selectedGame, setSelectedGame] = useState(null);
  const [upcomingGames, setUpcomingGames] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUpcomingGames();
    fetchLeaderboard();
  }, []);

  const fetchUpcomingGames = async () => {
    try {
      const { data, error } = await supabase
        .from('game_schedule')
        .select('*')
        .gte('game_date', new Date().toISOString().split('T')[0])
        .order('game_date', { ascending: true })
        .limit(10);

      if (error) throw error;
      setUpcomingGames(data || []);
    } catch (error) {
      console.error('Error fetching games:', error);
      // Fallback to mock data
      setUpcomingGames([
        {
          id: 1,
          opponent: "Houston Astros",
          game_date: "2024-01-20",
          game_time: "7:10 PM",
          location: "T-Mobile Park",
          predictions_count: 156
        },
        {
          id: 2,
          opponent: "Los Angeles Angels",
          game_date: "2024-01-22",
          game_time: "1:10 PM",
          location: "Angel Stadium",
          predictions_count: 89
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const fetchLeaderboard = async () => {
    try {
      // This would be a more complex query in real implementation
      const mockLeaderboard = [
        { rank: 1, user: "PredictionKing", accuracy: "78%", points: 2340 },
        { rank: 2, user: "MarinersOracle", accuracy: "76%", points: 2180 },
        { rank: 3, user: "BaseballGuru", accuracy: "74%", points: 2050 }
      ];
      setLeaderboard(mockLeaderboard);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
    }
  };

  const handleMakePrediction = (game: any) => {
    setSelectedGame(game);
    setIsModalOpen(true);
  };

  const handlePredictionMade = () => {
    fetchUpcomingGames(); // Refresh to update prediction counts
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Game Predictions</h1>
        <Badge variant="secondary">Season: 2024</Badge>
      </div>

      {/* Upcoming Games */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Upcoming Games</h2>
        {loading ? (
          <div className="text-center py-8">Loading games...</div>
        ) : (
          <div className="grid gap-4">
            {upcomingGames.map((game: any) => (
              <Card key={game.id} className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">vs {game.opponent}</h3>
                    <p className="text-gray-600">{game.game_date} at {game.game_time}</p>
                    <p className="text-sm text-gray-500">{game.location}</p>
                  </div>
                  <div className="text-right">
                    <Badge>{game.predictions_count || 0} predictions</Badge>
                  </div>
                </div>
                <Button 
                  className="w-full"
                  onClick={() => handleMakePrediction(game)}
                >
                  Make Prediction
                </Button>
              </Card>
            ))}
          </div>
        )}
      </div>
      {/* Enhanced Leaderboards */}
      <PredictionLeaderboards />
      
      {/* AI Bot Leaderboard */}
      <BotLeaderboard />

      {/* How it Works */}
      <Card className="p-6 bg-blue-50 dark:bg-blue-900/20">
        <h3 className="text-lg font-semibold mb-2">7-Category Prediction System</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
          <ul className="space-y-1">
            <li>• 1. Mariners Win/Lose (10 pts)</li>
            <li>• 2. Starter 5+ Innings (10 pts)</li>
            <li>• 3. Home Run Player (15 pts)</li>
            <li>• 4. Relief Pitchers x2 (5 pts each)</li>
          </ul>
          <ul className="space-y-1">
            <li>• 5. Pitch Count Over/Under 80 (10 pts)</li>
            <li>• 6. Extra Innings Yes/No (10 pts)</li>
            <li>• 7. Forum Tossup Winner (5 pts)</li>
            <li>• Weekly reset: Sunday MST midnight</li>
          </ul>
        </div>
      </Card>

      <EnhancedPredictionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        game={selectedGame}
        onPredictionMade={handlePredictionMade}
      />
    </div>
  );
};

export default PredictionsPage;