import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://mqeddvipsmfvusqlkbqq.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1xZWRkdmlwc21mdnVzcWxrYnFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQyMDAxMjksImV4cCI6MjA2OTc3NjEyOX0.0P5jy7gHU5vh09DWPXYpJbZ6BELuXD8Z8s1pulVd69g'

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Test connection
export const testConnection = async () => {
  try {
    const { data, error } = await supabase.from('profiles').select('count').limit(1);
    if (error) {
      console.warn('Supabase connection test warning:', error.message);
      return false;
    }
    console.log('Supabase connection successful');
    return true;
  } catch (err) {
    console.error('Supabase connection failed:', err);
    return false;
  }
};

// Initialize connection test
testConnection();