import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Briefcase, TrendingUp, Clock, Users } from 'lucide-react';

interface GMThread {
  id: string;
  title: string;
  author: string;
  category: 'trade' | 'draft' | 'strategy' | 'roster';
  replies: number;
  lastActivity: string;
  upvotes: number;
}

const GMForum: React.FC = () => {
  const [showNewThread, setShowNewThread] = useState(false);
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [newThreadContent, setNewThreadContent] = useState('');

  const threads: GMThread[] = [
    { id: '1', title: 'Trade Proposal: Mariners should target pitching depth', author: 'TridentGM', category: 'trade', replies: 18, lastActivity: '3m ago', upvotes: 12 },
    { id: '2', title: 'Draft Strategy: Focus on college hitters in 2024', author: 'ScoutingReport', category: 'draft', replies: 25, lastActivity: '8m ago', upvotes: 19 },
    { id: '3', title: 'Roster Construction: Too many lefties in the lineup?', author: 'AnalyticsFan', category: 'roster', replies: 14, lastActivity: '15m ago', upvotes: 8 },
    { id: '4', title: 'Long-term Strategy: Building around young core', author: 'FutureSeer', category: 'strategy', replies: 31, lastActivity: '22m ago', upvotes: 23 },
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'trade': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-green-100 text-green-800';
      case 'strategy': return 'bg-purple-100 text-purple-800';
      case 'roster': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleCreateThread = () => {
    if (newThreadTitle.trim() && newThreadContent.trim()) {
      setNewThreadTitle('');
      setNewThreadContent('');
      setShowNewThread(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center space-x-2">
            <Briefcase className="w-5 h-5" />
            <span>If I was the GM</span>
          </CardTitle>
          <Button onClick={() => setShowNewThread(!showNewThread)} size="sm">
            <Plus className="w-4 h-4 mr-1" />
            New Idea
          </Button>
        </div>
        <p className="text-sm text-gray-600">Share your GM strategies • Resets weekly</p>
      </CardHeader>
      <CardContent>
        {showNewThread && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <Input
                  placeholder="Your GM strategy title..."
                  value={newThreadTitle}
                  onChange={(e) => setNewThreadTitle(e.target.value)}
                />
                <Textarea
                  placeholder="Explain your GM decision..."
                  value={newThreadContent}
                  onChange={(e) => setNewThreadContent(e.target.value)}
                  rows={4}
                />
                <div className="flex space-x-2">
                  <Button onClick={handleCreateThread} size="sm">Share Idea</Button>
                  <Button variant="outline" onClick={() => setShowNewThread(false)} size="sm">Cancel</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-3">
          {threads
            .sort((a, b) => b.upvotes - a.upvotes)
            .map((thread) => (
              <div key={thread.id} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-sm">{thread.title}</h3>
                  <Badge className={`text-xs ${getCategoryColor(thread.category)}`}>
                    {thread.category}
                  </Badge>
                </div>
                <div className="flex justify-between items-center text-xs text-gray-500">
                  <span>by {thread.author}</span>
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center space-x-1">
                      <TrendingUp className="w-3 h-3" />
                      <span>{thread.upvotes}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Users className="w-3 h-3" />
                      <span>{thread.replies}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{thread.lastActivity}</span>
                    </span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default GMForum;