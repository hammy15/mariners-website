import React, { useState, useEffect } from 'react';
import { GradientCard, AnimatedBadge, GlowButton } from '@/components/EnhancedVisualComponents';
import { supabase } from '@/lib/supabase';

interface GameThread {
  id: string;
  title: string;
  opponent: string;
  gameDate: string;
  gameTime: string;
  status: 'upcoming' | 'active' | 'closed' | 'archived';
  messageCount: number;
  participants: number;
}

const GameThreadManager = () => {
  const [gameThreads, setGameThreads] = useState<GameThread[]>([]);
  const [currentThread, setCurrentThread] = useState<GameThread | null>(null);

  // Mock data for game threads
  useEffect(() => {
    const mockThreads: GameThread[] = [
      {
        id: '1',
        title: "Today's Game: Mariners vs Rangers",
        opponent: 'Texas Rangers',
        gameDate: new Date().toLocaleDateString(),
        gameTime: '7:10 PM PST',
        status: 'active',
        messageCount: 247,
        participants: 89
      },
      {
        id: '2',
        title: 'Game Thread: Mariners vs Astros',
        opponent: 'Houston Astros',
        gameDate: new Date(Date.now() - 86400000).toLocaleDateString(),
        gameTime: '1:10 PM PST',
        status: 'archived',
        messageCount: 312,
        participants: 156
      }
    ];

    setGameThreads(mockThreads);
    
    // Auto-create today's game thread
    const today = new Date();
    const gameTime = new Date(today.getTime() + (19 * 60 + 10) * 60000); // 7:10 PM today
    const oneHourBefore = new Date(gameTime.getTime() - 60 * 60000);

    if (today >= oneHourBefore && today <= gameTime) {
      setCurrentThread(mockThreads[0]);
    }
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'upcoming': return 'warning';
      case 'closed': return 'secondary';
      case 'archived': return 'secondary';
      default: return 'primary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return '🔴';
      case 'upcoming': return '⏰';
      case 'closed': return '🔒';
      case 'archived': return '📁';
      default: return '⚾';
    }
  };

  return (
    <div className="space-y-6">
      {/* Current Active Thread */}
      {currentThread && (
        <GradientCard className="p-6" gradient="from-green-500 to-emerald-500 text-white">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              🔴 LIVE: {currentThread.title}
            </h2>
            <AnimatedBadge variant="secondary" pulse>
              {currentThread.participants} watching
            </AnimatedBadge>
          </div>
          
          <div className="grid md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-3xl font-bold">{currentThread.messageCount}</div>
              <div className="text-sm opacity-90">Messages</div>
            </div>
            <div>
              <div className="text-3xl font-bold">{currentThread.participants}</div>
              <div className="text-sm opacity-90">Participants</div>
            </div>
            <div>
              <div className="text-3xl font-bold">{currentThread.gameTime}</div>
              <div className="text-sm opacity-90">Game Time</div>
            </div>
          </div>

          <div className="mt-4 flex justify-center">
            <GlowButton variant="warning">
              💬 Join Discussion
            </GlowButton>
          </div>
        </GradientCard>
      )}

      {/* All Game Threads */}
      <GradientCard className="p-6">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          📋 Game Threads
        </h2>

        <div className="space-y-4">
          {gameThreads.map(thread => (
            <div key={thread.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getStatusIcon(thread.status)}</span>
                  <div>
                    <h3 className="font-semibold">{thread.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      vs {thread.opponent} • {thread.gameDate} at {thread.gameTime}
                    </p>
                  </div>
                </div>
                <AnimatedBadge variant={getStatusColor(thread.status) as any}>
                  {thread.status.toUpperCase()}
                </AnimatedBadge>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                  <span>💬 {thread.messageCount} messages</span>
                  <span>👥 {thread.participants} participants</span>
                </div>

                <div className="flex gap-2">
                  {thread.status === 'active' && (
                    <GlowButton variant="success">Join</GlowButton>
                  )}
                  {thread.status === 'archived' && (
                    <button className="px-3 py-1 text-sm bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600">
                      View Archive
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Thread Creation Info */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <h3 className="font-semibold mb-2 flex items-center gap-2">
            ℹ️ Game Thread Schedule
          </h3>
          <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
            <p>• Game threads open 1 hour before first pitch</p>
            <p>• Threads close at midnight PST on game day</p>
            <p>• Archived threads available for review</p>
            <p>• Profanity filter active in all discussions</p>
          </div>
        </div>
      </GradientCard>
    </div>
  );
};

export default GameThreadManager;