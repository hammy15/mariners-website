import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, Target, TrendingUp, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

interface UserPrediction {
  id: string;
  game_id: string;
  prediction: string;
  confidence: number;
  points_earned: number;
  status: 'pending' | 'correct' | 'incorrect';
  created_at: string;
}

interface PredictionStats {
  total_predictions: number;
  correct_predictions: number;
  accuracy_rate: number;
  total_points: number;
  rank: number;
}

const AuthenticatedPredictions: React.FC = () => {
  const { user } = useAuth();
  const [predictions, setPredictions] = useState<UserPrediction[]>([]);
  const [stats, setStats] = useState<PredictionStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchUserPredictions();
      fetchUserStats();
    }
  }, [user]);

  const fetchUserPredictions = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('game_predictions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setPredictions(data || []);
    } catch (error) {
      console.error('Error fetching predictions:', error);
      // Mock data for demo
      setPredictions([
        {
          id: '1',
          game_id: 'game1',
          prediction: 'Mariners Win',
          confidence: 85,
          points_earned: 10,
          status: 'correct',
          created_at: new Date().toISOString()
        },
        {
          id: '2',
          game_id: 'game2',
          prediction: 'Over 8.5 runs',
          confidence: 70,
          points_earned: 0,
          status: 'incorrect',
          created_at: new Date().toISOString()
        }
      ]);
    }
  };

  const fetchUserStats = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_prediction_stats')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      setStats(data || {
        total_predictions: 15,
        correct_predictions: 9,
        accuracy_rate: 60,
        total_points: 145,
        rank: 23
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
      setStats({
        total_predictions: 15,
        correct_predictions: 9,
        accuracy_rate: 60,
        total_points: 145,
        rank: 23
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'correct': return 'bg-green-500';
      case 'incorrect': return 'bg-red-500';
      default: return 'bg-yellow-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'correct': return <Trophy className="h-4 w-4" />;
      case 'incorrect': return <Target className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  if (!user) {
    return (
      <Card className="p-6 text-center">
        <div className="text-gray-500">
          Sign in to view your prediction history and stats
        </div>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 text-center">
        <div className="text-gray-500">Loading your predictions...</div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.total_predictions}</div>
              <div className="text-sm text-gray-600">Total Predictions</div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.accuracy_rate}%</div>
              <div className="text-sm text-gray-600">Accuracy Rate</div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.total_points}</div>
              <div className="text-sm text-gray-600">Total Points</div>
            </div>
          </Card>
          
          <Card className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">#{stats.rank}</div>
              <div className="text-sm text-gray-600">Leaderboard Rank</div>
            </div>
          </Card>
        </div>
      )}

      {/* Accuracy Progress */}
      {stats && (
        <Card className="p-6">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Prediction Accuracy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Correct: {stats.correct_predictions}</span>
                <span>Total: {stats.total_predictions}</span>
              </div>
              <Progress value={stats.accuracy_rate} className="h-2" />
              <div className="text-center text-sm text-gray-600">
                {stats.accuracy_rate}% accuracy rate
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Predictions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Predictions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {predictions.map((prediction) => (
              <div key={prediction.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${getStatusColor(prediction.status)} text-white`}>
                    {getStatusIcon(prediction.status)}
                  </div>
                  <div>
                    <div className="font-medium">{prediction.prediction}</div>
                    <div className="text-sm text-gray-600">
                      Confidence: {prediction.confidence}%
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={prediction.status === 'correct' ? 'default' : 'secondary'}>
                    {prediction.status === 'correct' ? `+${prediction.points_earned}` : '0'} pts
                  </Badge>
                  <div className="text-xs text-gray-500 mt-1">
                    {new Date(prediction.created_at).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthenticatedPredictions;