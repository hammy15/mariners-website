import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { TrendingUp, TrendingDown, Star, Users } from 'lucide-react';

const FantasyTracker: React.FC = () => {
  const [activeTab, setActiveTab] = useState('lineup');

  const mockPlayers = [
    { name: 'Mike Trout', team: 'LAA', position: 'OF', points: 24.5, trend: 'up', owned: 89 },
    { name: 'Mookie Betts', team: 'LAD', position: 'OF', points: 22.1, trend: 'up', owned: 76 },
    { name: 'Ronald Acuña Jr.', team: 'ATL', position: 'OF', points: 18.7, trend: 'down', owned: 82 }
  ];

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Star className="h-5 w-5 text-purple-600" />
          Fantasy Baseball Hub
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          {['lineup', 'waiver', 'trades'].map((tab) => (
            <Button
              key={tab}
              variant={activeTab === tab ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveTab(tab)}
              className="capitalize"
            >
              {tab}
            </Button>
          ))}
        </div>
        
        <div className="space-y-3">
          {mockPlayers.map((player, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant="secondary">{player.position}</Badge>
                <div>
                  <p className="font-medium">{player.name}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{player.team}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg">{player.points}</span>
                {player.trend === 'up' ? (
                  <TrendingUp className="h-4 w-4 text-green-500" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-500" />
                )}
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <Users className="h-3 w-3" />
                  {player.owned}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default FantasyTracker;