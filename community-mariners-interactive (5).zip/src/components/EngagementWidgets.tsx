import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { BarChart3, PieChart, TrendingUp, Users, Vote, Trophy, Target } from 'lucide-react';

interface Poll {
  id: string;
  question: string;
  options: { text: string; votes: number }[];
  totalVotes: number;
  endsAt: Date;
}

const EngagementWidgets: React.FC = () => {
  const [activePoll, setActivePoll] = useState<Poll>({
    id: '1',
    question: 'Who will be the Mariners MVP this season?',
    options: [
      { text: 'Julio Rodriguez', votes: 145 },
      { text: 'Cal Raleigh', votes: 89 },
      { text: 'George Kirby', votes: 67 },
      { text: 'Logan Gilbert', votes: 43 }
    ],
    totalVotes: 344,
    endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
  });

  const [userVote, setUserVote] = useState<string | null>(null);

  const handleVote = (optionText: string) => {
    if (userVote) return;
    setUserVote(optionText);
    setActivePoll(prev => ({
      ...prev,
      options: prev.options.map(opt => 
        opt.text === optionText ? { ...opt, votes: opt.votes + 1 } : opt
      ),
      totalVotes: prev.totalVotes + 1
    }));
  };

  const fanEngagement = [
    { metric: 'Active Members', value: '2,847', change: '+12%', icon: Users },
    { metric: 'Daily Posts', value: '156', change: '+8%', icon: TrendingUp },
    { metric: 'Game Predictions', value: '89%', change: '+5%', icon: Target },
    { metric: 'Community Score', value: '94/100', change: '+2%', icon: Trophy }
  ];

  const topContributors = [
    { name: 'SeattleFan2024', points: 1250, badge: 'Gold' },
    { name: 'MarinersForever', points: 980, badge: 'Silver' },
    { name: 'TridentWarrior', points: 875, badge: 'Bronze' },
    { name: 'BaseballAnalyst', points: 720, badge: 'Rising Star' }
  ];

  return (
    <div className="space-y-6">
      {/* Live Poll Widget */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Vote className="h-5 w-5" />
            Community Poll
          </CardTitle>
        </CardHeader>
        <CardContent>
          <h3 className="font-semibold mb-4">{activePoll.question}</h3>
          <div className="space-y-3">
            {activePoll.options.map((option, index) => {
              const percentage = activePoll.totalVotes > 0 
                ? Math.round((option.votes / activePoll.totalVotes) * 100) 
                : 0;
              
              return (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Button
                      variant={userVote === option.text ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleVote(option.text)}
                      disabled={!!userVote}
                      className="flex-1 justify-start"
                    >
                      {option.text}
                    </Button>
                    <span className="text-sm text-muted-foreground ml-2">
                      {percentage}% ({option.votes})
                    </span>
                  </div>
                  <Progress value={percentage} className="h-2" />
                </div>
              );
            })}
          </div>
          <div className="mt-4 text-sm text-muted-foreground text-center">
            {activePoll.totalVotes} total votes • Ends {activePoll.endsAt.toLocaleDateString()}
          </div>
        </CardContent>
      </Card>

      {/* Fan Engagement Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Community Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {fanEngagement.map((metric, index) => (
              <div key={index} className="text-center p-3 bg-muted/30 rounded-lg">
                {React.createElement(metric.icon, { className: "h-6 w-6 mx-auto mb-2 text-teal-600" })}
                <div className="font-bold text-lg">{metric.value}</div>
                <div className="text-sm text-muted-foreground">{metric.metric}</div>
                <Badge variant="secondary" className="text-xs mt-1">
                  {metric.change}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Contributors Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Top Contributors
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topContributors.map((contributor, index) => (
              <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-teal-600 text-white flex items-center justify-center text-sm font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <div className="font-medium text-sm">{contributor.name}</div>
                    <div className="text-xs text-muted-foreground">{contributor.points} points</div>
                  </div>
                </div>
                <Badge variant={
                  contributor.badge === 'Gold' ? 'default' :
                  contributor.badge === 'Silver' ? 'secondary' :
                  contributor.badge === 'Bronze' ? 'outline' : 'destructive'
                }>
                  {contributor.badge}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats Graph */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PieChart className="h-5 w-5" />
            Fan Activity This Week
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Game Discussions</span>
              <div className="flex items-center gap-2">
                <Progress value={85} className="w-20 h-2" />
                <span className="text-sm">85%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Predictions Made</span>
              <div className="flex items-center gap-2">
                <Progress value={72} className="w-20 h-2" />
                <span className="text-sm">72%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Photo Uploads</span>
              <div className="flex items-center gap-2">
                <Progress value={58} className="w-20 h-2" />
                <span className="text-sm">58%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Forum Posts</span>
              <div className="flex items-center gap-2">
                <Progress value={91} className="w-20 h-2" />
                <span className="text-sm">91%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EngagementWidgets;