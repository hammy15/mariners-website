import React from 'react';

interface MartyIconProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const MartyIcon: React.FC<MartyIconProps> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  return (
    <div className={`${sizeClasses[size]} ${className} relative`}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {/* Compass rose background */}
        <circle cx="50" cy="50" r="48" fill="#0f766e" stroke="#134e4a" strokeWidth="2"/>
        <path d="M50 10 L55 25 L50 30 L45 25 Z" fill="#fbbf24"/>
        <path d="M90 50 L75 55 L70 50 L75 45 Z" fill="#fbbf24"/>
        <path d="M50 90 L45 75 L50 70 L55 75 Z" fill="#fbbf24"/>
        <path d="M10 50 L25 45 L30 50 L25 55 Z" fill="#fbbf24"/>
        
        {/* Marty's face */}
        <circle cx="50" cy="45" r="18" fill="#fef3c7"/>
        
        {/* Sailor hat */}
        <ellipse cx="50" cy="32" rx="20" ry="8" fill="#1e40af"/>
        <rect x="30" y="28" width="40" height="8" fill="#1e40af"/>
        <text x="50" y="36" textAnchor="middle" fontSize="8" fill="white" fontWeight="bold">🔱</text>
        
        {/* Eyes */}
        <circle cx="44" cy="42" r="2" fill="#1f2937"/>
        <circle cx="56" cy="42" r="2" fill="#1f2937"/>
        
        {/* Smile */}
        <path d="M42 50 Q50 56 58 50" stroke="#1f2937" strokeWidth="2" fill="none"/>
        
        {/* Crystal ball */}
        <circle cx="75" cy="75" r="12" fill="#e0f2fe" stroke="#0891b2" strokeWidth="2" opacity="0.8"/>
        <circle cx="72" cy="72" r="3" fill="white" opacity="0.6"/>
      </svg>
    </div>
  );
};

export default MartyIcon;