# GoDaddy DNS Configuration for TridentFans

## Domain Setup Instructions

### Step 1: Access GoDaddy DNS Management
1. Log into your GoDaddy account
2. Go to "My Products" → "Domains"
3. Click "DNS" next to your domain name
4. Click "Manage DNS"

### Step 2: DNS Records Configuration

#### For Vercel Deployment (Recommended)
Add these DNS records in GoDaddy:

**A Records:**
```
Type: A
Name: @
Value: 76.76.19.61
TTL: 1 Hour
```

**CNAME Records:**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
TTL: 1 Hour
```

#### For Netlify Deployment (Alternative)
**A Records:**
```
Type: A
Name: @
Value: 75.2.60.5
TTL: 1 Hour
```

**CNAME Records:**
```
Type: CNAME
Name: www
Value: tridentfans.netlify.app
TTL: 1 Hour
```

### Step 3: SSL Certificate Setup
1. Enable "Full SSL" in your hosting platform
2. Force HTTPS redirects (already configured in vercel.json/netlify.toml)
3. Wait 24-48 hours for DNS propagation

### Step 4: Domain Verification
After DNS changes:
1. Add your custom domain in Vercel/Netlify dashboard
2. Verify domain ownership
3. Enable automatic SSL certificate generation

### Step 5: Test Configuration
```bash
# Check DNS propagation
nslookup yourdomain.com
dig yourdomain.com

# Test SSL
curl -I https://yourdomain.com
```

## Common Issues & Solutions

### ERR_SSL_PROTOCOL_ERROR
- Ensure A record points to correct IP
- Verify HTTPS redirect is enabled
- Clear browser cache and cookies
- Wait for full DNS propagation (24-48 hours)

### DNS Not Propagating
- Check TTL settings (set to 1 hour for faster updates)
- Use DNS checker tools online
- Try different DNS servers (8.8.8.8, 1.1.1.1)

### SSL Certificate Issues
- Verify domain ownership in hosting platform
- Check that CNAME points to correct hosting service
- Ensure no conflicting DNS records exist

## Final Checklist
- [ ] A record points to hosting platform IP
- [ ] CNAME record points to hosting platform
- [ ] Custom domain added in hosting dashboard
- [ ] SSL certificate generated and active
- [ ] HTTPS redirects working
- [ ] All pages load correctly with SSL