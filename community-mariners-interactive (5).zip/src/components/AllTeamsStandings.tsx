import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, TrendingUp, TrendingDown } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TeamStanding {
  Key: string;
  Name: string;
  City: string;
  Wins: number;
  Losses: number;
  Percentage: number;
  DivisionRank: number;
  League: string;
  Division: string;
  Streak: number;
  StreakType: string;
}

const AllTeamsStandings: React.FC = () => {
  const [standings, setStandings] = useState<TeamStanding[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStandings();
  }, []);

  const fetchStandings = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('sportsdata-mariners', {
        body: { endpoint: 'standings' }
      });

      if (error) throw error;
      
      if (data.success) {
        setStandings(data.data || []);
      } else {
        setError('No standings data available');
      }
    } catch (err) {
      setError('Failed to load standings');
      console.error('Standings error:', err);
    } finally {
      setLoading(false);
    }
  };

  const groupByDivision = (teams: TeamStanding[]) => {
    return teams.reduce((acc, team) => {
      const key = `${team.League} ${team.Division}`;
      if (!acc[key]) acc[key] = [];
      acc[key].push(team);
      return acc;
    }, {} as Record<string, TeamStanding[]>);
  };

  const TeamRow = ({ team, rank }: { team: TeamStanding; rank: number }) => (
    <div className={`flex items-center justify-between p-2 rounded ${team.Key === 'SEA' ? 'bg-teal-50 border-teal-200 border' : 'hover:bg-gray-50'}`}>
      <div className="flex items-center gap-3">
        <span className="text-sm font-medium w-6">{rank}</span>
        <div>
          <div className="font-medium">{team.City} {team.Name}</div>
          <div className="text-xs text-gray-500">{team.Wins}-{team.Losses}</div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm">{(team.Percentage * 100).toFixed(1)}%</span>
        <div className="flex items-center gap-1">
          {team.StreakType === 'W' ? (
            <TrendingUp className="h-3 w-3 text-green-500" />
          ) : (
            <TrendingDown className="h-3 w-3 text-red-500" />
          )}
          <span className="text-xs">{team.StreakType}{team.Streak}</span>
        </div>
      </div>
    </div>
  );

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-12 bg-gray-200 rounded"></div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  if (error) return (
    <Card>
      <CardContent className="p-6 text-center text-red-500">
        {error}
      </CardContent>
    </Card>
  );

  const divisions = groupByDivision(standings);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <Trophy className="h-5 w-5" />
          MLB Standings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="AL West" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="AL West">AL West</TabsTrigger>
            <TabsTrigger value="AL Central">AL Central</TabsTrigger>
            <TabsTrigger value="AL East">AL East</TabsTrigger>
          </TabsList>
          
          {Object.entries(divisions).map(([division, teams]) => (
            <TabsContent key={division} value={division} className="space-y-2">
              <h3 className="font-semibold text-sm text-gray-600 mb-2">{division}</h3>
              {teams
                .sort((a, b) => b.Percentage - a.Percentage)
                .map((team, index) => (
                  <TeamRow key={team.Key} team={team} rank={index + 1} />
                ))}
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AllTeamsStandings;