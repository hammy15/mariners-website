import React, { useState, useEffect } from 'react';
import { Card } from '@/components/MinimalComponents';

interface SeventhInningPopupProps {
  winner: 'Marty' | 'Captain' | 'Spartan';
  onClose: () => void;
}

const SeventhInningPopup: React.FC<SeventhInningPopupProps> = ({ winner, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    setAnimate(true);
    const timer = setTimeout(() => {
      setIsVisible(false);
      onClose();
    }, 8000);

    return () => clearTimeout(timer);
  }, [onClose]);

  const getBotEmoji = (bot: string) => {
    switch (bot) {
      case 'Marty': return '🤖';
      case 'Captain': return '⚓';
      case 'Spartan': return '🛡️';
      default: return '🎉';
    }
  };

  const getBotColor = (bot: string) => {
    switch (bot) {
      case 'Marty': return 'from-blue-500 to-cyan-500';
      case 'Captain': return 'from-indigo-500 to-purple-500';
      case 'Spartan': return 'from-red-500 to-orange-500';
      default: return 'from-green-500 to-emerald-500';
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className={`transform transition-all duration-1000 ${
        animate ? 'scale-100 rotate-0' : 'scale-0 rotate-180'
      }`}>
        <Card className={`p-8 mx-4 max-w-md w-full bg-gradient-to-br ${getBotColor(winner)} text-white shadow-2xl border-0`}>
          <div className="text-center space-y-4">
            <div className="text-8xl animate-bounce">
              {getBotEmoji(winner)}
            </div>
            
            <div className="space-y-2">
              <h2 className="text-3xl font-bold animate-pulse">
                7TH INNING!
              </h2>
              <div className="text-6xl font-extrabold animate-pulse">
                I WON!
              </div>
              <p className="text-xl font-semibold">
                {winner} wins the Forum Tossup!
              </p>
            </div>

            <div className="flex justify-center space-x-2 mt-6">
              <div className="w-3 h-3 bg-white rounded-full animate-ping"></div>
              <div className="w-3 h-3 bg-white rounded-full animate-ping" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-3 h-3 bg-white rounded-full animate-ping" style={{ animationDelay: '0.4s' }}></div>
            </div>

            <div className="text-sm opacity-90 mt-4">
              Forum Tossup Winner • Game Prediction #7
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default SeventhInningPopup;