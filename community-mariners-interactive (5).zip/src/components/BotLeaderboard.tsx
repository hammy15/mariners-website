import React, { useState, useEffect } from 'react';
import { Card, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const BotLeaderboard = () => {
  const [botStats, setBotStats] = useState([]);
  const [weeklyReset, setWeeklyReset] = useState('');

  useEffect(() => {
    fetchBotStats();
    calculateNextReset();
  }, []);

  const fetchBotStats = async () => {
    try {
      // Mock data - in real app would fetch from database
      const mockBotStats = [
        {
          name: 'Marty',
          avatar: '🤖',
          totalPoints: 1850,
          accuracy: '74%',
          weeklyPoints: 280,
          predictions: 156,
          bestCategory: 'Win/Lose',
          streak: 8
        },
        {
          name: 'Captain',
          avatar: '⚓',
          totalPoints: 1720,
          accuracy: '71%',
          weeklyPoints: 245,
          predictions: 142,
          bestCategory: 'Home Runs',
          streak: 5
        },
        {
          name: 'Spartan',
          avatar: '🛡️',
          totalPoints: 1680,
          accuracy: '69%',
          weeklyPoints: 230,
          predictions: 138,
          bestCategory: 'Pitch Count',
          streak: 3
        }
      ];
      
      setBotStats(mockBotStats);
    } catch (error) {
      console.error('Error fetching bot stats:', error);
    }
  };

  const calculateNextReset = () => {
    const now = new Date();
    const nextSunday = new Date();
    nextSunday.setDate(now.getDate() + (7 - now.getDay()));
    nextSunday.setHours(0, 0, 0, 0);
    setWeeklyReset(nextSunday.toLocaleDateString());
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI Bot Leaderboard</h2>
        <Badge variant="secondary">Next Reset: {weeklyReset}</Badge>
      </div>

      <div className="grid gap-4">
        {botStats.map((bot: any, index) => (
          <Card key={bot.name} className={`p-6 ${
            index === 0 ? 'border-2 border-yellow-400 bg-yellow-50 dark:bg-yellow-900/20' :
            index === 1 ? 'border-2 border-gray-400 bg-gray-50 dark:bg-gray-800/50' :
            'border-2 border-orange-400 bg-orange-50 dark:bg-orange-900/20'
          }`}>
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-4">
                <div className="text-4xl">{bot.avatar}</div>
                <div>
                  <div className="flex items-center gap-2">
                    {index === 0 && <span className="text-2xl">🥇</span>}
                    {index === 1 && <span className="text-2xl">🥈</span>}
                    {index === 2 && <span className="text-2xl">🥉</span>}
                    <h3 className="text-xl font-bold">{bot.name}</h3>
                  </div>
                  <p className="text-gray-600">AI Prediction Bot</p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-600">{bot.totalPoints}</div>
                <div className="text-sm text-gray-500">Total Points</div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">{bot.accuracy}</div>
                <div className="text-gray-500">Accuracy</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">{bot.weeklyPoints}</div>
                <div className="text-gray-500">This Week</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">{bot.bestCategory}</div>
                <div className="text-gray-500">Best Category</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">{bot.streak}</div>
                <div className="text-gray-500">Win Streak</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-6 bg-blue-50 dark:bg-blue-900/20">
        <h3 className="text-lg font-semibold mb-3">Bot Prediction Schedule</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>🤖 Marty:</span>
            <span>30 minutes before first pitch</span>
          </div>
          <div className="flex justify-between">
            <span>⚓ Captain:</span>
            <span>5 minutes before first pitch</span>
          </div>
          <div className="flex justify-between">
            <span>🛡️ Spartan:</span>
            <span>5 minutes before first pitch</span>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default BotLeaderboard;