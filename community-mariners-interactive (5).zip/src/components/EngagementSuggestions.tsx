import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  BarChart3, 
  Users, 
  Trophy, 
  MessageCircle, 
  TrendingUp, 
  Calendar,
  Target,
  Zap
} from 'lucide-react';

const EngagementSuggestions: React.FC = () => {
  const suggestions = [
    {
      title: "Fan Photo Contest",
      description: "Weekly stadium photo submissions with voting",
      icon: <Target className="h-5 w-5" />,
      engagement: "High",
      difficulty: "Easy"
    },
    {
      title: "Prediction Streaks",
      description: "Track consecutive correct game predictions",
      icon: <TrendingUp className="h-5 w-5" />,
      engagement: "Medium",
      difficulty: "Medium"
    },
    {
      title: "Player Performance Polls",
      description: "Daily polls on player of the game",
      icon: <BarChart3 className="h-5 w-5" />,
      engagement: "High",
      difficulty: "Easy"
    },
    {
      title: "Trade Deadline Simulator",
      description: "Interactive trade scenario discussions",
      icon: <Users className="h-5 w-5" />,
      engagement: "Very High",
      difficulty: "Hard"
    },
    {
      title: "Game Day Bingo",
      description: "Interactive bingo cards for live games",
      icon: <Trophy className="h-5 w-5" />,
      engagement: "High",
      difficulty: "Medium"
    },
    {
      title: "Fan Mood Tracker",
      description: "Real-time sentiment during games",
      icon: <MessageCircle className="h-5 w-5" />,
      engagement: "Medium",
      difficulty: "Hard"
    }
  ];

  const getEngagementColor = (level: string) => {
    switch(level) {
      case 'Very High': return 'bg-green-500';
      case 'High': return 'bg-blue-500';
      case 'Medium': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getDifficultyColor = (level: string) => {
    switch(level) {
      case 'Easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'Hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-yellow-500" />
          Engagement Ideas
          <Badge variant="secondary" className="ml-auto">Suggestions</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3">
          {suggestions.map((suggestion, idx) => (
            <div key={idx} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 bg-muted rounded-lg">
                    {suggestion.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{suggestion.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">
                      {suggestion.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${getEngagementColor(suggestion.engagement)}`} />
                        <span className="text-xs">{suggestion.engagement}</span>
                      </div>
                      <Badge variant="outline" className={`text-xs ${getDifficultyColor(suggestion.difficulty)}`}>
                        {suggestion.difficulty}
                      </Badge>
                    </div>
                  </div>
                </div>
                <Button size="sm" variant="outline" className="text-xs">
                  Implement
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="border-t pt-4">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                Updated weekly
              </div>
              <div className="flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                Based on analytics
              </div>
            </div>
            <Button size="sm" variant="ghost" className="text-xs">
              More Ideas
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EngagementSuggestions;