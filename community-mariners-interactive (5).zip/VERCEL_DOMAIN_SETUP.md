# Vercel Custom Domain Setup Guide

## Step 1: Access Vercel Dashboard
1. Go to https://vercel.com/dashboard
2. Select your `tridentfans` project
3. Click on the "Settings" tab
4. Click on "Domains" in the left sidebar

## Step 2: Add Custom Domain
1. In the "Domains" section, click "Add"
2. Enter your domain: `tridentfans.com`
3. Click "Add"
4. Vercel will show you DNS records to configure

## Step 3: Configure Domain Records
Vercel will provide these records:
- **A Record**: `76.76.19.61` (Vercel's IP)
- **CNAME Record**: `cname.vercel-dns.com`

## Step 4: Add www Subdomain (Optional)
1. Click "Add" again
2. Enter: `www.tridentfans.com`
3. This will redirect to your main domain

## Step 5: Verify Configuration
- Vercel will automatically check DNS propagation
- Green checkmark = Domain is configured correctly
- Orange warning = DNS still propagating (wait 24-48 hours)

## Step 6: SSL Certificate
- Vercel automatically provisions SSL certificates
- HTTPS will be enabled once domain verification completes
- Certificate auto-renews every 90 days

## Troubleshooting
- DNS changes take 24-48 hours to propagate globally
- Use `nslookup tridentfans.com` to check DNS resolution
- Clear browser cache if site doesn't load immediately