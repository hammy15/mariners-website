# Super Admin Setup Guide

## How to Create and Access Your Super Admin Account

### Step 1: Create a User Account
1. Go to your TridentFans website
2. Click "Sign In" in the header
3. Create a new account with your email and password
4. Verify your email if required

### Step 2: Add Yourself as Super Admin
After creating your user account, you need to manually add yourself to the super_admins table:

#### Option A: Using Supabase Dashboard
1. Go to your Supabase project dashboard
2. Navigate to "Table Editor" 
3. Find the "super_admins" table
4. Click "Insert row"
5. Fill in:
   - `user_id`: Your user ID (get from auth.users table)
   - `email`: Your email address
   - `is_active`: true

#### Option B: Using SQL Query
Run this SQL query in your Supabase SQL editor:

```sql
-- First, find your user ID
SELECT id, email FROM auth.users WHERE email = 'your-email@example.com';

-- Then insert yourself as super admin (replace the user_id with your actual ID)
INSERT INTO super_admins (user_id, email, is_active) 
VALUES ('your-user-id-here', 'your-email@example.com', true);
```

### Step 3: Access Admin Panel
1. Sign in to your account
2. Navigate to `/admin` (add /admin to your website URL)
3. You should now see the Super Admin Dashboard

### Admin Features Available:
- **Bot Management**: Update chat bot prompts and behavior
- **User Management**: Ban/unban users
- **Content Control**: Manage banned users list
- **System Settings**: Configure site-wide settings

### Troubleshooting:
- If you see "Access Denied", make sure you're in the super_admins table with is_active = true
- If you see "Please sign in", make sure you're logged into your account
- Check that your user_id in super_admins matches your actual user ID from auth.users

### Security Note:
Only add trusted administrators to the super_admins table as they have full control over the site.