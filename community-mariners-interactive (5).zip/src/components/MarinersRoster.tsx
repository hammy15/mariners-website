import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Player {
  PlayerID: number;
  FirstName: string;
  LastName: string;
  Jersey: number;
  Position: string;
  Height: string;
  Weight: number;
  BirthDate: string;
  Age: number;
  Salary: number;
}

const MarinersRoster: React.FC = () => {
  const [roster, setRoster] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchRoster();
  }, []);

  const fetchRoster = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('sportsdata-mariners', {
        body: { endpoint: 'mariners-roster' }
      });

      if (error) throw error;
      
      if (data.success) {
        setRoster(data.data || []);
      } else {
        setError('No roster data available');
      }
    } catch (err) {
      setError('Failed to load roster');
      console.error('Roster error:', err);
    } finally {
      setLoading(false);
    }
  };

  const categorizeByPosition = (players: Player[]) => {
    return {
      pitchers: players.filter(p => p.Position === 'P'),
      catchers: players.filter(p => p.Position === 'C'),
      infielders: players.filter(p => ['1B', '2B', '3B', 'SS'].includes(p.Position)),
      outfielders: players.filter(p => ['LF', 'CF', 'RF', 'OF'].includes(p.Position))
    };
  };

  const PlayerCard = ({ player }: { player: Player }) => (
    <div className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-medium">{player.FirstName} {player.LastName}</div>
          <div className="text-sm text-gray-500">{player.Position}</div>
          <div className="text-xs text-gray-400">Age: {player.Age}</div>
        </div>
        <Badge variant="outline">#{player.Jersey}</Badge>
      </div>
    </div>
  );

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-200 rounded"></div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  if (error) return (
    <Card>
      <CardContent className="p-6 text-center text-red-500">
        {error}
      </CardContent>
    </Card>
  );

  const categorized = categorizeByPosition(roster);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <Users className="h-5 w-5" />
          Mariners Roster
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="pitchers" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pitchers">Pitchers</TabsTrigger>
            <TabsTrigger value="catchers">Catchers</TabsTrigger>
            <TabsTrigger value="infielders">Infield</TabsTrigger>
            <TabsTrigger value="outfielders">Outfield</TabsTrigger>
          </TabsList>
          
          <TabsContent value="pitchers" className="space-y-2">
            {categorized.pitchers.map(player => (
              <PlayerCard key={player.PlayerID} player={player} />
            ))}
          </TabsContent>
          
          <TabsContent value="catchers" className="space-y-2">
            {categorized.catchers.map(player => (
              <PlayerCard key={player.PlayerID} player={player} />
            ))}
          </TabsContent>
          
          <TabsContent value="infielders" className="space-y-2">
            {categorized.infielders.map(player => (
              <PlayerCard key={player.PlayerID} player={player} />
            ))}
          </TabsContent>
          
          <TabsContent value="outfielders" className="space-y-2">
            {categorized.outfielders.map(player => (
              <PlayerCard key={player.PlayerID} player={player} />
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default MarinersRoster;
export { MarinersRoster };