# Vercel Root Directory Configuration Fix

## Immediate Action Required

### 1. Access Vercel Settings
**Direct Link:** https://vercel.com/dashboard/[your-project]/settings/general

Replace `[your-project]` with your actual project name.

### 2. Fix Root Directory Setting

**Location in Dashboard:**
- Settings → General → Build & Development Settings
- Look for "Root Directory" field

**Current Problem:** Likely set to wrong path
**Solution:** Set to one of these:

**Option A: Leave Blank**
```
Root Directory: [leave empty]
```

**Option B: Use Dot**
```
Root Directory: .
```

**Option C: If files are in subfolder**
```
Root Directory: frontend
```
(Only if your package.json is in a subfolder)

### 3. Build Command Settings
**Also check these in same settings page:**

**Build Command:**
```
npm run build
```

**Output Directory:**
```
dist
```

**Install Command:**
```
npm install
```

### 4. Save and Redeploy

1. Click **Save** button
2. Go to **Deployments** tab
3. Click **Redeploy** on latest failed deployment
4. Uncheck "Use existing Build Cache"
5. Click **Redeploy**

## Repository Structure Check

Your GitHub repository should look like:
```
repository-root/
├── package.json ← Must be here
├── vite.config.ts
├── tsconfig.json
├── src/
├── public/
└── dist/ (created during build)
```

## If Still Failing

### Check GitHub Repository
1. Go to your GitHub repository
2. Verify package.json is in the root (not in a subfolder)
3. If it's in a subfolder, either:
   - Move it to root, OR
   - Set Root Directory to that subfolder name

### Re-import Project
1. Delete project in Vercel
2. Import again from GitHub
3. Select correct repository
4. Leave Root Directory blank during import

## Quick Test
Run locally to verify structure:
```bash
npm install
npm run build
```
If this works locally, the issue is Vercel configuration.