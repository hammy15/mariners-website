import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { MessageSquare, Plus, Search, TrendingUp, Users, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import ForumPostModal from '@/components/ForumPostModal';
import RealtimeChat from '@/components/RealtimeChat';
import EnhancedForumSection from '@/components/EnhancedForumSection';
import AutomatedForumManager from '@/components/AutomatedForumManager';

const ForumPage: React.FC = () => {
  const { user } = useAuth();
  const [forumPosts, setForumPosts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const categories = ['all', "Today's Game", 'Temp Check', 'Off My Chest', 'General Discussion', 'Stadium', 'Predictions', 'Roster'];

  useEffect(() => {
    fetchPosts();
  }, [selectedCategory]);

  const fetchPosts = async () => {
    try {
      let query = supabase
        .from('forum_posts')
        .select('*')
        .order('created_at', { ascending: false });

      if (selectedCategory !== 'all') {
        query = query.eq('category', selectedCategory);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      setForumPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
      // Fallback to mock data
      setForumPosts([
        {
          id: 1,
          title: "Thoughts on the new roster moves?",
          author: "MarinersFan2024",
          replies: 23,
          category: "General Discussion",
          created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Less than an hour ago';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    return `${Math.floor(diffInHours / 24)} days ago`;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Mariners Forum</h1>
        <Button onClick={() => setIsModalOpen(true)}>New Post</Button>
      </div>
      {/* Automated Forum Management */}
      <AutomatedForumManager />

      {/* Enhanced Forum Section */}
      <EnhancedForumSection />

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            onClick={() => setSelectedCategory(category)}
            className="capitalize"
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Forum Posts */}
      {loading ? (
        <div className="text-center py-8">Loading posts...</div>
      ) : (
        <div className="space-y-4">
          {forumPosts.map((post: any) => (
            <Card key={post.id} className="p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex justify-between items-start mb-3">
                <Badge variant="secondary">{post.category}</Badge>
                <span className="text-sm text-gray-500">{formatTimeAgo(post.created_at)}</span>
              </div>
              <h3 className="text-lg font-semibold mb-2">{post.title}</h3>
              <div className="flex justify-between items-center text-sm text-gray-600">
                <span>By {post.author}</span>
                <span>{post.replies || 0} replies</span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Real-time Chat Section */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          {/* Forum Rules */}
          <Card className="p-6 bg-yellow-50 dark:bg-yellow-900/20">
            <h3 className="text-lg font-semibold mb-2">Forum Guidelines</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Be respectful to all members</li>
              <li>• Stay on topic</li>
              <li>• No spam or self-promotion</li>
              <li>• Keep discussions family-friendly</li>
            </ul>
          </Card>
        </div>
        
        <div>
          <RealtimeChat room="forum" title="Forum Chat" />
        </div>
      </div>


      <ForumPostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onPostCreated={fetchPosts}
      />
    </div>
  );
};

export default ForumPage;