# Supabase Connection Troubleshooting

## Quick Fix for "Invalid API key" Error

### Step 1: Get Fresh API Keys
1. Go to https://supabase.com/dashboard
2. Select your project: `zsiwvovthbccyhublgch`
3. Go to Settings → API
4. Copy the **anon/public** key (not the service_role key)

### Step 2: Update the Configuration
Replace the key in `src/lib/supabase.ts` with the fresh anon key from your dashboard.

### Step 3: Common Issues & Solutions

**Issue: "Invalid API key"**
- Solution: Make sure you're using the `anon` key, not `service_role`
- The anon key should start with `eyJhbGciOiJIUzI1NiIs...`

**Issue: "Project not found"**
- Solution: Verify the URL matches your project reference
- Should be: `https://zsiwvovthbccyhublgch.supabase.co`

**Issue: "Network error"**
- Solution: Check if Supabase is accessible from your network
- Try accessing the URL directly in browser

### Step 4: Test Connection
Open browser console and run:
```javascript
// Test if Supabase is reachable
fetch('https://zsiwvovthbccyhublgch.supabase.co/rest/v1/')
  .then(r => r.text())
  .then(console.log)
```

### Step 5: Alternative Fix
If the issue persists, create a new Supabase project:
1. Go to https://supabase.com/dashboard
2. Click "New Project"
3. Use the new URL and keys
4. Update `src/lib/supabase.ts` with new credentials

The app should connect successfully after updating with fresh API keys.