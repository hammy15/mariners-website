# Fix Vercel "package.json not found" Error

## The Problem
```
npm error code ENOENT
npm error syscall open
npm error path /vercel/path0/package.json
npm error errno -2
npm error enoent Could not read package.json
```

## Step-by-Step Fix

### 1. Check Your Repository Structure
Your files should be in the ROOT of your repository:
```
your-repo/
├── package.json ✅ (must be here)
├── vite.config.ts
├── src/
└── public/
```

### 2. Fix in Vercel Dashboard

**Go to:** https://vercel.com/dashboard

**Steps:**
1. Click your project name
2. Go to **Settings** tab
3. Click **General** in left sidebar
4. Find **Root Directory** section
5. Leave it BLANK or set to `.` (dot)
6. Click **Save**

### 3. Check Git Repository

**Make sure package.json is committed:**
```bash
git add package.json
git commit -m "Add package.json"
git push
```

### 4. Re-deploy

**In Vercel Dashboard:**
1. Go to **Deployments** tab
2. Click **Redeploy** on latest deployment
3. Check "Use existing Build Cache" = OFF
4. Click **Redeploy**

### 5. Alternative: Import Fresh

If still failing:
1. Delete project in Vercel
2. Re-import from GitHub
3. Make sure to select the correct repository
4. Leave Root Directory blank

## Quick Links
- Vercel Dashboard: https://vercel.com/dashboard
- GitHub Repository: Check your repo has package.json in root
- Deployment Logs: Click deployment → View Function Logs

## Still Not Working?
Check these common issues:
- Package.json is in a subfolder (move to root)
- Wrong repository selected in Vercel
- Root directory set incorrectly
- Files not committed to git