import React, { useState } from 'react';
import { MessageCircle, X, Smile, Anchor, Sword } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface ChatBot {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
}

const chatBots: ChatBot[] = [
  {
    id: 'marty',
    name: 'Marty Boomstick',
    icon: <Smile className="w-5 h-5" />,
    color: 'text-teal-600',
    bgColor: 'bg-teal-50'
  },
  {
    id: 'captain',
    name: 'Captain Wes',
    icon: <Anchor className="w-5 h-5" />,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    id: 'spartan',
    name: 'Spartan Don',
    icon: <Sword className="w-5 h-5" />,
    color: 'text-red-600',
    bgColor: 'bg-red-50'
  }
];

export const FloatingChatBots: React.FC = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [messages, setMessages] = useState<Record<string, Array<{text: string, isBot: boolean}>>>({});
  const [inputValue, setInputValue] = useState('');

  const handleSendMessage = (botId: string) => {
    if (!inputValue.trim()) return;
    
    const newMessages = {
      ...messages,
      [botId]: [
        ...(messages[botId] || []),
        { text: inputValue, isBot: false },
        { text: `Hey there! This is ${chatBots.find(b => b.id === botId)?.name}. Thanks for chatting!`, isBot: true }
      ]
    };
    setMessages(newMessages);
    setInputValue('');
  };

  if (isCollapsed) {
    return (
      <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-50">
        <Button
          onClick={() => setIsCollapsed(false)}
          className="rounded-full w-12 h-12 bg-blue-600 hover:bg-blue-700"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed right-4 top-1/2 transform -translate-y-1/2 z-50 space-y-2">
      <div className="flex justify-end mb-2">
        <Button
          onClick={() => setIsCollapsed(true)}
          variant="outline"
          size="sm"
          className="rounded-full w-8 h-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
      
      {chatBots.map((bot) => (
        <div key={bot.id} className="relative">
          <Button
            onClick={() => setActiveChat(activeChat === bot.id ? null : bot.id)}
            className={`rounded-full w-12 h-12 ${bot.bgColor} ${bot.color} hover:opacity-80`}
            variant="outline"
          >
            {bot.icon}
          </Button>
          
          {activeChat === bot.id && (
            <Card className="absolute right-14 top-0 w-80 h-96 p-4 shadow-lg">
              <div className="flex justify-between items-center mb-3">
                <h3 className={`font-semibold ${bot.color}`}>{bot.name}</h3>
                <Button
                  onClick={() => setActiveChat(null)}
                  variant="ghost"
                  size="sm"
                  className="w-6 h-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="h-64 overflow-y-auto mb-3 space-y-2">
                {(messages[bot.id] || []).map((msg, idx) => (
                  <div key={idx} className={`p-2 rounded text-sm ${
                    msg.isBot ? `${bot.bgColor} ${bot.color}` : 'bg-gray-100'
                  }`}>
                    {msg.text}
                  </div>
                ))}
              </div>
              
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Type a message..."
                  className="text-sm"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(bot.id)}
                />
                <Button
                  onClick={() => handleSendMessage(bot.id)}
                  size="sm"
                  className={bot.color}
                >
                  Send
                </Button>
              </div>
            </Card>
          )}
        </div>
      ))}
    </div>
  );
};