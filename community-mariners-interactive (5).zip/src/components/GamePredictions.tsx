import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Calendar, Target } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface Game {
  id: string;
  opponent: string;
  gameDate: Date;
  gameTime: string;
  canPredict: boolean;
  userPrediction?: 'win' | 'loss';
}

const GamePredictions: React.FC = () => {
  const { user } = useAuth();
  const [games, setGames] = useState<Game[]>([]);

  useEffect(() => {
    // Generate upcoming games
    const upcomingGames: Game[] = [
      {
        id: '1',
        opponent: 'Houston Astros',
        gameDate: new Date(Date.now() + 86400000),
        gameTime: '7:10 PM',
        canPredict: true
      },
      {
        id: '2', 
        opponent: 'Texas Rangers',
        gameDate: new Date(Date.now() + 2 * 86400000),
        gameTime: '7:10 PM',
        canPredict: true
      },
      {
        id: '3',
        opponent: 'Los Angeles Angels', 
        gameDate: new Date(Date.now() + 3 * 86400000),
        gameTime: '7:10 PM',
        canPredict: true
      }
    ];
    setGames(upcomingGames);
  }, []);

  const makePrediction = (gameId: string, prediction: 'win' | 'loss') => {
    if (!user) {
      toast.error('Please sign in to make predictions');
      return;
    }

    setGames(prev => prev.map(game => 
      game.id === gameId 
        ? { ...game, userPrediction: prediction }
        : game
    ));
    
    toast.success(`Prediction recorded: ${prediction.toUpperCase()}`);
  };

  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Make Your Predictions</h2>
        <p className="text-gray-600">Predict game outcomes up to 30 minutes before game time</p>
      </div>

      {games.map((game) => (
        <Card key={game.id} className="mb-4">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">vs {game.opponent}</CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="outline">
                  <Calendar className="w-4 h-4 mr-1" />
                  {game.gameDate.toLocaleDateString()}
                </Badge>
                <Badge variant="secondary">
                  <Clock className="w-4 h-4 mr-1" />
                  {game.gameTime}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {game.userPrediction ? (
              <div className="text-center py-4">
                <Target className="w-8 h-8 mx-auto mb-2 text-teal-600" />
                <p className="font-medium">Your prediction: 
                  <Badge className="ml-2" variant={game.userPrediction === 'win' ? 'default' : 'destructive'}>
                    {game.userPrediction.toUpperCase()}
                  </Badge>
                </p>
              </div>
            ) : (
              <div className="flex justify-center space-x-4">
                <Button 
                  onClick={() => makePrediction(game.id, 'win')}
                  className="bg-green-600 hover:bg-green-700"
                  disabled={!game.canPredict}
                >
                  Mariners WIN
                </Button>
                <Button 
                  onClick={() => makePrediction(game.id, 'loss')}
                  variant="destructive"
                  disabled={!game.canPredict}
                >
                  Mariners LOSE
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default GamePredictions;
export { GamePredictions };