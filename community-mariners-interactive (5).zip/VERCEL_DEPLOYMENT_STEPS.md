# Vercel Deployment - Step by Step Guide

## Step 1: Push Code to GitHub
1. Go to [GitHub.com](https://github.com) and create new repository
2. Name it `seattle-mariners-fan-site` 
3. Push your code:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/seattle-mariners-fan-site.git
git push -u origin main
```

## Step 2: Connect to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign up" and choose "Continue with GitHub"
3. Click "Import Project" or "New Project"
4. Select your `seattle-mariners-fan-site` repository
5. Click "Import"

## Step 3: Configure Build Settings
**CRITICAL: Set these exact settings in Vercel:**

### Build & Development Settings:
- **Framework Preset**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

### Environment Variables:
Click "Environment Variables" and add:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Step 4: Fix Build Issues
If build fails, add these to your project:

### Create vercel.json:
```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }],
  "buildCommand": "npm run build"
}
```

### Update package.json scripts:
```json
{
  "scripts": {
    "build": "tsc && vite build",
    "preview": "vite preview"
  }
}
```

## Step 5: Deploy
1. Click "Deploy" in Vercel
2. Wait for build to complete
3. Your site will be live at `https://your-project-name.vercel.app`

## Troubleshooting Links:
- [Vercel Build Errors](https://vercel.com/docs/concepts/deployments/build-step#build-errors)
- [Vite Deployment](https://vitejs.dev/guide/static-deploy.html#vercel)
- [Environment Variables](https://vercel.com/docs/concepts/projects/environment-variables)

## Quick Fix Commands:
```bash
# If build fails, run locally first:
npm install
npm run build

# Check for TypeScript errors:
npx tsc --noEmit
```