import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Target, Lock, Trophy, Calendar } from 'lucide-react';

const PredictionGames: React.FC = () => {
  const [predictions, setPredictions] = useState({
    runs: '',
    hits: '',
    strikeouts: ''
  });

  const games = [
    {
      level: 'Triple A',
      opponent: 'vs LAA',
      time: '7:10 PM PT',
      locked: false,
      categories: ['Runs Scored', 'Total Hits', 'Strikeouts']
    },
    {
      level: 'Double A', 
      opponent: 'Series vs TEX',
      time: 'Locked',
      locked: true,
      categories: ['Series Winner', 'Total Runs', 'MVP']
    }
  ];

  const leaderboard = [
    { rank: 1, name: 'SeaFan47', points: 1250, badge: '🏆' },
    { rank: 2, name: 'TridentKing', points: 1180, badge: '🥈' },
    { rank: 3, name: 'MarinerMania', points: 1150, badge: '🥉' },
    { rank: 4, name: 'You', points: 890, badge: '⭐' },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="h-5 w-5 mr-2 text-teal-600" />
            Prediction Games
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {games.map((game, index) => (
              <div key={index} className={`border rounded-lg p-4 ${game.locked ? 'bg-gray-50' : 'bg-white'}`}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <Badge variant={game.level === 'Triple A' ? 'default' : 'secondary'}>
                      {game.level}
                    </Badge>
                    <h4 className="font-semibold mt-1">{game.opponent}</h4>
                  </div>
                  <div className="text-right">
                    {game.locked ? (
                      <div className="flex items-center text-red-600">
                        <Lock className="h-4 w-4 mr-1" />
                        <span className="text-sm">Locked</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-green-600">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span className="text-sm">{game.time}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                {!game.locked && index === 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="runs">Mariners Runs</Label>
                      <Input
                        id="runs"
                        type="number"
                        placeholder="0-20"
                        value={predictions.runs}
                        onChange={(e) => setPredictions({...predictions, runs: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="hits">Total Hits</Label>
                      <Input
                        id="hits"
                        type="number"
                        placeholder="0-25"
                        value={predictions.hits}
                        onChange={(e) => setPredictions({...predictions, hits: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="strikeouts">Team Strikeouts</Label>
                      <Input
                        id="strikeouts"
                        type="number"
                        placeholder="0-20"
                        value={predictions.strikeouts}
                        onChange={(e) => setPredictions({...predictions, strikeouts: e.target.value})}
                      />
                    </div>
                  </div>
                )}
                
                {!game.locked && index === 0 && (
                  <Button className="mt-4 w-full bg-teal-600 hover:bg-teal-700">
                    Lock In Predictions
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Trophy className="h-5 w-5 mr-2 text-yellow-600" />
            Monthly Leaderboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {leaderboard.map((player) => (
              <div key={player.rank} className={`flex items-center justify-between p-2 rounded ${
                player.name === 'You' ? 'bg-teal-50 border border-teal-200' : 'hover:bg-gray-50'
              }`}>
                <div className="flex items-center space-x-3">
                  <span className="text-lg">{player.badge}</span>
                  <div>
                    <span className="font-medium">{player.name}</span>
                    {player.name === 'You' && <Badge className="ml-2" variant="outline">You</Badge>}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{player.points} pts</div>
                  <div className="text-sm text-gray-600">#{player.rank}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PredictionGames;