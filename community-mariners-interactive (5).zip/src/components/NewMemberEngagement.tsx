import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Star, Trophy, Users, MessageCircle, Target } from 'lucide-react';

const NewMemberEngagement: React.FC = () => {
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);

  const engagementTasks = [
    {
      id: 'profile',
      title: 'Complete Your Profile',
      description: 'Add your favorite player and team preferences',
      points: 50,
      icon: <Users className="h-5 w-5" />
    },
    {
      id: 'prediction',
      title: 'Make Your First Prediction',
      description: 'Join our prediction game for the next Mariners match',
      points: 100,
      icon: <Target className="h-5 w-5" />
    },
    {
      id: 'forum',
      title: 'Join Forum Discussion',
      description: 'Post in any forum thread or start your own',
      points: 75,
      icon: <MessageCircle className="h-5 w-5" />
    },
    {
      id: 'bot-chat',
      title: 'Chat with AI Bots',
      description: 'Have a conversation with Marty, Captain, or Spartan',
      points: 25,
      icon: <Star className="h-5 w-5" />
    }
  ];

  const handleTaskComplete = (taskId: string) => {
    if (!completedTasks.includes(taskId)) {
      setCompletedTasks([...completedTasks, taskId]);
    }
  };

  const totalPoints = completedTasks.reduce((sum, taskId) => {
    const task = engagementTasks.find(t => t.id === taskId);
    return sum + (task?.points || 0);
  }, 0);

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-yellow-600" />
          Welcome Challenge
          <Badge variant="secondary" className="ml-auto">
            {totalPoints} pts
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-muted-foreground mb-4">
          Complete these tasks to unlock features and earn your first TridentFans badges!
        </div>
        
        {engagementTasks.map((task) => {
          const isCompleted = completedTasks.includes(task.id);
          return (
            <div
              key={task.id}
              className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                isCompleted ? 'bg-green-50 border-green-200' : 'bg-muted/20'
              }`}
            >
              <div className={`flex-shrink-0 ${isCompleted ? 'text-green-600' : 'text-muted-foreground'}`}>
                {isCompleted ? <CheckCircle className="h-5 w-5" /> : task.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className={`font-medium text-sm ${isCompleted ? 'line-through text-muted-foreground' : ''}`}>
                  {task.title}
                </h4>
                <p className="text-xs text-muted-foreground mt-1">{task.description}</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  +{task.points} points
                </Badge>
              </div>
              {!isCompleted && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleTaskComplete(task.id)}
                  className="text-xs"
                >
                  Complete
                </Button>
              )}
            </div>
          );
        })}
        
        {completedTasks.length === engagementTasks.length && (
          <div className="text-center p-4 bg-gradient-to-r from-teal-50 to-blue-50 rounded-lg">
            <Trophy className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
            <h3 className="font-semibold text-green-700">Welcome Challenge Complete!</h3>
            <p className="text-sm text-green-600">You've earned the "TridentFans Rookie" badge!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default NewMemberEngagement;