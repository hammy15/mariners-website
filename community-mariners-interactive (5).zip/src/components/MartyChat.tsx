import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Bot, Compass, Sword, Send, ThumbsUp, ThumbsDown, BarChart3 } from 'lucide-react';
import { aiLearning, BOT_PERSONALITIES } from '@/lib/aiLearning';
import { ConversationAnalytics } from './ConversationAnalytics';

interface Message {
  id: string;
  content: string;
  isBot: boolean;
  botId?: string;
  timestamp: Date;
  topics?: string[];
  sentiment?: 'positive' | 'neutral' | 'negative';
  feedback?: 'positive' | 'negative';
}

export function MartyChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [activeBotId, setActiveBotId] = useState<string>('marty');
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const userId = 'user-' + Math.random().toString(36).substr(2, 9); // Simple user ID

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Generate daily greeting when bot is switched
    generateDailyGreeting();
  }, [activeBotId]);

  const generateDailyGreeting = () => {
    const bot = BOT_PERSONALITIES.find(b => b.id === activeBotId);
    if (!bot) return;

    const today = new Date().toDateString();
    const dayIndex = new Date().getDate() % bot.conversationStarters.length;
    const greeting = bot.conversationStarters[dayIndex];

    const greetingMessage: Message = {
      id: `greeting-${Date.now()}`,
      content: greeting,
      isBot: true,
      botId: activeBotId,
      timestamp: new Date(),
      topics: ['greeting'],
      sentiment: 'positive'
    };

    setMessages(prev => {
      // Remove previous greeting from same bot
      const filtered = prev.filter(m => !m.id.startsWith('greeting-'));
      return [...filtered, greetingMessage];
    });
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      content: input.trim(),
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Generate AI response
    setTimeout(() => {
      const response = aiLearning.generatePersonalizedResponse(activeBotId, input, userId);
      const topics = extractTopics(input);
      const sentiment = analyzeSentiment(input);

      const botMessage: Message = {
        id: `bot-${Date.now()}`,
        content: response,
        isBot: true,
        botId: activeBotId,
        timestamp: new Date(),
        topics,
        sentiment
      };

      setMessages(prev => [...prev, botMessage]);

      // Record conversation for learning
      aiLearning.recordConversation({
        userId,
        botId: activeBotId,
        message: input,
        response,
        timestamp: new Date(),
        topics,
        sentiment
      });

      setIsLoading(false);
    }, 1000);
  };

  const extractTopics = (message: string): string[] => {
    const topics = [];
    const lower = message.toLowerCase();
    if (lower.includes('roster') || lower.includes('player')) topics.push('roster');
    if (lower.includes('game') || lower.includes('score')) topics.push('games');
    if (lower.includes('stat') || lower.includes('number')) topics.push('statistics');
    if (lower.includes('trade') || lower.includes('deal')) topics.push('trades');
    if (lower.includes('season') || lower.includes('playoff')) topics.push('season');
    return topics;
  };

  const analyzeSentiment = (message: string): 'positive' | 'neutral' | 'negative' => {
    const positive = ['great', 'awesome', 'love', 'amazing', 'win', 'victory'];
    const negative = ['bad', 'terrible', 'hate', 'lose', 'disappointed'];
    const words = message.toLowerCase().split(' ');
    
    const posCount = words.filter(w => positive.includes(w)).length;
    const negCount = words.filter(w => negative.includes(w)).length;
    
    if (posCount > negCount) return 'positive';
    if (negCount > posCount) return 'negative';
    return 'neutral';
  };

  const handleFeedback = (messageId: string, feedback: 'positive' | 'negative') => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, feedback } : msg
    ));
  };

  const getBotIcon = (botId: string) => {
    switch (botId) {
      case 'marty': return <Bot className="h-4 w-4" />;
      case 'wes': return <Compass className="h-4 w-4" />;
      case 'don': return <Sword className="h-4 w-4" />;
      default: return <Bot className="h-4 w-4" />;
    }
  };

  const activeBot = BOT_PERSONALITIES.find(b => b.id === activeBotId);

  if (showAnalytics) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Conversation Analytics</CardTitle>
          <Button variant="outline" onClick={() => setShowAnalytics(false)}>
            Back to Chat
          </Button>
        </CardHeader>
        <CardContent>
          <ConversationAnalytics userId={userId} />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Card className="w-96 h-[500px] flex flex-col">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">TridentFans AI Chat</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAnalytics(true)}
            >
              <BarChart3 className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Bot Selection */}
          <div className="flex gap-2">
            {BOT_PERSONALITIES.map(bot => (
              <Button
                key={bot.id}
                variant={activeBotId === bot.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveBotId(bot.id)}
                className="flex items-center gap-1"
              >
                {getBotIcon(bot.id)}
                <span className="text-xs">{bot.name.split(' ')[0]}</span>
              </Button>
            ))}
          </div>

          {activeBot && (
            <div className="text-xs text-muted-foreground">
              <div className="font-medium">{activeBot.name}</div>
              <div className="flex gap-1 mt-1">
                {activeBot.specialties.slice(0, 2).map(specialty => (
                  <Badge key={specialty} variant="secondary" className="text-xs">
                    {specialty}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardHeader>

        <Separator />

        <CardContent className="flex-1 flex flex-col p-0">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[80%] rounded-lg p-3 ${
                    message.isBot 
                      ? 'bg-muted text-muted-foreground' 
                      : 'bg-primary text-primary-foreground'
                  }`}>
                    {message.isBot && (
                      <div className="flex items-center gap-1 mb-1">
                        {getBotIcon(message.botId || 'marty')}
                        <span className="text-xs font-medium">
                          {BOT_PERSONALITIES.find(b => b.id === message.botId)?.name.split(' ')[0]}
                        </span>
                      </div>
                    )}
                    <div className="text-sm">{message.content}</div>
                    
                    {message.topics && message.topics.length > 0 && (
                      <div className="flex gap-1 mt-2">
                        {message.topics.map(topic => (
                          <Badge key={topic} variant="outline" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    )}

                    {message.isBot && (
                      <div className="flex gap-1 mt-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleFeedback(message.id, 'positive')}
                          className={`h-6 w-6 p-0 ${message.feedback === 'positive' ? 'text-green-600' : ''}`}
                        >
                          <ThumbsUp className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleFeedback(message.id, 'negative')}
                          className={`h-6 w-6 p-0 ${message.feedback === 'negative' ? 'text-red-600' : ''}`}
                        >
                          <ThumbsDown className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg p-3">
                    <div className="flex items-center gap-2">
                      {getBotIcon(activeBotId)}
                      <div className="text-sm">Thinking...</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div ref={messagesEndRef} />
          </ScrollArea>

          <Separator />

          <div className="p-4">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Chat with ${activeBot?.name.split(' ')[0]}...`}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                disabled={isLoading}
              />
              <Button onClick={handleSendMessage} disabled={isLoading || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
