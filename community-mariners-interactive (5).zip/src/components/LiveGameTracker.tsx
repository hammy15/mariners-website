import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const LiveGameTracker = () => {
  const [liveGame, setLiveGame] = useState(null);
  const [gameStats, setGameStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLiveGame();
    const interval = setInterval(fetchLiveGame, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchLiveGame = async () => {
    try {
      // Call the real-time game data function
      const { data, error } = await supabase.functions.invoke('real-time-game-data', {
        body: { team: 'mariners' }
      });

      if (error) throw error;
      
      if (data?.game) {
        setLiveGame(data.game);
        setGameStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching live game:', error);
      // Mock data for development
      setLiveGame({
        opponent: "Houston Astros",
        inning: "7th",
        score: { mariners: 4, opponent: 3 },
        status: "In Progress",
        lastPlay: "Single to right field by Julio Rodriguez"
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-6">
        <div className="text-center">Loading live game data...</div>
      </Card>
    );
  }

  if (!liveGame) {
    return (
      <Card className="p-6">
        <div className="text-center text-gray-500">No live game currently</div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold">Live Game</h3>
        <Badge variant="destructive">LIVE</Badge>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="text-lg font-medium">Mariners vs {liveGame.opponent}</div>
          <div className="text-sm text-gray-500">{liveGame.inning} Inning</div>
        </div>

        <div className="flex justify-center items-center space-x-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600">{liveGame.score.mariners}</div>
            <div className="text-sm text-gray-600">Mariners</div>
          </div>
          <div className="text-2xl font-bold text-gray-400">-</div>
          <div className="text-center">
            <div className="text-3xl font-bold text-red-600">{liveGame.score.opponent}</div>
            <div className="text-sm text-gray-600">{liveGame.opponent}</div>
          </div>
        </div>

        {liveGame.lastPlay && (
          <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded">
            <div className="text-sm font-medium mb-1">Last Play:</div>
            <div className="text-sm text-gray-600">{liveGame.lastPlay}</div>
          </div>
        )}

        <Button className="w-full" onClick={fetchLiveGame}>
          Refresh
        </Button>
      </div>
    </Card>
  );
};

export default LiveGameTracker;