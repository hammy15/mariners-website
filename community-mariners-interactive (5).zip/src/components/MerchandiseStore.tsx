import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Star, Shirt, Coffee, Phone } from 'lucide-react';
import StorePaymentModal from './StorePaymentModal';

interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: 'apparel' | 'accessories' | 'collectibles';
  rating: number;
  inStock: boolean;
}

const MerchandiseStore: React.FC = () => {
  const [products] = useState<Product[]>([
    {
      id: '1',
      name: 'TridentFans Jersey',
      price: 89.99,
      image: '🎽',
      category: 'apparel',
      rating: 4.8,
      inStock: true
    },
    {
      id: '2',
      name: 'Mariners Coffee Mug',
      price: 19.99,
      image: '☕',
      category: 'accessories',
      rating: 4.5,
      inStock: true
    },
    {
      id: '3',
      name: 'Signed Baseball',
      price: 149.99,
      image: '⚾',
      category: 'collectibles',
      rating: 5.0,
      inStock: false
    },
    {
      id: '4',
      name: 'Team Cap',
      price: 34.99,
      image: '🧢',
      category: 'apparel',
      rating: 4.6,
      inStock: true
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [paymentModal, setPaymentModal] = useState<{
    isOpen: boolean;
    product?: Product;
  }>({ isOpen: false });

  const categories = [
    { id: 'all', name: 'All Items' },
    { id: 'apparel', name: 'Apparel' },
    { id: 'accessories', name: 'Accessories' },
    { id: 'collectibles', name: 'Collectibles' }
  ];

  const filteredProducts = products.filter(product => 
    selectedCategory === 'all' || product.category === selectedCategory
  );

  const handlePurchase = (product: Product) => {
    setPaymentModal({ isOpen: true, product });
  };

  const handlePaymentSuccess = () => {
    alert('Purchase successful! Your order will be shipped within 3-5 business days.');
    setPaymentModal({ isOpen: false });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'apparel': return <Shirt className="h-4 w-4" />;
      case 'accessories': return <Coffee className="h-4 w-4" />;
      case 'collectibles': return <Star className="h-4 w-4" />;
      default: return <ShoppingCart className="h-4 w-4" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <ShoppingCart className="mr-2 h-5 w-5" />
            TridentFans Store
          </span>
          <Badge variant="outline" className="text-teal-600">
            Free Shipping $50+
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2 mb-4">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="flex items-center gap-1"
            >
              {getCategoryIcon(category.id)}
              {category.name}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product) => (
            <div key={product.id} className="border rounded-lg p-3 hover:shadow-md transition-shadow">
              <div className="text-center mb-2">
                <div className="text-3xl mb-2">{product.image}</div>
                <h3 className="font-semibold text-sm">{product.name}</h3>
                <div className="flex items-center justify-center gap-1 text-xs text-gray-600 mb-1">
                  <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                  {product.rating}
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-lg font-bold text-teal-600 mb-2">
                  ${product.price}
                </div>
                
                {product.inStock ? (
                  <Button
                    size="sm"
                    className="w-full bg-teal-600 hover:bg-teal-700"
                    onClick={() => handlePurchase(product)}
                  >
                    Buy Now
                  </Button>
                ) : (
                  <Button size="sm" variant="outline" disabled className="w-full">
                    Out of Stock
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {paymentModal.product && (
          <StorePaymentModal
            isOpen={paymentModal.isOpen}
            onClose={() => setPaymentModal({ isOpen: false })}
            title={`Purchase: ${paymentModal.product.name}`}
            description="Official TridentFans merchandise with free shipping on orders over $50"
            amount={paymentModal.product.price}
            onSuccess={handlePaymentSuccess}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default MerchandiseStore;