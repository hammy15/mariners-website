import React from 'react';
import EnhancedNewsHub from '@/components/EnhancedNewsHub';

const NewsPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <EnhancedNewsHub />
    </div>
  );
};
export default NewsPage;