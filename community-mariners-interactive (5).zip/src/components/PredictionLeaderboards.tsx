import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const PredictionLeaderboards = () => {
  const [activeTab, setActiveTab] = useState('overall');
  const [leaderboards, setLeaderboards] = useState({
    overall: [],
    winLose: [],
    pitcherInnings: [],
    homeRuns: [],
    reliefPitchers: [],
    pitchCount: [],
    extraInnings: [],
    forumTossup: []
  });

  const tabs = [
    { id: 'overall', name: 'Overall Points', icon: '🏆' },
    { id: 'winLose', name: 'Win/Lose', icon: '⚾' },
    { id: 'pitcherInnings', name: 'Pitcher Innings', icon: '🥎' },
    { id: 'homeRuns', name: 'Home Runs', icon: '💥' },
    { id: 'reliefPitchers', name: 'Relief Pitchers', icon: '🎯' },
    { id: 'pitchCount', name: 'Pitch Count', icon: '📊' },
    { id: 'extraInnings', name: 'Extra Innings', icon: '⏰' },
    { id: 'forumTossup', name: 'Forum Tossup', icon: '🎲' }
  ];

  useEffect(() => {
    fetchLeaderboards();
  }, []);

  const fetchLeaderboards = async () => {
    try {
      // Mock data - in real app would fetch from database
      const mockData = {
        overall: [
          { rank: 1, user: 'PredictionKing', points: 2340, accuracy: '78%' },
          { rank: 2, user: 'MarinersOracle', points: 2180, accuracy: '76%' },
          { rank: 3, user: 'BaseballGuru', points: 2050, accuracy: '74%' },
          { rank: 4, user: 'SeattleFan', points: 1890, accuracy: '72%' },
          { rank: 5, user: 'TridentPower', points: 1750, accuracy: '70%' }
        ],
        winLose: [
          { rank: 1, user: 'WinPredictor', points: 450, accuracy: '85%' },
          { rank: 2, user: 'GameCaller', points: 420, accuracy: '82%' },
          { rank: 3, user: 'VictorySeeker', points: 380, accuracy: '79%' }
        ],
        pitcherInnings: [
          { rank: 1, user: 'PitchingExpert', points: 320, accuracy: '80%' },
          { rank: 2, user: 'InningsCounter', points: 290, accuracy: '76%' },
          { rank: 3, user: 'StartingRotation', points: 275, accuracy: '74%' }
        ],
        homeRuns: [
          { rank: 1, user: 'HomeRunHunter', points: 280, accuracy: '70%' },
          { rank: 2, user: 'PowerHitter', points: 260, accuracy: '68%' },
          { rank: 3, user: 'FenceClearing', points: 240, accuracy: '65%' }
        ],
        reliefPitchers: [
          { rank: 1, user: 'BullpenBoss', points: 190, accuracy: '63%' },
          { rank: 2, user: 'ReliefExpert', points: 175, accuracy: '61%' },
          { rank: 3, user: 'CloserCall', points: 160, accuracy: '58%' }
        ],
        pitchCount: [
          { rank: 1, user: 'PitchCounter', points: 210, accuracy: '75%' },
          { rank: 2, user: 'ThrowTracker', points: 195, accuracy: '72%' },
          { rank: 3, user: 'CountMaster', points: 180, accuracy: '69%' }
        ],
        extraInnings: [
          { rank: 1, user: 'ExtraInningsGuru', points: 150, accuracy: '60%' },
          { rank: 2, user: 'OvertimeOracle', points: 135, accuracy: '58%' },
          { rank: 3, user: 'BonusBaseball', points: 120, accuracy: '55%' }
        ],
        forumTossup: [
          { rank: 1, user: 'BotWhisperer', points: 95, accuracy: '48%' },
          { rank: 2, user: 'RandomRuler', points: 90, accuracy: '46%' },
          { rank: 3, user: 'LuckyGuesser', points: 85, accuracy: '44%' }
        ]
      };
      
      setLeaderboards(mockData);
    } catch (error) {
      console.error('Error fetching leaderboards:', error);
    }
  };

  const currentLeaderboard = leaderboards[activeTab] || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Prediction Leaderboards</h2>
        <Badge variant="secondary">Weekly Reset: Sunday MST</Badge>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2">
        {tabs.map(tab => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'outline'}
            onClick={() => setActiveTab(tab.id)}
            className="text-sm"
          >
            {tab.icon} {tab.name}
          </Button>
        ))}
      </div>

      {/* Leaderboard Display */}
      <Card className="p-6">
        <h3 className="text-xl font-semibold mb-4">
          {tabs.find(t => t.id === activeTab)?.name} Leaders
        </h3>
        
        <div className="space-y-3">
          {currentLeaderboard.map((user: any, index) => (
            <div 
              key={user.rank} 
              className={`flex justify-between items-center p-4 rounded-lg ${
                index === 0 ? 'bg-yellow-100 dark:bg-yellow-900/30 border-2 border-yellow-300' :
                index === 1 ? 'bg-gray-100 dark:bg-gray-800 border-2 border-gray-300' :
                index === 2 ? 'bg-orange-100 dark:bg-orange-900/30 border-2 border-orange-300' :
                'bg-gray-50 dark:bg-gray-800/50'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {index === 0 && <span className="text-2xl">🥇</span>}
                  {index === 1 && <span className="text-2xl">🥈</span>}
                  {index === 2 && <span className="text-2xl">🥉</span>}
                  {index > 2 && <Badge variant="outline">#{user.rank}</Badge>}
                </div>
                <span className="font-medium text-lg">{user.user}</span>
              </div>
              <div className="flex gap-6 text-sm">
                <div className="text-center">
                  <div className="font-semibold text-lg">{user.points}</div>
                  <div className="text-gray-500">Points</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-lg">{user.accuracy}</div>
                  <div className="text-gray-500">Accuracy</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {currentLeaderboard.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No predictions yet for this category
          </div>
        )}
      </Card>

      {/* Points System */}
      <Card className="p-6 bg-blue-50 dark:bg-blue-900/20">
        <h3 className="text-lg font-semibold mb-3">Points System</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <h4 className="font-medium mb-2">Standard Categories (10 pts each):</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Win/Lose Prediction</li>
              <li>• Pitcher Innings (5+ or Under)</li>
              <li>• Pitch Count (Over/Under 80)</li>
              <li>• Extra Innings (Yes/No)</li>
            </ul>
          </div>
          <div>
            <h4 className="font-medium mb-2">Advanced Categories:</h4>
            <ul className="space-y-1 text-gray-600">
              <li>• Home Run Player (15 pts)</li>
              <li>• Relief Pitchers (5 pts each)</li>
              <li>• Forum Tossup (5 pts)</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default PredictionLeaderboards;