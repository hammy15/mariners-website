import React, { useState, useEffect } from 'react';
import { Card, Button, Input, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const AdminBotSettings = () => {
  const [botSettings, setBotSettings] = useState({
    marty: {
      personality: "I'm Marty, the enthusiastic Mariners superfan! I love analyzing stats, making bold predictions, and cheering on our team with unwavering optimism. Let's go M's!",
      autopick: true,
      accuracy: '74%'
    },
    captain: {
      personality: "I'm Captain, the strategic leader of this crew. I approach predictions with naval precision and tactical analysis. Steady as she goes, mateys!",
      autopick: true,
      accuracy: '71%'
    },
    spartan: {
      personality: "I'm Spartan, the disciplined warrior of predictions. I analyze every detail with military precision and never back down from a challenge. Victory or death!",
      autopick: true,
      accuracy: '69%'
    }
  });

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [saveStatus, setSaveStatus] = useState('');

  const handleLogin = () => {
    if (loginForm.username === 'Captain' && loginForm.password === '!!Hammy11') {
      setIsAuthenticated(true);
      setSaveStatus('Login successful!');
      setTimeout(() => setSaveStatus(''), 3000);
    } else {
      setSaveStatus('Invalid credentials');
      setTimeout(() => setSaveStatus(''), 3000);
    }
  };

  const handleSaveSettings = async () => {
    try {
      // In real app, would save to database
      setSaveStatus('Settings saved successfully!');
      setTimeout(() => setSaveStatus(''), 3000);
    } catch (error) {
      setSaveStatus('Error saving settings');
      setTimeout(() => setSaveStatus(''), 3000);
    }
  };

  const updateBotSetting = (bot: string, field: string, value: any) => {
    setBotSettings(prev => ({
      ...prev,
      [bot]: {
        ...prev[bot],
        [field]: value
      }
    }));
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto mt-20">
        <Card className="p-8">
          <h2 className="text-2xl font-bold mb-6 text-center">Admin Login</h2>
          <div className="space-y-4">
            <Input
              placeholder="Username"
              value={loginForm.username}
              onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
            />
            <Input
              type="password"
              placeholder="Password"
              value={loginForm.password}
              onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
            />
            <Button onClick={handleLogin} className="w-full">
              Login
            </Button>
            {saveStatus && (
              <div className={`text-center text-sm ${
                saveStatus.includes('successful') ? 'text-green-600' : 'text-red-600'
              }`}>
                {saveStatus}
              </div>
            )}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI Bot Management</h2>
        <Badge variant="secondary">Super Admin: Captain</Badge>
      </div>

      {/* Marty Settings */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">🤖</span>
          <h3 className="text-xl font-bold">Marty Settings</h3>
          <Badge variant="outline">Accuracy: {botSettings.marty.accuracy}</Badge>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Personality Prompt</label>
            <textarea
              className="w-full p-3 border rounded-lg resize-none h-24 bg-white dark:bg-gray-800"
              value={botSettings.marty.personality}
              onChange={(e) => updateBotSetting('marty', 'personality', e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="marty-autopick"
              checked={botSettings.marty.autopick}
              onChange={(e) => updateBotSetting('marty', 'autopick', e.target.checked)}
            />
            <label htmlFor="marty-autopick">Auto-pick predictions (30 min before game)</label>
          </div>
        </div>
      </Card>

      {/* Captain Settings */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">⚓</span>
          <h3 className="text-xl font-bold">Captain Settings</h3>
          <Badge variant="outline">Accuracy: {botSettings.captain.accuracy}</Badge>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Personality Prompt</label>
            <textarea
              className="w-full p-3 border rounded-lg resize-none h-24 bg-white dark:bg-gray-800"
              value={botSettings.captain.personality}
              onChange={(e) => updateBotSetting('captain', 'personality', e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="captain-autopick"
              checked={botSettings.captain.autopick}
              onChange={(e) => updateBotSetting('captain', 'autopick', e.target.checked)}
            />
            <label htmlFor="captain-autopick">Auto-pick predictions (5 min before game)</label>
          </div>
        </div>
      </Card>

      {/* Spartan Settings */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">🛡️</span>
          <h3 className="text-xl font-bold">Spartan Settings</h3>
          <Badge variant="outline">Accuracy: {botSettings.spartan.accuracy}</Badge>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Personality Prompt</label>
            <textarea
              className="w-full p-3 border rounded-lg resize-none h-24 bg-white dark:bg-gray-800"
              value={botSettings.spartan.personality}
              onChange={(e) => updateBotSetting('spartan', 'personality', e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="spartan-autopick"
              checked={botSettings.spartan.autopick}
              onChange={(e) => updateBotSetting('spartan', 'autopick', e.target.checked)}
            />
            <label htmlFor="spartan-autopick">Auto-pick predictions (5 min before game)</label>
          </div>
        </div>
      </Card>

      <div className="flex justify-between items-center">
        <Button onClick={handleSaveSettings} className="bg-blue-600 hover:bg-blue-700">
          Save All Settings
        </Button>
        
        {saveStatus && (
          <div className={`text-sm ${
            saveStatus.includes('successful') ? 'text-green-600' : 'text-red-600'
          }`}>
            {saveStatus}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminBotSettings;