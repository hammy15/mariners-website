import React from 'react';

// Enhanced Card with gradient effects
export const GradientCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  gradient?: string;
}> = ({ children, className = '', gradient = 'from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-900' }) => (
  <div className={`bg-gradient-to-br ${gradient} rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 ${className}`}>
    {children}
  </div>
);

// Animated Badge
export const AnimatedBadge: React.FC<{
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'success' | 'warning';
  pulse?: boolean;
}> = ({ children, variant = 'primary', pulse = false }) => {
  const variants = {
    primary: 'bg-blue-500 text-white',
    secondary: 'bg-gray-500 text-white',
    success: 'bg-green-500 text-white',
    warning: 'bg-yellow-500 text-black'
  };

  return (
    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${variants[variant]} ${
      pulse ? 'animate-pulse' : ''
    }`}>
      {children}
    </span>
  );
};

// Glowing Button
export const GlowButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'success' | 'warning';
  disabled?: boolean;
}> = ({ children, onClick, variant = 'primary', disabled = false }) => {
  const variants = {
    primary: 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/25',
    success: 'bg-green-600 hover:bg-green-700 shadow-green-500/25',
    warning: 'bg-yellow-600 hover:bg-yellow-700 shadow-yellow-500/25'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`px-6 py-3 rounded-lg font-semibold text-white transition-all duration-300 transform hover:scale-105 hover:shadow-lg ${variants[variant]} ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-xl'
      }`}
    >
      {children}
    </button>
  );
};

// Stats Counter with animation
export const AnimatedCounter: React.FC<{
  value: number;
  label: string;
  icon?: string;
}> = ({ value, label, icon }) => (
  <div className="text-center p-4">
    <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 animate-pulse">
      {icon && <span className="mr-2">{icon}</span>}
      {value.toLocaleString()}
    </div>
    <div className="text-sm text-gray-600 dark:text-gray-400 font-medium">
      {label}
    </div>
  </div>
);

// Progress Bar with glow effect
export const GlowProgress: React.FC<{
  value: number;
  max: number;
  color?: string;
  label?: string;
}> = ({ value, max, color = 'blue', label }) => {
  const percentage = (value / max) * 100;
  
  return (
    <div className="w-full">
      {label && <div className="text-sm font-medium mb-2">{label}</div>}
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
        <div
          className={`h-full bg-${color}-500 rounded-full transition-all duration-1000 ease-out shadow-lg shadow-${color}-500/50`}
          style={{ width: `${percentage}%` }}
        />
      </div>
      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
        {value} / {max} ({percentage.toFixed(1)}%)
      </div>
    </div>
  );
};

const EnhancedVisualComponents: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <GradientCard className="p-6">
        <AnimatedCounter value={1247} label="Active Fans" icon="👥" />
      </GradientCard>
      
      <GradientCard className="p-6">
        <AnimatedCounter value={89} label="Predictions Made" icon="🎯" />
      </GradientCard>
      
      <GradientCard className="p-6">
        <AnimatedCounter value={156} label="Forum Posts" icon="💬" />
      </GradientCard>
      
      <GradientCard className="p-6 md:col-span-2 lg:col-span-3">
        <GlowProgress value={75} max={100} color="blue" label="Season Progress" />
      </GradientCard>
    </div>
  );
};

export default EnhancedVisualComponents;