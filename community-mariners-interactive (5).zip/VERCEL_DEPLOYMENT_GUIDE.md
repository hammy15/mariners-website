# Complete Vercel Deployment Guide

## Prerequisites
- GitHub account
- Vercel account (free tier is sufficient)
- Domain name (optional, Vercel provides free subdomain)

## Step 1: Prepare Your Repository

### 1.1 Push to GitHub
```bash
git add .
git commit -m "Final deployment preparation"
git push origin main
```

### 1.2 Verify Build Configuration
Ensure these files exist in your project root:
- `package.json` ✓
- `vite.config.ts` ✓
- `vercel.json` ✓

## Step 2: Deploy to Vercel

### 2.1 Connect GitHub Repository
1. Go to [vercel.com](https://vercel.com)
2. Sign in with GitHub
3. Click "New Project"
4. Import your repository
5. Configure project settings:
   - Framework Preset: **Vite**
   - Root Directory: **.**
   - Build Command: `npm run build`
   - Output Directory: `dist`

### 2.2 Environment Variables
Add these environment variables in Vercel dashboard:

**Required for Supabase:**
```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

**Optional API Keys (for full functionality):**
```
VITE_RAPIDAPI_KEY=your_rapidapi_key
VITE_SPORTSDATA_IO_API_KEY=your_sportsdata_key
VITE_OPENAI_API_KEY=your_openai_key
VITE_SENDGRID_API_KEY=your_sendgrid_key
VITE_STRIPE_PUBLISHABLE_KEY=your_stripe_key
```

### 2.3 Deploy
1. Click "Deploy"
2. Wait for build to complete (2-3 minutes)
3. Your app will be live at `https://your-project-name.vercel.app`

## Step 3: Configure Custom Domain (Optional)

### 3.1 Add Domain in Vercel
1. Go to Project Settings → Domains
2. Add your custom domain
3. Configure DNS records as shown

### 3.2 DNS Configuration
Add these records to your domain provider:
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com

Type: A
Name: @
Value: 76.76.19.61
```

## Step 4: Verify Deployment

### 4.1 Test Core Features
- [ ] Homepage loads correctly
- [ ] User authentication works
- [ ] Database connections are active
- [ ] API integrations function
- [ ] Admin panel accessible

### 4.2 Check System Health
1. Navigate to `/admin` (requires super admin access)
2. Go to "System Health" tab
3. Verify all systems show "Healthy" status

## Step 5: Post-Deployment Configuration

### 5.1 Supabase Settings
1. Update Supabase Auth settings:
   - Site URL: `https://your-domain.com`
   - Redirect URLs: `https://your-domain.com/**`

### 5.2 Enable RLS Policies
Run this SQL in Supabase SQL Editor:
```sql
-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;

-- Create basic policies
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = user_id);
```

## Troubleshooting

### Build Errors
- Check Node.js version (use Node 18+)
- Verify all dependencies in package.json
- Check for TypeScript errors

### Runtime Errors
- Verify environment variables are set
- Check Supabase connection in browser console
- Test API endpoints individually

### Domain Issues
- DNS propagation can take 24-48 hours
- Use DNS checker tools to verify records
- Ensure SSL certificate is active

## Monitoring and Maintenance

### 5.1 Set Up Monitoring
- Enable Vercel Analytics
- Monitor function logs
- Set up error tracking

### 5.2 Regular Updates
- Update dependencies monthly
- Monitor Supabase usage
- Review and rotate API keys quarterly

## Support Resources
- Vercel Documentation: https://vercel.com/docs
- Supabase Documentation: https://supabase.com/docs
- Project Support: Navigate to `/support` in your deployed app

## Quick Commands
```bash
# Local development
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Deploy to Vercel (if using CLI)
vercel --prod
```

Your Seattle Mariners fan site is now live and ready for users!