import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, MessageCircle, TrendingUp, Clock } from 'lucide-react';

interface ForumThread {
  id: string;
  title: string;
  author: string;
  replies: number;
  lastActivity: string;
  isHot: boolean;
}

const TempCheckForum: React.FC = () => {
  const [showNewThread, setShowNewThread] = useState(false);
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [newThreadContent, setNewThreadContent] = useState('');

  const threads: ForumThread[] = [
    { id: '1', title: 'What do you think about the new batting coach?', author: 'MarinerMagic', replies: 23, lastActivity: '5m ago', isHot: true },
    { id: '2', title: 'Best seats for families at T-Mobile Park?', author: 'FamilyFan', replies: 15, lastActivity: '12m ago', isHot: false },
    { id: '3', title: 'Predictions for this weekend series', author: 'BaseballBuff', replies: 31, lastActivity: '18m ago', isHot: true },
    { id: '4', title: 'Anyone going to the game tonight?', author: 'SeattleSuper', replies: 8, lastActivity: '25m ago', isHot: false },
  ];

  const handleCreateThread = () => {
    if (newThreadTitle.trim() && newThreadContent.trim()) {
      // In real app, send to backend
      setNewThreadTitle('');
      setNewThreadContent('');
      setShowNewThread(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center space-x-2">
            <MessageCircle className="w-5 h-5" />
            <span>Temp Check</span>
          </CardTitle>
          <Button onClick={() => setShowNewThread(!showNewThread)} size="sm">
            <Plus className="w-4 h-4 mr-1" />
            New Thread
          </Button>
        </div>
        <p className="text-sm text-gray-600">Open discussions • Resets weekly</p>
      </CardHeader>
      <CardContent>
        {showNewThread && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="space-y-4">
                <Input
                  placeholder="Thread title..."
                  value={newThreadTitle}
                  onChange={(e) => setNewThreadTitle(e.target.value)}
                />
                <Textarea
                  placeholder="Start the conversation..."
                  value={newThreadContent}
                  onChange={(e) => setNewThreadContent(e.target.value)}
                  rows={3}
                />
                <div className="flex space-x-2">
                  <Button onClick={handleCreateThread} size="sm">Create Thread</Button>
                  <Button variant="outline" onClick={() => setShowNewThread(false)} size="sm">Cancel</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-3">
          {threads
            .sort((a, b) => (b.isHot ? 1 : 0) - (a.isHot ? 1 : 0))
            .map((thread) => (
              <div key={thread.id} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-sm flex items-center space-x-2">
                    <span>{thread.title}</span>
                    {thread.isHot && (
                      <Badge variant="destructive" className="text-xs">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        Hot
                      </Badge>
                    )}
                  </h3>
                </div>
                <div className="flex justify-between items-center text-xs text-gray-500">
                  <span>by {thread.author}</span>
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center space-x-1">
                      <MessageCircle className="w-3 h-3" />
                      <span>{thread.replies}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{thread.lastActivity}</span>
                    </span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TempCheckForum;