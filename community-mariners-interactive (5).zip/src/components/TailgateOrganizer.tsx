import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { MapPin, Users, Calendar, Plus, Clock } from 'lucide-react';

interface TailgateEvent {
  id: string;
  title: string;
  organizer: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  maxAttendees: number;
  gameVs: string;
  description: string;
}

const TailgateOrganizer: React.FC = () => {
  const [events] = useState<TailgateEvent[]>([
    {
      id: '1',
      title: 'Pre-Game BBQ Bash',
      organizer: 'SeattleBBQKing',
      date: '2024-08-15',
      time: '4:00 PM',
      location: 'Lot 1, Section A',
      attendees: 12,
      maxAttendees: 20,
      gameVs: 'Angels',
      description: 'Bringing the grill and fixings! BYOB and side dishes welcome.'
    },
    {
      id: '2',
      title: 'Mariners Trivia & Tailgate',
      organizer: 'TridentTrivia',
      date: '2024-08-18',
      time: '3:30 PM',
      location: 'Lot 3, Near Gate',
      attendees: 8,
      maxAttendees: 15,
      gameVs: 'Astros',
      description: 'Test your M\'s knowledge while we prep for the big game!'
    },
    {
      id: '3',
      title: 'Family Fun Tailgate',
      organizer: 'MarinersMom',
      date: '2024-08-22',
      time: '5:00 PM',
      location: 'Family Lot',
      attendees: 6,
      maxAttendees: 25,
      gameVs: 'Rangers',
      description: 'Kid-friendly activities, face painting, and great food!'
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);

  const getAvailabilityColor = (attendees: number, max: number) => {
    const ratio = attendees / max;
    if (ratio < 0.5) return 'text-green-600';
    if (ratio < 0.8) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Users className="mr-2 h-5 w-5" />
            Tailgate Meetups
          </span>
          <Button 
            size="sm" 
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="bg-teal-600 hover:bg-teal-700"
          >
            <Plus className="mr-2 h-4 w-4" />
            Create Event
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {showCreateForm && (
          <div className="mb-6 p-4 border rounded-lg bg-gray-50">
            <h3 className="font-semibold mb-3">Create New Tailgate Event</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Input placeholder="Event title" />
              <Input placeholder="vs. Team" />
              <Input type="date" />
              <Input type="time" />
              <Input placeholder="Location/Lot" />
              <Input type="number" placeholder="Max attendees" />
            </div>
            <div className="mt-3 flex space-x-2">
              <Button size="sm" className="bg-teal-600 hover:bg-teal-700">Create</Button>
              <Button size="sm" variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold">{event.title}</h3>
                  <p className="text-sm text-gray-600">vs. {event.gameVs}</p>
                </div>
                <Badge variant="outline">
                  {event.attendees}/{event.maxAttendees}
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3 text-sm">
                <div className="flex items-center text-gray-600">
                  <Calendar className="mr-2 h-4 w-4" />
                  {new Date(event.date).toLocaleDateString()}
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock className="mr-2 h-4 w-4" />
                  {event.time}
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="mr-2 h-4 w-4" />
                  {event.location}
                </div>
              </div>

              <p className="text-sm text-gray-700 mb-3">{event.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  Organized by {event.organizer}
                </span>
                <div className="flex space-x-2">
                  <span className={`text-sm font-semibold ${getAvailabilityColor(event.attendees, event.maxAttendees)}`}>
                    {event.maxAttendees - event.attendees} spots left
                  </span>
                  <Button size="sm" variant="outline">
                    Join Event
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TailgateOrganizer;