import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Radio, Clock, TrendingUp, MessageCircle } from 'lucide-react';

interface ForumTopic {
  topic: string;
  messages: number;
  sentiment: 'positive' | 'negative' | 'mixed';
}

const ForumDigest: React.FC = () => {
  const [digest, setDigest] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>('');

  const generateDigest = async () => {
    setIsLoading(true);
    try {
      // Mock forum topics for demo
      const mockTopics: ForumTopic[] = [
        { topic: "Julio Rodriguez batting average", messages: 47, sentiment: "positive" },
        { topic: "Trade deadline speculation", messages: 32, sentiment: "mixed" },
        { topic: "Pitching rotation concerns", messages: 28, sentiment: "negative" },
        { topic: "T-Mobile Park atmosphere", messages: 19, sentiment: "positive" }
      ];

      const totalMessages = mockTopics.reduce((sum, t) => sum + t.messages, 0);
      const topTopic = mockTopics[0];
      
      const openings = [
        "🎙️ Good evening TridentFans! Here's your midnight forum roundup...",
        "📻 Coming to you live from the digital dugout...",
        "🏟️ The forum lights are still on, and here's what's buzzing..."
      ];
      
      const opening = openings[Math.floor(Math.random() * openings.length)];
      
      const generatedDigest = `${opening}

📊 TONIGHT'S FORUM STATS:
• ${totalMessages} total messages across ${mockTopics.length} hot topics
• Leading discussion: "${topTopic.topic}" with ${topTopic.messages} messages
• Community mood: Optimistic ✨

🔥 TOP CONVERSATIONS:
${mockTopics.slice(0, 3).map((t, i) => 
  `${i + 1}. ${t.topic} (${t.messages} msgs) - ${getSentimentEmoji(t.sentiment)}`
).join('\n')}

The TridentFans community never sleeps! See you tomorrow for more Mariners magic! ⚾️`;

      setDigest(generatedDigest);
      setLastUpdate(new Date().toLocaleString());
    } catch (error) {
      console.error('Error generating digest:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getSentimentEmoji = (sentiment: string) => {
    switch(sentiment) {
      case 'positive': return '😊';
      case 'negative': return '😤';
      case 'mixed': return '🤔';
      default: return '💭';
    }
  };

  useEffect(() => {
    generateDigest();
  }, []);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Radio className="h-5 w-5 text-teal-600" />
          Mariners Forum Digest
          <Badge variant="secondary" className="ml-auto">Live</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            Last update: {lastUpdate || 'Never'}
          </div>
          <Button 
            size="sm" 
            onClick={generateDigest} 
            disabled={isLoading}
            className="bg-teal-600 hover:bg-teal-700"
          >
            {isLoading ? 'Generating...' : 'Refresh Digest'}
          </Button>
        </div>
        
        {digest && (
          <div className="bg-muted/30 rounded-lg p-4">
            <pre className="whitespace-pre-wrap text-sm font-mono">
              {digest}
            </pre>
          </div>
        )}
        
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <MessageCircle className="h-3 w-3" />
            Auto-updates at midnight
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Sports announcer style
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ForumDigest;