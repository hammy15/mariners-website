import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, MessageCircle, Clock, Mic } from 'lucide-react';

interface PodcastEpisode {
  id: string;
  title: string;
  podcast: string;
  duration: string;
  publishDate: string;
  description: string;
  isPlaying: boolean;
  comments: number;
  category: string;
}

const PodcastHub: React.FC = () => {
  const [episodes, setEpisodes] = useState<PodcastEpisode[]>([
    {
      id: '1',
      title: 'Trade Deadline Breakdown: What\'s Next for the M\'s?',
      podcast: 'Trident Talk',
      duration: '45:32',
      publishDate: '2 days ago',
      description: 'Deep dive into potential moves and roster construction for the playoff push.',
      isPlaying: false,
      comments: 23,
      category: 'Analysis'
    },
    {
      id: '2',
      title: 'Julio\'s MVP Case & Rookie Comparisons',
      podcast: 'Mariners Mindset',
      duration: '38:15',
      publishDate: '1 day ago',
      description: 'Breaking down Julio Rodriguez\'s incredible season and historical context.',
      isPlaying: false,
      comments: 18,
      category: 'Player Focus'
    },
    {
      id: '3',
      title: 'Fan Roundtable: Stadium Experience & Traditions',
      podcast: 'From the Stands',
      duration: '52:08',
      publishDate: '6 hours ago',
      description: 'Long-time fans share their favorite T-Mobile Park memories and traditions.',
      isPlaying: false,
      comments: 31,
      category: 'Fan Stories'
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState('all');
  const categories = ['all', 'Analysis', 'Player Focus', 'Fan Stories', 'History'];

  const togglePlay = (episodeId: string) => {
    setEpisodes(episodes.map(ep => ({
      ...ep,
      isPlaying: ep.id === episodeId ? !ep.isPlaying : false
    })));
  };

  const filteredEpisodes = episodes.filter(episode =>
    selectedCategory === 'all' || episode.category === selectedCategory
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Mic className="mr-2 h-5 w-5" />
            Podcast Hub
          </span>
          <Button size="sm" variant="outline">
            Submit Podcast
          </Button>
        </CardTitle>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="capitalize"
            >
              {category}
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {filteredEpisodes.map((episode) => (
            <div key={episode.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => togglePlay(episode.id)}
                  className="mt-1 flex-shrink-0"
                >
                  {episode.isPlaying ? 
                    <Pause className="h-4 w-4" /> : 
                    <Play className="h-4 w-4" />
                  }
                </Button>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-semibold text-sm leading-tight">{episode.title}</h3>
                      <p className="text-xs text-gray-600 mt-1">{episode.podcast}</p>
                    </div>
                    <Badge variant="secondary" className="ml-2 flex-shrink-0">
                      {episode.category}
                    </Badge>
                  </div>
                  
                  <p className="text-sm text-gray-700 mb-3">{episode.description}</p>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-3">
                      <span className="flex items-center">
                        <Clock className="mr-1 h-3 w-3" />
                        {episode.duration}
                      </span>
                      <span>{episode.publishDate}</span>
                    </div>
                    
                    <button className="flex items-center space-x-1 hover:text-blue-600">
                      <MessageCircle className="h-3 w-3" />
                      <span>{episode.comments} comments</span>
                    </button>
                  </div>
                  
                  {episode.isPlaying && (
                    <div className="mt-3 p-2 bg-blue-50 rounded text-xs text-blue-700">
                      Now playing... (This would integrate with audio player)
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-teal-50 rounded-lg">
          <h4 className="font-semibold text-teal-800 mb-2">Featured: Weekly Trident Talk Live</h4>
          <p className="text-sm text-teal-700 mb-3">
            Join us every Wednesday at 7 PM for live discussion and fan Q&A!
          </p>
          <Button size="sm" className="bg-teal-600 hover:bg-teal-700">
            Set Reminder
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PodcastHub;