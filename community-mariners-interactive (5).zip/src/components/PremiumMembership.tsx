import React, { useState } from 'react';
import { Crown, Heart, Zap, Star, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import PaymentModal from './PaymentModal';

const PremiumMembership: React.FC = () => {
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedTier, setSelectedTier] = useState<'supporter' | 'champion' | null>(null);
  const [customAmount, setCustomAmount] = useState('');

  const handleDonate = (tier: 'supporter' | 'champion', amount?: number) => {
    setSelectedTier(tier);
    setPaymentModalOpen(true);
  };

  const tiers = [
    {
      id: 'free',
      name: 'Free Fan',
      price: 'Free',
      badge: 'Fan',
      badgeColor: 'bg-gray-500',
      icon: <Star className="w-6 h-6" />,
      description: 'Join the TridentFans community',
      features: [
        'Access to live scores and news',
        'Basic predictions and forum access',
        'Team customization',
        'Chat with Marty'
      ],
      perks: 'Referred to as: "Fan"'
    },
    {
      id: 'supporter',
      name: 'Site Supporter',
      price: '$5/month',
      badge: 'Supporter',
      badgeColor: 'bg-blue-600',
      icon: <Heart className="w-6 h-6" />,
      description: 'Help keep TridentFans running',
      features: [
        'Everything in Free',
        'Supporter badge on all posts',
        'Priority in forum discussions',
        'Early access to new features'
      ],
      perks: 'Referred to as: "Loyal Supporter" with special blue badge'
    },
    {
      id: 'champion',
      name: 'Site Champion',
      price: 'Custom Amount',
      badge: 'Champion',
      badgeColor: 'bg-gradient-to-r from-yellow-400 to-orange-500',
      icon: <Crown className="w-6 h-6" />,
      description: 'Help add new features and keep us growing',
      features: [
        'Everything in Supporter',
        'Exclusive Champion badge',
        'Direct input on new features',
        'Special recognition in community',
        'Custom donation amount'
      ],
      perks: 'Referred to as: "TridentFans Champion" with golden crown badge and special privileges'
    }
  ];

  return (
    <>
      <div className="py-12">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Support TridentFans</h2>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            TridentFans is free for everyone! Help us keep the lights on and add amazing new features 
            by becoming a supporter. Every contribution helps our community grow stronger.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {tiers.map((tier) => (
            <Card 
              key={tier.id} 
              className={`relative ${tier.id === 'champion' ? 'border-2 border-yellow-400 shadow-lg' : ''}`}
            >
              {tier.id === 'champion' && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black">
                    <Zap className="w-3 h-3 mr-1" />
                    Most Impact
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <div className="flex justify-center mb-2">
                  <div className={`p-3 rounded-full ${tier.badgeColor} text-white`}>
                    {tier.icon}
                  </div>
                </div>
                <CardTitle className="text-xl">{tier.name}</CardTitle>
                <div className="text-2xl font-bold text-blue-600">{tier.price}</div>
                <CardDescription>{tier.description}</CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3 mb-6">
                  {tier.features.map((feature, index) => (
                    <div key={index} className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                      {feature}
                    </div>
                  ))}
                </div>
                
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg mb-4">
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    {tier.perks}
                  </p>
                </div>

                {tier.id === 'free' ? (
                  <Button variant="outline" className="w-full" disabled>
                    Current Plan
                  </Button>
                ) : tier.id === 'champion' ? (
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="custom-amount">Custom Amount ($)</Label>
                      <Input
                        id="custom-amount"
                        type="number"
                        min="10"
                        placeholder="Enter amount (min $10)"
                        value={customAmount}
                        onChange={(e) => setCustomAmount(e.target.value)}
                      />
                    </div>
                    <Button 
                      className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black"
                      onClick={() => handleDonate('champion', parseInt(customAmount))}
                      disabled={!customAmount || parseInt(customAmount) < 10}
                    >
                      <Crown className="w-4 h-4 mr-2" />
                      Become a Champion
                    </Button>
                  </div>
                ) : (
                  <Button 
                    className="w-full"
                    onClick={() => handleDonate('supporter')}
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Support for $5/month
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-8">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            <Gift className="w-4 h-4 inline mr-1" />
            All donations help fund server costs, new features, and community growth. Thank you for your support!
          </p>
        </div>
      </div>

      <PaymentModal 
        open={paymentModalOpen} 
        onOpenChange={setPaymentModalOpen}
        tier={selectedTier}
        customAmount={selectedTier === 'champion' ? parseInt(customAmount) : undefined}
      />
    </>
  );
};

export default PremiumMembership;