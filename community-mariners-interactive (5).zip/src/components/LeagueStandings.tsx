import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Trophy } from 'lucide-react';

const LeagueStandings: React.FC = () => {
  const standings = [
    { team: 'Houston Astros', wins: 90, losses: 72, gb: '-' },
    { team: 'Seattle Mariners', wins: 88, losses: 74, gb: '2.0' },
    { team: 'Texas Rangers', wins: 78, losses: 84, gb: '12.0' },
    { team: 'Los Angeles Angels', wins: 63, losses: 99, gb: '27.0' },
    { team: 'Oakland Athletics', wins: 50, losses: 112, gb: '40.0' }
  ];

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Trophy className="h-5 w-5" />
          AL West Standings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {standings.map((team, idx) => (
            <div 
              key={idx} 
              className={`flex justify-between items-center p-2 rounded text-sm ${
                team.team === 'Seattle Mariners' ? 'bg-blue-50 dark:bg-blue-950' : 'bg-muted/30'
              }`}
            >
              <span className={team.team === 'Seattle Mariners' ? 'font-semibold' : ''}>
                {idx + 1}. {team.team}
              </span>
              <div className="flex gap-4 text-xs">
                <span>{team.wins}-{team.losses}</span>
                <span>{team.gb}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default LeagueStandings;