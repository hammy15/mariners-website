import React from 'react';
import { Crown, Heart, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface UserBadgeProps {
  tier: 'free' | 'supporter' | 'champion';
  className?: string;
}

const UserBadge: React.FC<UserBadgeProps> = ({ tier, className = '' }) => {
  const getBadgeConfig = () => {
    switch (tier) {
      case 'supporter':
        return {
          icon: <Heart className="w-3 h-3" />,
          text: 'Supporter',
          className: 'bg-blue-600 text-white hover:bg-blue-700'
        };
      case 'champion':
        return {
          icon: <Crown className="w-3 h-3" />,
          text: 'Champion',
          className: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-black hover:from-yellow-500 hover:to-orange-600'
        };
      default:
        return {
          icon: <Star className="w-3 h-3" />,
          text: 'Fan',
          className: 'bg-gray-500 text-white hover:bg-gray-600'
        };
    }
  };

  const config = getBadgeConfig();

  return (
    <Badge className={`${config.className} ${className}`}>
      {config.icon}
      <span className="ml-1">{config.text}</span>
    </Badge>
  );
};

export default UserBadge;