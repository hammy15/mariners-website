import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Newspaper, ExternalLink, Clock, Search, TrendingUp } from 'lucide-react';

interface NewsItem {
  title: string;
  source: string;
  time: string;
  link: string;
}

interface NewsCategories {
  [key: string]: NewsItem[];
}

const MarinersIntelBot: React.FC = () => {
  const [newsData, setNewsData] = useState<NewsCategories>({});
  const [summary, setSummary] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>('');

  const fetchDailyIntel = async () => {
    setIsLoading(true);
    try {
      // Mock data for demo
      const categories: NewsCategories = {
        'Breaking News': [
          { title: 'Mariners Call Up Top Prospect from AAA', source: 'MLB.com', time: '2h ago', link: '#' },
          { title: 'Trade Talks Intensify Before Deadline', source: 'The Athletic', time: '4h ago', link: '#' }
        ],
        'Player Updates': [
          { title: 'Julio Rodriguez Listed Day-to-Day', source: 'Seattle Times', time: '1h ago', link: '#' },
          { title: 'Pitching Staff Injury Report', source: 'ESPN', time: '3h ago', link: '#' }
        ],
        'Social Buzz': [
          { title: 'Fan Reactions to Last Night\'s Walk-Off', source: 'Twitter', time: '30m ago', link: '#' },
          { title: 'Reddit Hot Takes on Roster Moves', source: 'Reddit', time: '1h ago', link: '#' }
        ],
        'Analysis': [
          { title: 'Playoff Probability Update', source: 'FanGraphs', time: '5h ago', link: '#' },
          { title: 'Trade Deadline Strategy Breakdown', source: 'ESPN', time: '6h ago', link: '#' }
        ]
      };

      const totalArticles = Object.values(categories).flat().length;
      const generatedSummary = `📰 DAILY MARINERS INTEL - ${new Date().toLocaleDateString()}

🔥 BREAKING: Major roster moves expected this week as trade deadline approaches
📊 STATS: Team batting average up 15 points over last 10 games  
💬 BUZZ: Fans optimistic about playoff push on social media
🎯 FOCUS: Pitching depth remains top priority for front office

Total articles tracked: ${totalArticles}
New sources added: 3 local podcasts, 2 beat reporters`;

      setNewsData(categories);
      setSummary(generatedSummary);
      setLastUpdate(new Date().toLocaleString());
    } catch (error) {
      console.error('Error fetching intel:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDailyIntel();
  }, []);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Newspaper className="h-5 w-5 text-blue-600" />
          Trident Intel Daily
          <Badge variant="secondary" className="ml-auto">24/7 Monitoring</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            Last scan: {lastUpdate || 'Never'}
          </div>
          <Button 
            size="sm" 
            onClick={fetchDailyIntel} 
            disabled={isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Search className="h-4 w-4 mr-1" />
            {isLoading ? 'Scanning...' : 'Refresh Intel'}
          </Button>
        </div>
        
        {summary && (
          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
            <pre className="whitespace-pre-wrap text-sm">
              {summary}
            </pre>
          </div>
        )}

        <Tabs defaultValue="Breaking News" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            {Object.keys(newsData).map((category) => (
              <TabsTrigger key={category} value={category} className="text-xs">
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {Object.entries(newsData).map(([category, articles]) => (
            <TabsContent key={category} value={category} className="space-y-2">
              {articles.map((article, idx) => (
                <div key={idx} className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h4 className="font-medium text-sm leading-tight">{article.title}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">{article.source}</Badge>
                        <span className="text-xs text-muted-foreground">{article.time}</span>
                      </div>
                    </div>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </TabsContent>
          ))}
        </Tabs>
        
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Multi-platform monitoring
          </div>
          <div>No duplicate articles</div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarinersIntelBot;