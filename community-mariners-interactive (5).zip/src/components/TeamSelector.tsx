import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';

const MLB_TEAMS = [
  { code: 'LAA', name: 'Los Angeles Angels', colors: 'from-red-600 to-red-800' },
  { code: 'HOU', name: 'Houston Astros', colors: 'from-orange-500 to-blue-900' },
  { code: 'OAK', name: 'Oakland Athletics', colors: 'from-green-600 to-yellow-400' },
  { code: 'TOR', name: 'Toronto Blue Jays', colors: 'from-blue-600 to-blue-800' },
  { code: 'ATL', name: 'Atlanta Braves', colors: 'from-red-600 to-blue-900' },
  { code: 'MIL', name: 'Milwaukee Brewers', colors: 'from-blue-600 to-yellow-400' },
  { code: 'STL', name: 'St. Louis Cardinals', colors: 'from-red-600 to-red-800' },
  { code: 'CHC', name: 'Chicago Cubs', colors: 'from-blue-600 to-red-600' },
  { code: 'ARI', name: 'Arizona Diamondbacks', colors: 'from-red-600 to-black' },
  { code: 'LAD', name: 'Los Angeles Dodgers', colors: 'from-blue-600 to-blue-800' },
  { code: 'SF', name: 'San Francisco Giants', colors: 'from-orange-500 to-black' },
  { code: 'CLE', name: 'Cleveland Guardians', colors: 'from-red-600 to-blue-900' },
  { code: 'SEA', name: 'Seattle Mariners', colors: 'from-teal-600 to-blue-900' },
  { code: 'MIA', name: 'Miami Marlins', colors: 'from-blue-400 to-orange-500' },
  { code: 'NYM', name: 'New York Mets', colors: 'from-blue-600 to-orange-500' },
  { code: 'WSH', name: 'Washington Nationals', colors: 'from-red-600 to-blue-900' },
  { code: 'BAL', name: 'Baltimore Orioles', colors: 'from-orange-500 to-black' },
  { code: 'SD', name: 'San Diego Padres', colors: 'from-yellow-600 to-brown-600' },
  { code: 'PHI', name: 'Philadelphia Phillies', colors: 'from-red-600 to-blue-900' },
  { code: 'PIT', name: 'Pittsburgh Pirates', colors: 'from-yellow-400 to-black' },
  { code: 'TEX', name: 'Texas Rangers', colors: 'from-blue-600 to-red-600' },
  { code: 'TB', name: 'Tampa Bay Rays', colors: 'from-blue-400 to-yellow-400' },
  { code: 'BOS', name: 'Boston Red Sox', colors: 'from-red-600 to-blue-900' },
  { code: 'CIN', name: 'Cincinnati Reds', colors: 'from-red-600 to-red-800' },
  { code: 'COL', name: 'Colorado Rockies', colors: 'from-purple-600 to-black' },
  { code: 'DET', name: 'Detroit Tigers', colors: 'from-blue-900 to-orange-500' },
  { code: 'KC', name: 'Kansas City Royals', colors: 'from-blue-600 to-blue-800' },
  { code: 'MIN', name: 'Minnesota Twins', colors: 'from-red-600 to-blue-900' },
  { code: 'CWS', name: 'Chicago White Sox', colors: 'from-black to-gray-600' },
  { code: 'NYY', name: 'New York Yankees', colors: 'from-blue-900 to-gray-600' }
];

const TeamSelector: React.FC = () => {
  const { profile, updateProfile } = useAuth();

  const handleTeamChange = async (teamCode: string) => {
    try {
      await updateProfile({ favorite_team: teamCode });
    } catch (error) {
      console.error('Error updating team:', error);
    }
  };

  const selectedTeam = MLB_TEAMS.find(team => team.code === profile?.favorite_team);

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">My Team</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Select value={profile?.favorite_team || ''} onValueChange={handleTeamChange}>
          <SelectTrigger>
            <SelectValue placeholder="Choose your favorite team" />
          </SelectTrigger>
          <SelectContent>
            {MLB_TEAMS.map((team) => (
              <SelectItem key={team.code} value={team.code}>
                {team.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        {selectedTeam && (
          <div className={`p-4 rounded-lg bg-gradient-to-r ${selectedTeam.colors} text-white text-center`}>
            <h3 className="font-bold text-lg">{selectedTeam.name}</h3>
            <p className="text-sm opacity-90">Your favorite team</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TeamSelector;