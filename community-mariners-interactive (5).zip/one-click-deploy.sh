#!/bin/bash

echo "🚀 One-Click Deployment Script"
echo "================================"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm not found. Please install Node.js first."
    exit 1
fi

echo "📦 Installing dependencies..."
npm install

echo "🔧 Building application..."
npm run build

echo "✅ Build complete! Files are in 'dist' folder"
echo ""
echo "🌐 Deployment Options:"
echo "1. Drag 'dist' folder to netlify.com"
echo "2. Run: npx surge dist"
echo "3. Upload 'dist' to any web host"
echo ""
echo "🎉 Your app is ready to deploy!"

# Optional: Auto-deploy to surge if available
if command -v surge &> /dev/null; then
    echo "🚀 Auto-deploying to Surge..."
    cd dist && surge
fi