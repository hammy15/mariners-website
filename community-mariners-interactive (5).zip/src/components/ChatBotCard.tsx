import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';

interface ChatBotCardProps {
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  onClick: () => void;
}

const ChatBotCard: React.FC<ChatBotCardProps> = ({ 
  name, 
  description, 
  icon, 
  color, 
  onClick 
}) => {
  return (
    <Card className={`cursor-pointer hover:shadow-lg transition-all duration-200 border-2 hover:border-${color}-300`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full bg-${color}-100`}>
              {icon}
            </div>
            <div>
              <h3 className="font-semibold text-sm">{name}</h3>
              <p className="text-xs text-gray-600">{description}</p>
            </div>
          </div>
          <Button 
            size="sm" 
            variant="outline"
            onClick={onClick}
            className={`hover:bg-${color}-50`}
          >
            <MessageCircle className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ChatBotCard;