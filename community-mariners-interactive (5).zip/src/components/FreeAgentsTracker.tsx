import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { UserX, Search } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface FreeAgent {
  PlayerID: number;
  FirstName: string;
  LastName: string;
  Position: string;
  Age: number;
  Experience: number;
  Height: string;
  Weight: number;
}

const FreeAgentsTracker: React.FC = () => {
  const [freeAgents, setFreeAgents] = useState<FreeAgent[]>([]);
  const [filteredAgents, setFilteredAgents] = useState<FreeAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState('');

  useEffect(() => {
    fetchFreeAgents();
  }, []);

  useEffect(() => {
    filterAgents();
  }, [freeAgents, searchTerm, positionFilter]);

  const fetchFreeAgents = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('sportsdata-mariners', {
        body: { endpoint: 'free-agents' }
      });

      if (error) throw error;
      
      if (data.success) {
        setFreeAgents(data.data || []);
      } else {
        setError('No free agents data available');
      }
    } catch (err) {
      setError('Failed to load free agents');
      console.error('Free agents error:', err);
    } finally {
      setLoading(false);
    }
  };

  const filterAgents = () => {
    let filtered = freeAgents;
    
    if (searchTerm) {
      filtered = filtered.filter(agent => 
        `${agent.FirstName} ${agent.LastName}`.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (positionFilter) {
      filtered = filtered.filter(agent => agent.Position === positionFilter);
    }
    
    setFilteredAgents(filtered);
  };

  const positions = [...new Set(freeAgents.map(agent => agent.Position))].sort();

  const AgentCard = ({ agent }: { agent: FreeAgent }) => (
    <div className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-medium">{agent.FirstName} {agent.LastName}</div>
          <div className="text-sm text-gray-500">{agent.Position}</div>
          <div className="text-xs text-gray-400">
            Age: {agent.Age} | Exp: {agent.Experience} years
          </div>
          <div className="text-xs text-gray-400">
            {agent.Height} | {agent.Weight} lbs
          </div>
        </div>
        <Badge variant="outline" className="bg-orange-50 text-orange-600">
          Free Agent
        </Badge>
      </div>
    </div>
  );

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-200 rounded"></div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  if (error) return (
    <Card>
      <CardContent className="p-6 text-center text-red-500">
        {error}
      </CardContent>
    </Card>
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <UserX className="h-5 w-5" />
          MLB Free Agents
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search players..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={positionFilter}
            onChange={(e) => setPositionFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">All Positions</option>
            {positions.map(pos => (
              <option key={pos} value={pos}>{pos}</option>
            ))}
          </select>
        </div>

        <div className="text-sm text-gray-600 mb-2">
          Showing {filteredAgents.length} of {freeAgents.length} free agents
        </div>

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredAgents.map(agent => (
            <AgentCard key={agent.PlayerID} agent={agent} />
          ))}
        </div>

        {filteredAgents.length === 0 && !loading && (
          <div className="text-center text-gray-500 py-8">
            No free agents found matching your criteria
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FreeAgentsTracker;