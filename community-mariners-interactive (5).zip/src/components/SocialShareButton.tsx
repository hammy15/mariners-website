import React from 'react';
import { Button } from './ui/button';
import { Share2, Facebook, Twitter, MessageCircle } from 'lucide-react';

interface SocialShareButtonProps {
  url?: string;
  title?: string;
  description?: string;
  platform?: 'facebook' | 'twitter' | 'reddit' | 'generic';
  className?: string;
}

const SocialShareButton: React.FC<SocialShareButtonProps> = ({
  url = window.location.href,
  title = 'Check out TridentFans - Seattle Mariners Community',
  description = 'Join the ultimate Seattle Mariners fan community',
  platform = 'generic',
  className = ''
}) => {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);

  const shareUrls = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
    reddit: `https://reddit.com/submit?url=${encodedUrl}&title=${encodedTitle}`,
    generic: ''
  };

  const icons = {
    facebook: <Facebook className="h-4 w-4" />,
    twitter: <Twitter className="h-4 w-4" />,
    reddit: <MessageCircle className="h-4 w-4" />,
    generic: <Share2 className="h-4 w-4" />
  };

  const handleShare = async () => {
    if (platform === 'generic' && navigator.share) {
      try {
        await navigator.share({
          title,
          text: description,
          url
        });
        return;
      } catch (error) {
        console.log('Native sharing not available');
      }
    }

    if (platform !== 'generic') {
      window.open(shareUrls[platform], '_blank', 'width=600,height=400');
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleShare}
      className={`flex items-center gap-2 ${className}`}
    >
      {icons[platform]}
      <span className="capitalize">{platform === 'generic' ? 'Share' : platform}</span>
    </Button>
  );
};

export default SocialShareButton;