import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Heart, Star, Crown } from 'lucide-react';

const SupportTiers: React.FC = () => {
  const tiers = [
    { name: 'Fan', price: 'Free', icon: Heart, color: 'bg-gray-100' },
    { name: 'Supporter', price: '$5/mo', icon: Star, color: 'bg-blue-100' },
    { name: 'MVP', price: '$25 once', icon: Crown, color: 'bg-yellow-100' }
  ];

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Support TridentFans</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-2">
          {tiers.map((tier, idx) => {
            const Icon = tier.icon;
            return (
              <div key={idx} className="text-center">
                <div className={`w-12 h-12 rounded-full ${tier.color} flex items-center justify-center mx-auto mb-2`}>
                  <Icon className="h-5 w-5" />
                </div>
                <p className="text-xs font-medium">{tier.name}</p>
                <p className="text-xs text-muted-foreground">{tier.price}</p>
              </div>
            );
          })}
        </div>
        <Button variant="outline" size="sm" className="w-full mt-4">
          Choose Tier
        </Button>
      </CardContent>
    </Card>
  );
};

export default SupportTiers;