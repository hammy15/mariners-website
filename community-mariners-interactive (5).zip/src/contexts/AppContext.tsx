import React, { createContext, useContext, useState } from 'react';

interface AppContextType {
  selectedTeam: string;
  setSelectedTeam: (team: string) => void;
  notifications: any[];
  addNotification: (notification: any) => void;
  removeNotification: (id: string) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [selectedTeam, setSelectedTeam] = useState('mariners');
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const addNotification = (notification: any) => {
    const id = Math.random().toString(36).substring(2);
    setNotifications(prev => [...prev, { ...notification, id }]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return (
    <AppContext.Provider value={{
      selectedTeam,
      setSelectedTeam,
      notifications,
      addNotification,
      removeNotification,
      isLoading,
      setIsLoading
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}