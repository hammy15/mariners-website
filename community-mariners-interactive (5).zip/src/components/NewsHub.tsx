import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, ExternalLink, TrendingUp, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';

const NewsHub: React.FC = () => {
  const [newsItems, setNewsItems] = useState([
    {
      title: "Mariners Acquire Veteran Reliever in Trade",
      source: "Seattle Times",
      time: "2h ago",
      category: "local",
      sentiment: "positive"
    },
    {
      title: "Julio Rodriguez Named AL Player of the Week",
      source: "MLB.com",
      time: "4h ago", 
      category: "national",
      sentiment: "positive"
    },
    {
      title: "Tacoma Rainiers Win Pacific Coast League Title",
      source: "MiLB.com",
      time: "6h ago",
      category: "minors",
      sentiment: "positive"
    },
    {
      title: "Injury Update: Starting Pitcher Day-to-Day",
      source: "ESPN",
      time: "8h ago",
      category: "national", 
      sentiment: "neutral"
    }
  ]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.functions.invoke('mlb-news-feed');
      
      if (error) throw error;
      
      if (data?.news) {
        setNewsItems(data.news);
      }
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-green-100 text-green-800';
      case 'negative': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingUp className="h-5 w-5 mr-2 text-teal-600" />
          News Hub
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="local">Local</TabsTrigger>
            <TabsTrigger value="national">National</TabsTrigger>
            <TabsTrigger value="minors">Minors</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-3 mt-4">
            {newsItems.map((item, index) => (
              <div key={index} className="border-l-4 border-teal-200 pl-4 py-2 hover:bg-gray-50 cursor-pointer">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-1">{item.title}</h4>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <span>{item.source}</span>
                      <span>•</span>
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {item.time}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 ml-4">
                    <Badge className={getSentimentColor(item.sentiment)} variant="secondary">
                      {item.sentiment}
                    </Badge>
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="local">
            <p className="text-gray-600 text-center py-8">Local Seattle news coming soon...</p>
          </TabsContent>
          
          <TabsContent value="national">
            <p className="text-gray-600 text-center py-8">National MLB news coming soon...</p>
          </TabsContent>
          
          <TabsContent value="minors">
            <p className="text-gray-600 text-center py-8">Minor league updates coming soon...</p>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default NewsHub;