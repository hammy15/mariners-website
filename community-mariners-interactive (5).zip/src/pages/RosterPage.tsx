import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const RosterPage = () => {
  const [players, setPlayers] = useState([]);
  const [selectedPosition, setSelectedPosition] = useState('all');
  const [loading, setLoading] = useState(true);

  const positions = ['all', 'Pitcher', 'Catcher', 'Infielder', 'Outfielder'];

  useEffect(() => {
    fetchRoster();
  }, []);

  const fetchRoster = async () => {
    try {
      // Call Mariners roster function
      const { data, error } = await supabase.functions.invoke('mariners-roster', {
        body: { season: '2024' }
      });

      if (error) throw error;
      
      if (data?.players) {
        setPlayers(data.players);
      }
    } catch (error) {
      console.error('Error fetching roster:', error);
      // Fallback to mock data
      setPlayers([
        {
          id: 1,
          name: "Julio Rodriguez",
          position: "Outfielder",
          number: 44,
          age: 23,
          battingAvg: ".284",
          homeRuns: 28,
          rbi: 103,
          imageUrl: "/placeholder.svg"
        },
        {
          id: 2,
          name: "Cal Raleigh",
          position: "Catcher",
          number: 29,
          age: 27,
          battingAvg: ".220",
          homeRuns: 30,
          rbi: 63,
          imageUrl: "/placeholder.svg"
        },
        {
          id: 3,
          name: "Logan Gilbert",
          position: "Pitcher",
          number: 36,
          age: 27,
          era: "3.73",
          wins: 10,
          strikeouts: 220,
          imageUrl: "/placeholder.svg"
        },
        {
          id: 4,
          name: "Eugenio Suarez",
          position: "Infielder",
          number: 28,
          age: 32,
          battingAvg: ".232",
          homeRuns: 22,
          rbi: 90,
          imageUrl: "/placeholder.svg"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filteredPlayers = selectedPosition === 'all' 
    ? players 
    : players.filter((player: any) => player.position === selectedPosition);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">2024 Mariners Roster</h1>
        <Button onClick={fetchRoster}>Refresh</Button>
      </div>

      {/* Position Filter */}
      <div className="flex flex-wrap gap-2">
        {positions.map((position) => (
          <Button
            key={position}
            variant={selectedPosition === position ? "default" : "outline"}
            onClick={() => setSelectedPosition(position)}
            className="capitalize"
          >
            {position}
          </Button>
        ))}
      </div>

      {/* Player Cards */}
      {loading ? (
        <div className="text-center py-8">Loading roster...</div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map((player: any) => (
            <Card key={player.id} className="p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <img 
                  src={player.imageUrl || "/placeholder.svg"} 
                  alt={player.name}
                  className="w-16 h-16 object-cover rounded-full"
                />
                <div>
                  <h3 className="text-lg font-semibold">{player.name}</h3>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">#{player.number}</Badge>
                    <span className="text-sm text-gray-600">{player.position}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Age:</span>
                  <span>{player.age}</span>
                </div>
                
                {player.position === 'Pitcher' ? (
                  <>
                    <div className="flex justify-between">
                      <span>ERA:</span>
                      <span className="font-semibold">{player.era}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Wins:</span>
                      <span>{player.wins}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Strikeouts:</span>
                      <span>{player.strikeouts}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between">
                      <span>AVG:</span>
                      <span className="font-semibold">{player.battingAvg}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Home Runs:</span>
                      <span>{player.homeRuns}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>RBI:</span>
                      <span>{player.rbi}</span>
                    </div>
                  </>
                )}
              </div>

              <Button className="w-full mt-4" variant="outline">
                View Stats
              </Button>
            </Card>
          ))}
        </div>
      )}

      {/* Team Overview */}
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-teal-50 dark:from-blue-900/20 dark:to-teal-900/20">
        <h3 className="text-lg font-semibold mb-4">Team Overview</h3>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{players.length}</div>
            <div className="text-gray-600">Active Players</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">85-77</div>
            <div className="text-gray-600">2024 Record</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">3rd</div>
            <div className="text-gray-600">AL West</div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default RosterPage;
