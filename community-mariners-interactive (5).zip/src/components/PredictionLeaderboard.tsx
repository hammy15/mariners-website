import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface LeaderboardEntry {
  user_id: string;
  username: string;
  total_predictions: number;
  correct_predictions: number;
  accuracy_rate: number;
  points: number;
  tier: string;
}

const PredictionLeaderboard: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    try {
      const { data, error } = await supabase
        .from('prediction_leaderboard')
        .select('*')
        .order('points', { ascending: false })
        .limit(10);

      if (error) throw error;
      setLeaderboard(data || []);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0: return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 1: return <Medal className="h-5 w-5 text-gray-400" />;
      case 2: return <Award className="h-5 w-5 text-amber-600" />;
      default: return <TrendingUp className="h-4 w-4 text-blue-500" />;
    }
  };

  const getTierBadge = (tier: string) => {
    const colors = {
      'champion': 'bg-purple-100 text-purple-800',
      'supporter': 'bg-blue-100 text-blue-800',
      'fan': 'bg-green-100 text-green-800'
    };
    return colors[tier as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Prediction Leaderboard</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-gray-200 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Trophy className="h-5 w-5 text-yellow-500" />
          <span>Top Mariners Predictors</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {leaderboard.map((entry, index) => (
            <div key={entry.user_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white">
                  {getRankIcon(index)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold">{entry.username}</span>
                    <Badge className={getTierBadge(entry.tier)}>
                      {entry.tier}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-600">
                    {entry.correct_predictions}/{entry.total_predictions} correct ({entry.accuracy_rate}%)
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-blue-600">{entry.points} pts</div>
                <div className="text-xs text-gray-500">#{index + 1}</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default PredictionLeaderboard;