import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle, Clock, Target } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface PredictionRecord {
  id: string;
  game_id: string;
  prediction_type: string;
  prediction_data: any;
  confidence_level: number;
  status: 'pending' | 'correct' | 'incorrect';
  points_earned: number;
  created_at: string;
  game_opponent: string;
  game_date: string;
}

const PredictionHistory: React.FC = () => {
  const { user } = useAuth();
  const [predictions, setPredictions] = useState<PredictionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    correct: 0,
    pending: 0,
    accuracy: 0,
    totalPoints: 0
  });

  useEffect(() => {
    if (user) {
      fetchPredictionHistory();
    }
  }, [user]);

  const fetchPredictionHistory = async () => {
    try {
      const { data, error } = await supabase
        .from('predictions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setPredictions(data || []);
      calculateStats(data || []);
    } catch (error) {
      console.error('Error fetching prediction history:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (data: PredictionRecord[]) => {
    const total = data.length;
    const correct = data.filter(p => p.status === 'correct').length;
    const pending = data.filter(p => p.status === 'pending').length;
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    const totalPoints = data.reduce((sum, p) => sum + (p.points_earned || 0), 0);

    setStats({ total, correct, pending, accuracy, totalPoints });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'correct': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'incorrect': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      'correct': 'bg-green-100 text-green-800',
      'incorrect': 'bg-red-100 text-red-800',
      'pending': 'bg-yellow-100 text-yellow-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatPredictionData = (type: string, data: any) => {
    switch (type) {
      case 'win_loss':
        return `Winner: ${data.winner === 'mariners' ? 'Mariners' : 'Opponent'}`;
      case 'offensive':
        return `${data.totalHits} hits, ${data.homeRuns} HRs, ${data.rbis} RBIs`;
      case 'pitching':
        return `${data.strikeouts} Ks, ${data.earnedRuns} ERs, ${data.innings} IP`;
      default:
        return 'Unknown prediction type';
    }
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p>Please sign in to view your prediction history</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Target className="h-5 w-5 text-blue-600" />
          <span>Your Prediction History</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
            <div className="text-sm text-gray-600">Total</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{stats.correct}</div>
            <div className="text-sm text-gray-600">Correct</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
            <div className="text-sm text-gray-600">Pending</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.accuracy}%</div>
            <div className="text-sm text-gray-600">Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{stats.totalPoints}</div>
            <div className="text-sm text-gray-600">Points</div>
          </div>
        </div>

        <div className="space-y-3">
          {loading ? (
            [...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
            ))
          ) : predictions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No predictions yet. Make your first Mariners prediction!
            </div>
          ) : (
            predictions.map((prediction) => (
              <div key={prediction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(prediction.status)}
                  <div>
                    <div className="font-medium">
                      vs {prediction.game_opponent || 'TBD'}
                    </div>
                    <div className="text-sm text-gray-600">
                      {formatPredictionData(prediction.prediction_type, prediction.prediction_data)}
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(prediction.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className={getStatusBadge(prediction.status)}>
                    {prediction.status}
                  </Badge>
                  <div className="text-sm text-gray-600 mt-1">
                    {prediction.confidence_level}% confidence
                  </div>
                  {prediction.points_earned > 0 && (
                    <div className="text-xs text-green-600">
                      +{prediction.points_earned} pts
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default PredictionHistory;