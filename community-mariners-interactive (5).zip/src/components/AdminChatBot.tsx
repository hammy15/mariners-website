import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Smile, Anchor, Sword, MessageCircle, X } from 'lucide-react';
import { aiLearningSystem } from '@/lib/aiLearning';

const AdminChatBot: React.FC<{name?: string; realName?: string; position?: string}> = ({ name, realName }) => {
  const [activeBot, setActiveBot] = useState<string | null>(null);

  const botProfiles = {
    'marty-boomstick': {
      name: 'Marty BoomStick',
      icon: Smile,
      color: 'blue'
    },
    'wes-tillwaiting': {
      name: 'Wes Tillwaiting',
      icon: Anchor,
      color: 'green'
    },
    'don-tlose': {
      name: 'Don Tlose', 
      icon: Sword,
      color: 'red'
    }
  };

  const getDailyGreeting = (botName: string) => {
    const greetings = {
      'Marty BoomStick': [
        "BOOM! Ready to hit a home run conversation today!",
        "Batter up! What's on your mind, Trident fan?",
        "Grand slam day ahead - let's talk Mariners!"
      ],
      'Wes Tillwaiting': [
        "Well, well... another day, another chance to analyze the M's. What's the data telling us today?",
        "Statistically speaking, today's looking good for some baseball chat!",
        "The numbers don't lie - but let's see what you're thinking!"
      ],
      'Don Tlose': [
        "Alright troops, rally time! What's the game plan today?",
        "19 years in Seattle and still fighting the good fight. What's on your mind?",
        "Old school wisdom meets new school passion - let's talk!"
      ]
    };
    
    const dayIndex = new Date().getDate() % 3;
    return greetings[botName as keyof typeof greetings][dayIndex];
  };

  const handleBotClick = (botKey: string) => {
    setActiveBot(activeBot === botKey ? null : botKey);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {activeBot && (
        <Card className="w-80 mb-4 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                {botProfiles[activeBot as keyof typeof botProfiles].name}
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActiveBot(null)}
                className="text-white hover:bg-white/20"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="mb-4 p-3 bg-muted/30 rounded-lg">
              <p className="text-sm">
                {getDailyGreeting(botProfiles[activeBot as keyof typeof botProfiles].name)}
              </p>
            </div>
            <div className="flex gap-2">
              <input
                className="flex-1 px-3 py-2 text-sm border rounded-md"
                placeholder="Type your message..."
              />
              <Button size="sm">Send</Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      <div className="flex flex-col gap-2">
        {Object.entries(botProfiles).map(([key, profile]) => (
          <Button
            key={key}
            onClick={() => handleBotClick(key)}
            className={`rounded-full w-12 h-12 bg-${profile.color}-600 hover:bg-${profile.color}-700`}
            title={profile.name}
          >
            {React.createElement(profile.icon, { className: "h-6 w-6" })}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default AdminChatBot;