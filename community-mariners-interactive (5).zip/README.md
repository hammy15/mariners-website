# 🏟️ TridentFans - Seattle Mariners Fan Hub

A comprehensive React-based fan community platform for Seattle Mariners enthusiasts, featuring live scores, interactive discussions, game predictions, and premium fan experiences.

## 🚀 One-Click Deployment

### Quick Deploy (Recommended)
```bash
chmod +x one-click-deploy.sh && ./one-click-deploy.sh
```

### Alternative: Manual Deploy
```bash
npm install --legacy-peer-deps
npm run build
npm run deploy
```

## ✨ Features

### 🏠 Core Pages
- **Home** - Live scores, news hub, hero section
- **News** - Mariners news aggregation and updates  
- **Predictions** - Game prediction games and leaderboards
- **Roster** - Team roster, player stats, and profiles
- **Forum** - Fan discussions and community engagement
- **Seating** - Interactive T-Mobile Park seating charts
- **Newsletter** - Fan newsletter signup and archives

### 🎯 Key Features
- **Live MLB Integration** - Real-time scores and stats
- **User Authentication** - Secure login/signup system
- **Dark/Light Themes** - Customizable UI experience
- **Responsive Design** - Mobile-first, works on all devices
- **Real-time Updates** - Live chat and score updates
- **Premium Membership** - Exclusive content and features

### 🛠️ Technical Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (Database, Auth, Real-time)
- **Deployment**: Vercel (Optimized for React SPA)
- **UI Components**: Radix UI, Shadcn/ui
- **Routing**: React Router v6

## 🏗️ Project Structure

```
src/
├── components/          # Reusable UI components
├── pages/              # Main application pages
├── contexts/           # React context providers
├── hooks/              # Custom React hooks
├── lib/                # Utilities and configurations
└── main.tsx           # Application entry point
```

## 🔧 Environment Setup

Create `.env` file:
```env
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
```

## 📦 Installation & Development

```bash
# Install dependencies
npm install --legacy-peer-deps

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🌐 Deployment Options

### Vercel (Recommended)
- Optimized React SPA configuration
- Automatic deployments from Git
- Built-in analytics and monitoring

### Other Platforms
- Netlify: Use `netlify.toml` configuration
- GitHub Pages: Build and deploy to `gh-pages` branch
- Custom hosting: Deploy `dist/` folder contents

## 🧪 Testing & Verification

### Automated Route Testing
```bash
npm run test:routes https://your-site.vercel.app
```

### Manual Testing Checklist
- [ ] All navigation links work
- [ ] Theme toggle functions
- [ ] Responsive design on mobile
- [ ] User authentication flows
- [ ] Live data loading

## 🏟️ Mariners-Specific Features

### Team Integration
- Live game scores and schedules
- Player roster and statistics
- T-Mobile Park seating charts
- Season predictions and games

### Fan Community
- Discussion forums by topic
- Prediction leaderboards
- Photo contests and galleries
- Tailgate event organization

### Premium Features
- Exclusive content access
- Advanced statistics
- Priority support
- Special event invitations

## 🔐 Security & Privacy

- Secure authentication via Supabase
- Row-level security policies
- GDPR-compliant data handling
- Secure payment processing

## 📊 Analytics & Monitoring

- Real-time user analytics
- Performance monitoring
- Error tracking and logging
- User engagement metrics

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

- **Documentation**: Check deployment guides in `/docs`
- **Issues**: Create GitHub issue for bugs
- **Discussions**: Use GitHub Discussions for questions
- **Email**: Contact team for urgent issues

---

**Go Mariners! ⚾️** Built with ❤️ for the best fans in baseball.