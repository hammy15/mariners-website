#!/usr/bin/env node

// Route testing script for TridentFans deployment
const https = require('https');
const http = require('http');

const routes = [
  '/',
  '/news',
  '/predictions', 
  '/roster',
  '/forum',
  '/seating',
  '/newsletter'
];

function testRoute(baseUrl, route) {
  return new Promise((resolve) => {
    const url = `${baseUrl}${route}`;
    const client = baseUrl.startsWith('https:') ? https : http;
    
    const req = client.get(url, (res) => {
      resolve({
        route,
        status: res.statusCode,
        success: res.statusCode === 200
      });
    });
    
    req.on('error', () => {
      resolve({
        route,
        status: 'ERROR',
        success: false
      });
    });
    
    req.setTimeout(10000, () => {
      req.destroy();
      resolve({
        route,
        status: 'TIMEOUT',
        success: false
      });
    });
  });
}

async function testAllRoutes(baseUrl) {
  console.log(`🧪 Testing routes for: ${baseUrl}`);
  console.log('================================');
  
  const results = await Promise.all(
    routes.map(route => testRoute(baseUrl, route))
  );
  
  results.forEach(result => {
    const icon = result.success ? '✅' : '❌';
    console.log(`${icon} ${result.route} - ${result.status}`);
  });
  
  const successCount = results.filter(r => r.success).length;
  console.log('================================');
  console.log(`✅ ${successCount}/${routes.length} routes working`);
  
  return successCount === routes.length;
}

// Main execution
const baseUrl = process.argv[2];
if (!baseUrl) {
  console.log('Usage: node test-routes.js <base-url>');
  console.log('Example: node test-routes.js https://your-site.vercel.app');
  process.exit(1);
}

testAllRoutes(baseUrl)
  .then(allPassed => {
    process.exit(allPassed ? 0 : 1);
  })
  .catch(error => {
    console.error('Test failed:', error);
    process.exit(1);
  });