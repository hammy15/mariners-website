# SSL Certificate Troubleshooting Guide

## Common SSL Issues & Solutions

### Issue 1: "Not Secure" Warning
**Cause**: SSL certificate not yet provisioned
**Solution**: 
- Wait 24-48 hours after DNS configuration
- Vercel auto-provisions SSL after domain verification
- Check Vercel dashboard for certificate status

### Issue 2: Mixed Content Errors
**Cause**: HTTP resources loaded on HTTPS page
**Solution**:
- All API calls use HTTPS (Supabase already HTTPS)
- All external resources use HTTPS URLs
- Check browser console for mixed content warnings

### Issue 3: Certificate Mismatch
**Cause**: DNS not properly pointing to Vercel
**Solution**:
- Verify A record points to 76.76.19.61
- Check `nslookup tridentfans.com` returns correct IP
- Wait for DNS propagation (24-48 hours)

### Issue 4: Redirect Loop
**Cause**: Conflicting redirect rules
**Solution**:
- Remove any redirect rules in GoDaddy
- Let Vercel handle all redirects via vercel.json
- Clear browser cache and cookies

## Verification Steps
1. **DNS Check**: `nslookup tridentfans.com`
2. **SSL Check**: Visit https://www.ssllabs.com/ssltest/
3. **Browser Test**: Open https://tridentfans.com
4. **Mobile Test**: Test on mobile device

## Timeline Expectations
- DNS Changes: 10 minutes - 48 hours
- SSL Certificate: 1-24 hours after DNS verification
- Full Propagation: Up to 48 hours globally

## Support Resources
- Vercel Support: https://vercel.com/help
- GoDaddy Support: https://www.godaddy.com/help
- SSL Test Tool: https://www.ssllabs.com/ssltest/