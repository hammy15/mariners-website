import React from 'react';
import { Badge } from './ui/badge';
import { Camera } from 'lucide-react';

interface SeatPhoto {
  id: string;
  seat_section: string;
  seat_row: string;
  seat_number: string;
  photo_url: string;
  view_description: string;
  submission_date: string;
}

interface SeatPhotoDisplayProps {
  selectedSeat: SeatPhoto | null;
  hoveredSeat: string | null;
  seatPhotos: SeatPhoto[];
}

const SeatPhotoDisplay: React.FC<SeatPhotoDisplayProps> = ({
  selectedSeat,
  hoveredSeat,
  seatPhotos,
}) => {
  if (!selectedSeat && !hoveredSeat) return null;

  return (
    <div className="mb-4">
      {selectedSeat ? (
        <div className="border rounded-lg p-4 bg-white shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <Camera className="h-4 w-4 text-teal-600" />
            <span className="font-semibold text-gray-800">
              Section {selectedSeat.seat_section}, Row {selectedSeat.seat_row}, Seat {selectedSeat.seat_number}
            </span>
          </div>
          {selectedSeat.photo_url && (
            <div className="mb-3">
              <img 
                src={selectedSeat.photo_url} 
                alt={selectedSeat.view_description}
                className="w-full max-w-md rounded-lg shadow-sm"
                loading="lazy"
              />
            </div>
          )}
          <p className="text-sm text-gray-600 mb-2">{selectedSeat.view_description}</p>
          <p className="text-xs text-gray-500">
            Submitted: {new Date(selectedSeat.submission_date).toLocaleDateString()}
          </p>
        </div>
      ) : hoveredSeat && (
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <span className="text-sm font-medium text-gray-700">Section {hoveredSeat}</span>
          {!seatPhotos.some(p => p.seat_section === hoveredSeat) && (
            <p className="text-xs text-gray-500 mt-1">No photos yet - be the first to submit!</p>
          )}
        </div>
      )}
    </div>
  );
};

export default SeatPhotoDisplay;