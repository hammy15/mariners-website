import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Trophy } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface StandingsData {
  Key: string;
  Name: string;
  Wins: number;
  Losses: number;
  Percentage: number;
  DivisionRank: number;
  WildCardRank: number;
  RunsScored: number;
  RunsAllowed: number;
  Streak: number;
  StreakType: string;
}

const MarinersStandings: React.FC = () => {
  const [standings, setStandings] = useState<StandingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStandings();
  }, []);

  const fetchStandings = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('sportsdata-mariners', {
        body: { endpoint: 'standings' }
      });

      if (error) throw error;
      
      if (data.success && data.data.length > 0) {
        setStandings(data.data[0]);
      } else {
        setError('No standings data available');
      }
    } catch (err) {
      setError('Failed to load standings');
      console.error('Standings error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      </CardContent>
    </Card>
  );

  if (error) return (
    <Card>
      <CardContent className="p-6 text-center text-red-500">
        {error}
      </CardContent>
    </Card>
  );

  if (!standings) return null;

  const winPercentage = (standings.Percentage * 100).toFixed(1);
  const isStreakWin = standings.StreakType === 'W';

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <Trophy className="h-5 w-5" />
          Mariners Standings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{standings.Wins}</div>
            <div className="text-sm text-gray-500">Wins</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{standings.Losses}</div>
            <div className="text-sm text-gray-500">Losses</div>
          </div>
        </div>

        <div className="text-center">
          <div className="text-lg font-semibold">{winPercentage}%</div>
          <div className="text-sm text-gray-500">Win Percentage</div>
        </div>

        <div className="flex justify-between items-center">
          <Badge variant="outline" className="bg-blue-50">
            Division: #{standings.DivisionRank}
          </Badge>
          {standings.WildCardRank && (
            <Badge variant="outline" className="bg-green-50">
              Wild Card: #{standings.WildCardRank}
            </Badge>
          )}
        </div>

        <div className="flex items-center justify-center gap-2">
          {isStreakWin ? (
            <TrendingUp className="h-4 w-4 text-green-500" />
          ) : (
            <TrendingDown className="h-4 w-4 text-red-500" />
          )}
          <span className={`font-medium ${isStreakWin ? 'text-green-600' : 'text-red-600'}`}>
            {standings.StreakType}{standings.Streak}
          </span>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarinersStandings;