import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Star, Trophy, Users, MessageCircle, Target, Gift } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const NewMemberWelcome: React.FC = () => {
  const { user, profile } = useAuth();
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);

  const welcomeTasks = [
    {
      id: 'profile',
      title: 'Complete Your Profile',
      description: 'Add your photo and favorite player',
      points: 50,
      icon: <Users className="h-5 w-5" />
    },
    {
      id: 'first-post',
      title: 'Make Your First Post',
      description: 'Introduce yourself to the community',
      points: 75,
      icon: <MessageCircle className="h-5 w-5" />
    },
    {
      id: 'prediction',
      title: 'Make a Game Prediction',
      description: 'Predict the outcome of the next Mariners game',
      points: 100,
      icon: <Target className="h-5 w-5" />
    },
    {
      id: 'forum-engage',
      title: 'Engage in Discussion',
      description: 'Comment on or vote on 3 forum posts',
      points: 60,
      icon: <Trophy className="h-5 w-5" />
    }
  ];

  const completeTask = (taskId: string) => {
    if (!completedTasks.includes(taskId)) {
      setCompletedTasks([...completedTasks, taskId]);
      const task = welcomeTasks.find(t => t.id === taskId);
      toast.success(`Task completed! +${task?.points} points`);
    }
  };

  const totalPoints = completedTasks.reduce((sum, taskId) => {
    const task = welcomeTasks.find(t => t.id === taskId);
    return sum + (task?.points || 0);
  }, 0);

  return (
    <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="h-6 w-6 text-blue-600" />
          Welcome to Mariners Community!
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center mb-6">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            {totalPoints} / 285 Points Earned
          </Badge>
          <p className="text-sm text-muted-foreground mt-2">
            Complete tasks to unlock community features
          </p>
        </div>

        <div className="grid gap-3">
          {welcomeTasks.map((task) => {
            const isCompleted = completedTasks.includes(task.id);
            return (
              <div
                key={task.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  isCompleted 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-white border-gray-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-full ${
                    isCompleted ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {isCompleted ? <CheckCircle className="h-4 w-4" /> : task.icon}
                  </div>
                  <div>
                    <h4 className="font-medium">{task.title}</h4>
                    <p className="text-sm text-muted-foreground">{task.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={isCompleted ? "default" : "outline"}>
                    {task.points} pts
                  </Badge>
                  {!isCompleted && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="mt-1 ml-2"
                      onClick={() => completeTask(task.id)}
                    >
                      Start
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {totalPoints >= 285 && (
          <div className="text-center p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg">
            <Trophy className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
            <h3 className="font-bold text-green-800">Welcome Complete!</h3>
            <p className="text-sm text-green-700">You've unlocked all community features!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default NewMemberWelcome;