import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, X, TrendingUp, BarChart3, Target, Bot } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ChatBot {
  id: string;
  name: string;
  personality: string;
  icon: React.ComponentType<any>;
  color: string;
  specialty: string;
}

interface Message {
  id: string;
  bot_id: string;
  content: string;
  timestamp: Date;
  context: any;
}

const EnhancedChatBots: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeBot, setActiveBot] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const bots: ChatBot[] = [
    {
      id: 'marty',
      name: 'Marty BoomStick',
      personality: 'cheerleader',
      icon: Bot,
      color: 'blue',
      specialty: 'Fan Engagement & Morale'
    },
    {
      id: 'captain',
      name: 'Captain Analytics',
      personality: 'technical',
      icon: BarChart3,
      color: 'green',
      specialty: 'Statistical Analysis'
    },
    {
      id: 'spartan',
      name: 'Spartan Strategy',
      personality: 'strategic',
      icon: Target,
      color: 'red',
      specialty: 'Game Strategy & Tactics'
    }
  ];

  const getPersonalityResponse = async (botId: string, userMessage: string) => {
    setLoading(true);
    try {
      // Get real-time context from forums and current events
      const { data: forumData } = await supabase
        .from('forum_posts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);

      const { data: gameData } = await supabase.functions.invoke('real-time-game-data');
      
      const context = {
        recentForumPosts: forumData || [],
        currentGameData: gameData?.data || {},
        timestamp: new Date().toISOString()
      };

      // Generate personality-specific response
      const response = await generateBotResponse(botId, userMessage, context);
      
      const newMessage: Message = {
        id: Date.now().toString(),
        bot_id: botId,
        content: response,
        timestamp: new Date(),
        context
      };

      setMessages(prev => [...prev, newMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        bot_id: botId,
        content: "I'm having trouble connecting right now. Let me try again!",
        timestamp: new Date(),
        context: {}
      }]);
    }
    setLoading(false);
  };

  const generateBotResponse = (botId: string, message: string, context: any): string => {
    const bot = bots.find(b => b.id === botId);
    if (!bot) return "Hello there!";

    const forumTopics = context.recentForumPosts?.map((post: any) => post.title).join(', ') || '';
    
    switch (bot.personality) {
      case 'cheerleader':
        return generateMartyResponse(message, forumTopics, context);
      case 'technical':
        return generateCaptainResponse(message, forumTopics, context);
      case 'strategic':
        return generateSpartanResponse(message, forumTopics, context);
      default:
        return "Great question! Let me think about that...";
    }
  };

  const generateMartyResponse = (message: string, forumTopics: string, context: any): string => {
    const responses = [
      `Hey there, fellow Trident fan! 🔱 I've been reading the forums and everyone's talking about ${forumTopics.split(',')[0] || 'the team'}. The energy is ELECTRIC!`,
      `BOOM! That's what I love to hear! Based on what fans are saying in the forums, we're all feeling optimistic about this season!`,
      `You know what? I've been learning from all the passionate discussions in our community, and your enthusiasm just adds to the amazing vibe we have here!`,
      `Ka-pow! The way our fan base comes together in the forums shows we're more than just fans - we're family! Let's keep that Mariners spirit alive!`
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const generateCaptainResponse = (message: string, forumTopics: string, context: any): string => {
    const responses = [
      `Analyzing current forum discussions and game data... The statistical trends show interesting patterns in ${forumTopics.split(',')[0] || 'team performance'}.`,
      `From a technical standpoint, the data I'm processing from recent forum posts indicates fan sentiment is correlating with on-field metrics.`,
      `Let me break down the numbers: Based on current forum activity and real-time data, I'm seeing measurable improvements in key performance indicators.`,
      `The analytical approach suggests that community engagement levels, as seen in our forums, directly impact team morale metrics.`
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const generateSpartanResponse = (message: string, forumTopics: string, context: any): string => {
    const responses = [
      `Strategic assessment: Forum discussions reveal key insights about ${forumTopics.split(',')[0] || 'tactical approaches'}. This intelligence is valuable for our game plan.`,
      `From a strategic perspective, the community wisdom I'm gathering from forums aligns with optimal tactical decisions.`,
      `Battle-tested analysis: The collective intelligence from our forum community provides strategic advantages that complement statistical data.`,
      `Tactical evaluation complete: Community insights from forums, combined with real-time data, suggest strategic opportunities ahead.`
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSendMessage = async () => {
    if (!input.trim() || !activeBot) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      bot_id: 'user',
      content: input,
      timestamp: new Date(),
      context: {}
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    await getPersonalityResponse(activeBot, input);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen && (
        <Card className="w-96 h-[500px] mb-4 shadow-xl border-2">
          <div className="flex flex-col h-full">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-bold text-lg">TridentFans AI Team</h3>
              <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.bot_id === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-lg ${
                    msg.bot_id === 'user' 
                      ? 'bg-blue-500 text-white' 
                      : 'bg-gray-100 border'
                  }`}>
                    {msg.bot_id !== 'user' && (
                      <Badge className="mb-2 text-xs">
                        {bots.find(b => b.id === msg.bot_id)?.name || 'AI'}
                      </Badge>
                    )}
                    <p className="text-sm">{msg.content}</p>
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="p-4 border-t">
              <div className="flex space-x-2 mb-3">
                {bots.map((bot) => (
                  <Button
                    key={bot.id}
                    size="sm"
                    variant={activeBot === bot.id ? "default" : "outline"}
                    onClick={() => setActiveBot(bot.id)}
                    className="text-xs"
                  >
                    {React.createElement(bot.icon, { className: "w-3 h-3 mr-1" })}
                    {bot.name.split(' ')[0]}
                  </Button>
                ))}
              </div>
              <div className="flex space-x-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={activeBot ? `Ask ${bots.find(b => b.id === activeBot)?.name}...` : "Select a bot first..."}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  disabled={!activeBot}
                />
                <Button onClick={handleSendMessage} disabled={!activeBot || !input.trim()}>
                  Send
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}
      
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-full w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 shadow-lg"
      >
        <MessageCircle className="h-7 w-7" />
      </Button>
    </div>
  );
};

export default EnhancedChatBots;