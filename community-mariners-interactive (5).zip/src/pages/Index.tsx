import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import HeroSection from '@/components/HeroSection';
import BotIntroduction from '@/components/BotIntroduction';
import EnhancedVisualComponents from '@/components/EnhancedVisualComponents';
import EnhancedChatBots from '@/components/EnhancedChatBots';
import AdvancedPredictionAlgorithms from '@/components/AdvancedPredictionAlgorithms';
import PushNotificationSystem from '@/components/PushNotificationSystem';
import RealTimeGameTracker from '@/components/RealTimeGameTracker';
import LiveScores from '@/components/LiveScores';
import MarinersNewsHub from '@/components/MarinersNewsHub';
import SupportContribute from '@/components/SupportContribute';
import NewMemberWelcome from '@/components/NewMemberWelcome';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Home, 
  Bot, 
  TrendingUp, 
  Bell, 
  Activity,
  Newspaper,
  BarChart3
} from 'lucide-react';

const Index = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/20">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Hero Section */}
        <HeroSection />
        
        {/* New Member Welcome - Only show for authenticated users */}
        {user && <NewMemberWelcome />}
        
        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 glass-effect">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="bots" className="flex items-center gap-2">
              <Bot className="h-4 w-4" />
              AI Bots
            </TabsTrigger>
            <TabsTrigger value="predictions" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Predictions
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Alerts
            </TabsTrigger>
            <TabsTrigger value="live" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Live Games
            </TabsTrigger>
            <TabsTrigger value="news" className="flex items-center gap-2">
              <Newspaper className="h-4 w-4" />
              News
            </TabsTrigger>
            <TabsTrigger value="scores" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Scores
            </TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-6">
            <EnhancedVisualComponents />
          </TabsContent>

          <TabsContent value="bots" className="space-y-6">
            <BotIntroduction />
            <EnhancedChatBots />
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <AdvancedPredictionAlgorithms />
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <PushNotificationSystem />
          </TabsContent>

          <TabsContent value="live" className="space-y-6">
            <RealTimeGameTracker />
          </TabsContent>

          <TabsContent value="news" className="space-y-6">
            <MarinersNewsHub />
          </TabsContent>

          <TabsContent value="scores" className="space-y-6">
            <LiveScores />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Support and Contribute Buttons */}
      <SupportContribute />
    </div>
  );
};

export default Index;