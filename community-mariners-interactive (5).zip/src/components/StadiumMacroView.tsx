import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Camera, MapPin, ArrowLeft } from 'lucide-react';
import SeatPhotoDisplay from './SeatPhotoDisplay';

interface StadiumMacroViewProps {
  onSectionSelect?: (section: string) => void;
}

const StadiumMacroView: React.FC<StadiumMacroViewProps> = ({ onSectionSelect }) => {
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPhotos, setShowPhotos] = useState(false);

  // Enhanced stadium sections with more detail
  const stadiumSections = {
    'Lower Bowl': {
      sections: ['100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145', '146', '147', '148', '149'],
      color: 'bg-green-500',
      description: 'Premium field-level seating'
    },
    'Club Level': {
      sections: ['200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229'],
      color: 'bg-blue-500',
      description: 'Mid-level with club amenities'
    },
    'Upper Deck': {
      sections: ['300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311', '312', '313', '314', '315', '316', '317', '318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339'],
      color: 'bg-purple-500',
      description: 'Upper level stadium view'
    },
    'Outfield': {
      sections: ['Bleachers', 'Hit It Here Cafe', 'Pen', 'The Terrace Club'],
      color: 'bg-orange-500',
      description: 'Outfield and specialty seating'
    }
  };

  // Mock photo data with more sections
  const sectionPhotos = {
    '100': 2, '101': 1, '102': 3, '103': 1, '104': 2, '105': 1,
    '200': 1, '201': 2, '202': 1, '203': 3, '204': 1,
    '300': 1, '301': 1, '302': 2, '303': 1,
    'Bleachers': 4, 'Hit It Here Cafe': 2, 'Pen': 1
  };

  const handleSectionClick = (section: string) => {
    setSelectedSection(section);
    setShowPhotos(true);
    onSectionSelect?.(section);
  };

  const handleSearch = () => {
    if (searchTerm) {
      const foundSection = Object.values(stadiumSections)
        .flatMap(level => level.sections)
        .find(section => 
          section.toLowerCase().includes(searchTerm.toLowerCase()) ||
          searchTerm.toLowerCase().includes(section.toLowerCase())
        );
      
      if (foundSection) {
        handleSectionClick(foundSection);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  if (showPhotos && selectedSection) {
    return (
      <div className="space-y-4">
        <Button 
          variant="outline" 
          onClick={() => setShowPhotos(false)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Stadium View
        </Button>
        <SeatPhotoDisplay section={selectedSection} />
      </div>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-blue-600" />
          <span>T-Mobile Park Stadium Map</span>
        </CardTitle>
        
        <div className="flex space-x-2">
          <Input
            placeholder="Search sections (e.g., 100, 200, Bleachers)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
          />
          <Button onClick={handleSearch} size="sm">
            <Search className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-6">
          {/* Stadium Visual Layout */}
          <div className="relative bg-green-100 dark:bg-green-900/20 rounded-lg p-8 min-h-96">
            <div className="text-center mb-4">
              <div className="bg-amber-200 dark:bg-amber-800 rounded-lg p-2 inline-block">
                <span className="text-sm font-semibold">⚾ FIELD ⚾</span>
              </div>
            </div>
            
            {/* Lower Bowl */}
            <div className="absolute inset-x-4 bottom-16 h-16 bg-green-500/20 rounded-lg border-2 border-green-500 flex items-center justify-center">
              <span className="text-sm font-semibold text-green-700 dark:text-green-300">Lower Bowl (100s)</span>
            </div>
            
            {/* Club Level */}
            <div className="absolute inset-x-8 bottom-32 h-12 bg-blue-500/20 rounded-lg border-2 border-blue-500 flex items-center justify-center">
              <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">Club Level (200s)</span>
            </div>
            
            {/* Upper Deck */}
            <div className="absolute inset-x-12 bottom-44 h-10 bg-purple-500/20 rounded-lg border-2 border-purple-500 flex items-center justify-center">
              <span className="text-sm font-semibold text-purple-700 dark:text-purple-300">Upper Deck (300s)</span>
            </div>
            
            {/* Outfield Sections */}
            <div className="absolute top-4 left-4 right-4 h-12 bg-orange-500/20 rounded-lg border-2 border-orange-500 flex items-center justify-center">
              <span className="text-sm font-semibold text-orange-700 dark:text-orange-300">Outfield Seating</span>
            </div>
          </div>

          {/* Section Grid */}
          <div className="space-y-6">
            {Object.entries(stadiumSections).map(([levelName, levelData]) => (
              <div key={levelName}>
                <h3 className="text-lg font-semibold mb-3 flex items-center">
                  <div className={`w-4 h-4 ${levelData.color} rounded mr-2`}></div>
                  {levelName}
                  <span className="text-sm text-gray-500 ml-2">({levelData.description})</span>
                </h3>
                
                <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2">
                  {levelData.sections.map((section) => {
                    const photoCount = sectionPhotos[section] || 0;
                    return (
                      <Button
                        key={section}
                        variant="outline"
                        size="sm"
                        onClick={() => handleSectionClick(section)}
                        className={`relative h-12 text-xs ${photoCount > 0 ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : 'border-gray-300'}`}
                        title={`Section ${section}${photoCount > 0 ? ` - ${photoCount} photos` : ' - No photos'}`}
                      >
                        <div className="flex flex-col items-center">
                          <span className="font-semibold">{section}</span>
                          {photoCount > 0 && (
                            <Badge variant="secondary" className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs">
                              <Camera className="w-2 h-2" />
                            </Badge>
                          )}
                        </div>
                      </Button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Legend</h4>
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center">
                <div className="w-3 h-3 border border-green-500 bg-green-50 rounded mr-2"></div>
                <span>Has Photos</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 border border-gray-300 rounded mr-2"></div>
                <span>No Photos</span>
              </div>
              <div className="flex items-center">
                <Camera className="w-3 h-3 mr-2" />
                <span>Photo Count</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StadiumMacroView;