import React from 'react';

interface SeatPhoto {
  id: string;
  seat_section: string;
  seat_row: string;
  seat_number: string;
  photo_url: string;
  view_description: string;
  submission_date: string;
}

interface SeatingSectionProps {
  name: string;
  sections: string[];
  seatPhotos: SeatPhoto[];
  onSectionClick: (section: string) => void;
  onSectionHover: (section: string | null) => void;
}

const SeatingSection: React.FC<SeatingSectionProps> = ({
  name,
  sections,
  seatPhotos,
  onSectionClick,
  onSectionHover,
}) => {
  return (
    <div className="text-center">
      <h4 className="font-semibold text-sm mb-2 text-gray-700">{name}</h4>
      <div className="grid grid-cols-3 gap-1">
        {sections.map((section) => {
          const hasPhoto = seatPhotos.some(photo => photo.seat_section === section);
          return (
            <div
              key={section}
              className={`
                w-8 h-6 text-xs flex items-center justify-center rounded cursor-pointer transition-colors
                ${hasPhoto 
                  ? 'bg-teal-500 text-white hover:bg-teal-600 shadow-sm' 
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-600'
                }
              `}
              onMouseEnter={() => onSectionHover(section)}
              onMouseLeave={() => onSectionHover(null)}
              onClick={() => onSectionClick(section)}
              title={hasPhoto ? `Section ${section} - Photos available` : `Section ${section} - No photos yet`}
            >
              {section}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SeatingSection;