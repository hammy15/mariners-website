import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface SetupStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'checking' | 'success' | 'error';
  error?: string;
}

export const SupabaseSetupSupport: React.FC = () => {
  const [steps, setSteps] = useState<SetupStep[]>([
    {
      id: 'connection',
      title: 'Database Connection',
      description: 'Test basic connection to Supabase',
      status: 'pending'
    },
    {
      id: 'auth',
      title: 'Authentication Setup',
      description: 'Verify auth configuration',
      status: 'pending'
    },
    {
      id: 'tables',
      title: 'Database Tables',
      description: 'Check if all required tables exist',
      status: 'pending'
    },
    {
      id: 'rls',
      title: 'Row Level Security',
      description: 'Verify RLS policies are configured',
      status: 'pending'
    },
    {
      id: 'functions',
      title: 'Edge Functions',
      description: 'Test edge function connectivity',
      status: 'pending'
    }
  ]);

  const [isRunning, setIsRunning] = useState(false);
  const [showConfig, setShowConfig] = useState(false);

  const updateStepStatus = (id: string, status: SetupStep['status'], error?: string) => {
    setSteps(prev => prev.map(step => 
      step.id === id ? { ...step, status, error } : step
    ));
  };

  const testConnection = async () => {
    updateStepStatus('connection', 'checking');
    try {
      const { data, error } = await supabase.from('users').select('count').limit(1);
      if (error) throw error;
      updateStepStatus('connection', 'success');
      return true;
    } catch (error) {
      updateStepStatus('connection', 'error', error instanceof Error ? error.message : 'Connection failed');
      return false;
    }
  };

  const testAuth = async () => {
    updateStepStatus('auth', 'checking');
    try {
      const { data: { session } } = await supabase.auth.getSession();
      updateStepStatus('auth', 'success');
      return true;
    } catch (error) {
      updateStepStatus('auth', 'error', error instanceof Error ? error.message : 'Auth test failed');
      return false;
    }
  };

  const testTables = async () => {
    updateStepStatus('tables', 'checking');
    const requiredTables = ['users', 'game_predictions', 'forum_posts', 'donations', 'seat_photos'];
    
    try {
      for (const table of requiredTables) {
        const { error } = await supabase.from(table).select('*').limit(1);
        if (error) throw new Error(`Table ${table} not accessible: ${error.message}`);
      }
      updateStepStatus('tables', 'success');
      return true;
    } catch (error) {
      updateStepStatus('tables', 'error', error instanceof Error ? error.message : 'Table check failed');
      return false;
    }
  };

  const testRLS = async () => {
    updateStepStatus('rls', 'checking');
    try {
      // Test RLS by trying to access protected data
      const { error } = await supabase.from('users').select('*').limit(1);
      updateStepStatus('rls', error ? 'error' : 'success', error?.message);
      return !error;
    } catch (error) {
      updateStepStatus('rls', 'error', error instanceof Error ? error.message : 'RLS test failed');
      return false;
    }
  };

  const testFunctions = async () => {
    updateStepStatus('functions', 'checking');
    try {
      const { data, error } = await supabase.functions.invoke('database-connection-test');
      if (error) throw error;
      updateStepStatus('functions', 'success');
      return true;
    } catch (error) {
      updateStepStatus('functions', 'error', error instanceof Error ? error.message : 'Function test failed');
      return false;
    }
  };

  const runDiagnostics = async () => {
    setIsRunning(true);
    
    await testConnection();
    await testAuth();
    await testTables();
    await testRLS();
    await testFunctions();
    
    setIsRunning(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusIcon = (status: SetupStep['status']) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'checking': return <AlertCircle className="h-5 w-5 text-yellow-500 animate-spin" />;
      default: return <AlertCircle className="h-5 w-5 text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span>Supabase Setup Support</span>
            <Badge variant="outline">Drop-in Support</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              This tool will help diagnose and fix Supabase connection issues for your Mariners fan website.
            </AlertDescription>
          </Alert>

          <div className="flex gap-2">
            <Button onClick={runDiagnostics} disabled={isRunning}>
              {isRunning ? 'Running Diagnostics...' : 'Run Setup Diagnostics'}
            </Button>
            <Button variant="outline" onClick={() => setShowConfig(!showConfig)}>
              {showConfig ? 'Hide' : 'Show'} Configuration
            </Button>
          </div>

          <div className="space-y-3">
            {steps.map((step) => (
              <div key={step.id} className="flex items-center gap-3 p-3 border rounded-lg">
                {getStatusIcon(step.status)}
                <div className="flex-1">
                  <h4 className="font-medium">{step.title}</h4>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                  {step.error && (
                    <p className="text-sm text-red-600 mt-1">{step.error}</p>
                  )}
                </div>
                <Badge variant={
                  step.status === 'success' ? 'default' : 
                  step.status === 'error' ? 'destructive' : 'secondary'
                }>
                  {step.status}
                </Badge>
              </div>
            ))}
          </div>

          {showConfig && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Configuration Help</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Required Environment Variables</h4>
                  <div className="space-y-2 text-sm font-mono bg-muted p-3 rounded">
                    <div className="flex items-center justify-between">
                      <span>VITE_SUPABASE_URL=your_supabase_url</span>
                      <Button size="sm" variant="ghost" onClick={() => copyToClipboard('VITE_SUPABASE_URL=your_supabase_url')}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>VITE_SUPABASE_ANON_KEY=your_anon_key</span>
                      <Button size="sm" variant="ghost" onClick={() => copyToClipboard('VITE_SUPABASE_ANON_KEY=your_anon_key')}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Quick Setup Links</h4>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm" asChild>
                      <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Supabase Dashboard
                      </a>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <a href="https://supabase.com/docs/guides/getting-started" target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Setup Documentation
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
};