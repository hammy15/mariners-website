import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, Trophy, DollarSign } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface TeamProfile {
  Key: string;
  TeamID: number;
  Name: string;
  City: string;
  League: string;
  Division: string;
  PrimaryColor: string;
  SecondaryColor: string;
  TertiaryColor: string;
  QuaternaryColor: string;
  WikipediaLogoUrl: string;
  WikipediaWordMarkUrl: string;
  GlobalTeamID: number;
}

const MarinersProfile: React.FC = () => {
  const [profile, setProfile] = useState<TeamProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('sportsdata-mariners', {
        body: { endpoint: 'mariners-profile' }
      });

      if (error) throw error;
      
      if (data.success) {
        setProfile(data.data);
      } else {
        setError('No team profile available');
      }
    } catch (err) {
      setError('Failed to load team profile');
      console.error('Profile error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-3/4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
        </div>
      </CardContent>
    </Card>
  );

  if (error) return (
    <Card>
      <CardContent className="p-6 text-center text-red-500">
        {error}
      </CardContent>
    </Card>
  );

  if (!profile) return null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <Trophy className="h-5 w-5" />
          Team Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          {profile.WikipediaLogoUrl && (
            <img 
              src={profile.WikipediaLogoUrl} 
              alt={`${profile.Name} logo`}
              className="w-16 h-16 mx-auto mb-2"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          )}
          <h3 className="text-xl font-bold" style={{ color: profile.PrimaryColor }}>
            {profile.City} {profile.Name}
          </h3>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-teal-600" />
            <span className="text-sm">{profile.City}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Trophy className="h-4 w-4 text-teal-600" />
            <span className="text-sm">{profile.League} - {profile.Division}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Badge 
            variant="outline" 
            style={{ 
              backgroundColor: profile.PrimaryColor + '20',
              borderColor: profile.PrimaryColor,
              color: profile.PrimaryColor
            }}
          >
            {profile.League}
          </Badge>
          <Badge 
            variant="outline"
            style={{ 
              backgroundColor: profile.SecondaryColor + '20',
              borderColor: profile.SecondaryColor,
              color: profile.SecondaryColor
            }}
          >
            {profile.Division}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-sm text-gray-500">Team ID</div>
            <div className="font-medium">{profile.TeamID}</div>
          </div>
          <div>
            <div className="text-sm text-gray-500">Global ID</div>
            <div className="font-medium">{profile.GlobalTeamID}</div>
          </div>
        </div>

        <div className="text-center text-sm text-gray-600 pt-2 border-t">
          <p className="font-medium">🌊 True to the Blue 🌊</p>
          <p className="text-xs">Seattle Mariners - America's Team of the Pacific Northwest</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarinersProfile;