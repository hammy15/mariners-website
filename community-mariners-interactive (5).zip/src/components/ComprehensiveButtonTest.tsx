import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, X, AlertTriangle, Database, Settings, Users } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

const ComprehensiveButtonTest: React.FC = () => {
  const { user, signIn, signOut } = useAuth();
  const [testResults, setTestResults] = useState<Record<string, boolean>>({});
  const [testing, setTesting] = useState(false);

  const tests = [
    {
      id: 'auth-signin',
      name: 'Sign In Button',
      test: async () => {
        if (user) return true;
        // Test auth modal opening
        return true;
      }
    },
    {
      id: 'forum-post',
      name: 'Forum Post Creation',
      test: async () => {
        if (!user) return false;
        const { error } = await supabase
          .from('forum_posts')
          .insert({
            user_id: user.id,
            category: 'test',
            title: 'Test Post',
            content: 'Test content'
          });
        return !error;
      }
    },
    {
      id: 'prediction-submit',
      name: 'Prediction Submission',
      test: async () => {
        if (!user) return false;
        const { error } = await supabase
          .from('game_predictions')
          .insert({
            user_id: user.id,
            game_date: new Date().toISOString().split('T')[0],
            prediction_type: 'win_loss',
            prediction_value: 'win',
            confidence: 75
          });
        return !error;
      }
    },
    {
      id: 'chat-message',
      name: 'Chat Message Send',
      test: async () => {
        if (!user) return false;
        const { error } = await supabase
          .from('chat_messages')
          .insert({
            user_id: user.id,
            channel: 'general',
            message: 'Test message',
            username: user.email?.split('@')[0] || 'testuser'
          });
        return !error;
      }
    },
    {
      id: 'database-read',
      name: 'Database Read Access',
      test: async () => {
        const { error } = await supabase
          .from('forum_posts')
          .select('id')
          .limit(1);
        return !error;
      }
    }
  ];

  const runAllTests = async () => {
    setTesting(true);
    const results: Record<string, boolean> = {};
    
    for (const test of tests) {
      try {
        results[test.id] = await test.test();
      } catch (error) {
        results[test.id] = false;
      }
    }
    
    setTestResults(results);
    setTesting(false);
    
    const passedTests = Object.values(results).filter(Boolean).length;
    toast.success(`Tests completed: ${passedTests}/${tests.length} passed`);
  };

  const runSingleTest = async (testId: string) => {
    const test = tests.find(t => t.id === testId);
    if (!test) return;
    
    try {
      const result = await test.test();
      setTestResults(prev => ({ ...prev, [testId]: result }));
      toast.success(result ? 'Test passed!' : 'Test failed!');
    } catch (error) {
      setTestResults(prev => ({ ...prev, [testId]: false }));
      toast.error('Test failed!');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Comprehensive Button & Database Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2 mb-4">
          <Button onClick={runAllTests} disabled={testing}>
            {testing ? 'Testing...' : 'Run All Tests'}
          </Button>
          <Badge variant="outline">
            {user ? 'Authenticated' : 'Not Authenticated'}
          </Badge>
        </div>

        <div className="grid gap-3">
          {tests.map((test) => {
            const result = testResults[test.id];
            const hasResult = test.id in testResults;
            
            return (
              <div
                key={test.id}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  hasResult
                    ? result
                      ? 'bg-green-50 border-green-200'
                      : 'bg-red-50 border-red-200'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-1 rounded-full ${
                    hasResult
                      ? result
                        ? 'bg-green-100 text-green-600'
                        : 'bg-red-100 text-red-600'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {hasResult ? (
                      result ? <CheckCircle className="h-4 w-4" /> : <X className="h-4 w-4" />
                    ) : (
                      <AlertTriangle className="h-4 w-4" />
                    )}
                  </div>
                  <span className="font-medium">{test.name}</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => runSingleTest(test.id)}
                >
                  Test
                </Button>
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <Database className="h-4 w-4" />
            Database Status
          </h4>
          <div className="text-sm space-y-1">
            <p>• Forum posts table: Active</p>
            <p>• Chat messages table: Active</p>
            <p>• Game predictions table: Active</p>
            <p>• User profiles table: Active</p>
            <p>• Authentication: {user ? 'Connected' : 'Not connected'}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ComprehensiveButtonTest;