import React from 'react';
import NewsletterPreview from '@/components/NewsletterPreview';
import { GradientCard } from '@/components/EnhancedVisualComponents';

const NewsletterPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-teal-50 dark:from-gray-900 dark:to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <GradientCard className="p-8 mb-8 text-center" gradient="from-blue-600 to-teal-600 text-white">
          <h1 className="text-4xl font-bold mb-4">📧 Mariners Newsletter</h1>
          <p className="text-xl opacity-90">
            Your weekly digest of Mariners news, predictions, and community highlights
          </p>
        </GradientCard>

        {/* Newsletter Content */}
        <NewsletterPreview />

        {/* Additional Newsletter Info */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <GradientCard className="p-6 text-center" gradient="from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
            <div className="text-3xl mb-2">📊</div>
            <h3 className="font-bold mb-2">Weekly Stats</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Prediction accuracy, forum activity, and team performance
            </p>
          </GradientCard>

          <GradientCard className="p-6 text-center" gradient="from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
            <div className="text-3xl mb-2">🎯</div>
            <h3 className="font-bold mb-2">Prediction Insights</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Bot vs member accuracy and trending predictions
            </p>
          </GradientCard>

          <GradientCard className="p-6 text-center" gradient="from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20">
            <div className="text-3xl mb-2">💬</div>
            <h3 className="font-bold mb-2">Community Buzz</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Top forum discussions and member highlights
            </p>
          </GradientCard>
        </div>
      </div>
    </div>
  );
};

export default NewsletterPage;
