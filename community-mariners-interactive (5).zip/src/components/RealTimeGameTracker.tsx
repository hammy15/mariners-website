import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Activity, Clock, Users, TrendingUp, Zap, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface GameData {
  gameId: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  inning: number;
  inningHalf: 'top' | 'bottom';
  gameStatus: 'scheduled' | 'live' | 'final' | 'postponed';
  lastUpdate: Date;
  liveStats: LiveStats;
}

interface LiveStats {
  currentBatter: string;
  currentPitcher: string;
  balls: number;
  strikes: number;
  outs: number;
  runnersOnBase: string[];
  recentPlays: Play[];
  momentum: number; // -100 to 100
}

interface Play {
  id: string;
  inning: number;
  description: string;
  timestamp: Date;
  impact: 'positive' | 'negative' | 'neutral';
}

const RealTimeGameTracker: React.FC = () => {
  const [gameData, setGameData] = useState<GameData | null>(null);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  useEffect(() => {
    loadGameData();
    
    if (autoRefresh) {
      const interval = setInterval(loadGameData, 30000); // Update every 30 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const loadGameData = async () => {
    setLoading(true);
    try {
      // Try to get real game data from Supabase function
      const { data: realTimeData } = await supabase.functions.invoke('real-time-game-data');
      
      if (realTimeData?.data) {
        setGameData(realTimeData.data);
      } else {
        // Fallback to mock data
        const mockData = generateMockGameData();
        setGameData(mockData);
      }
      
      setLastRefresh(new Date());
    } catch (error) {
      console.error('Error loading game data:', error);
      // Use fallback data
      const fallbackData = generateMockGameData();
      setGameData(fallbackData);
    }
    setLoading(false);
  };

  const generateMockGameData = (): GameData => {
    const isLive = Math.random() > 0.3;
    const inning = Math.floor(Math.random() * 9) + 1;
    
    return {
      gameId: 'sea-vs-hou-live',
      homeTeam: 'Seattle Mariners',
      awayTeam: 'Houston Astros',
      homeScore: Math.floor(Math.random() * 8),
      awayScore: Math.floor(Math.random() * 8),
      inning,
      inningHalf: Math.random() > 0.5 ? 'top' : 'bottom',
      gameStatus: isLive ? 'live' : (Math.random() > 0.5 ? 'scheduled' : 'final'),
      lastUpdate: new Date(),
      liveStats: {
        currentBatter: 'J. Rodriguez',
        currentPitcher: 'F. Valdez',
        balls: Math.floor(Math.random() * 4),
        strikes: Math.floor(Math.random() * 3),
        outs: Math.floor(Math.random() * 3),
        runnersOnBase: ['1B', '3B'].slice(0, Math.floor(Math.random() * 3)),
        recentPlays: generateRecentPlays(),
        momentum: (Math.random() - 0.5) * 200 // -100 to 100
      }
    };
  };

  const generateRecentPlays = (): Play[] => {
    const plays = [
      'Single to right field',
      'Strikeout swinging',
      'Ground out to second',
      'Home run to left field!',
      'Walk',
      'Double to center field',
      'Fly out to center',
      'Stolen base',
      'Wild pitch',
      'Sacrifice fly'
    ];

    return Array.from({ length: 5 }, (_, i) => ({
      id: `play-${i}`,
      inning: Math.floor(Math.random() * 9) + 1,
      description: plays[Math.floor(Math.random() * plays.length)],
      timestamp: new Date(Date.now() - i * 120000), // 2 minutes apart
      impact: Math.random() > 0.6 ? 'positive' : Math.random() > 0.3 ? 'negative' : 'neutral'
    }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-500';
      case 'final': return 'bg-gray-500';
      case 'scheduled': return 'bg-blue-500';
      case 'postponed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getMomentumColor = (momentum: number) => {
    if (momentum > 30) return 'text-green-600';
    if (momentum < -30) return 'text-red-600';
    return 'text-gray-600';
  };

  const getPlayImpactColor = (impact: string) => {
    switch (impact) {
      case 'positive': return 'text-green-600';
      case 'negative': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  if (loading && !gameData) {
    return (
      <Card className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </Card>
    );
  }

  if (!gameData) {
    return (
      <Card className="p-6">
        <p className="text-center text-gray-500">No game data available</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold flex items-center">
            <Activity className="mr-2 h-6 w-6" />
            Live Game Tracker
          </h2>
          
          <div className="flex items-center space-x-3">
            <Badge className={getStatusColor(gameData.gameStatus)}>
              {gameData.gameStatus.toUpperCase()}
            </Badge>
            
            <Button
              size="sm"
              variant="outline"
              onClick={loadGameData}
              disabled={loading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Score Display */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <Card className="p-4 text-center">
            <h3 className="font-bold text-lg mb-2">{gameData.awayTeam}</h3>
            <div className="text-3xl font-bold text-blue-600">{gameData.awayScore}</div>
          </Card>
          
          <Card className="p-4 text-center">
            <h3 className="font-bold text-lg mb-2">{gameData.homeTeam}</h3>
            <div className="text-3xl font-bold text-green-600">{gameData.homeScore}</div>
          </Card>
        </div>

        {/* Game Status */}
        {gameData.gameStatus === 'live' && (
          <Card className="p-4 mb-6 bg-green-50 border-green-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span className="font-semibold">
                    {gameData.inningHalf === 'top' ? 'Top' : 'Bottom'} {gameData.inning}
                  </span>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">
                    {gameData.liveStats.currentBatter} vs {gameData.liveStats.currentPitcher}
                  </span>
                </div>
              </div>
              
              <div className={`flex items-center space-x-2 ${getMomentumColor(gameData.liveStats.momentum)}`}>
                <TrendingUp className="h-4 w-4" />
                <span className="font-semibold">
                  Momentum: {gameData.liveStats.momentum > 0 ? '+' : ''}{gameData.liveStats.momentum.toFixed(0)}
                </span>
              </div>
            </div>

            {/* Count and Situation */}
            <div className="grid grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-xs text-gray-600">Balls</div>
                <div className="text-lg font-bold">{gameData.liveStats.balls}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Strikes</div>
                <div className="text-lg font-bold">{gameData.liveStats.strikes}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Outs</div>
                <div className="text-lg font-bold">{gameData.liveStats.outs}</div>
              </div>
              <div>
                <div className="text-xs text-gray-600">Runners</div>
                <div className="text-sm font-semibold">
                  {gameData.liveStats.runnersOnBase.length > 0 
                    ? gameData.liveStats.runnersOnBase.join(', ')
                    : 'None'
                  }
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Recent Plays */}
        <Card className="p-4">
          <h3 className="font-bold mb-3 flex items-center">
            <Zap className="mr-2 h-4 w-4" />
            Recent Plays
          </h3>
          
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {gameData.liveStats.recentPlays.map((play) => (
              <div key={play.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <div className="flex-1">
                  <span className={`font-medium ${getPlayImpactColor(play.impact)}`}>
                    {play.description}
                  </span>
                  <div className="text-xs text-gray-500">
                    Inning {play.inning} • {play.timestamp.toLocaleTimeString()}
                  </div>
                </div>
                
                <Badge 
                  variant="outline" 
                  className={`text-xs ${
                    play.impact === 'positive' ? 'border-green-300 text-green-700' :
                    play.impact === 'negative' ? 'border-red-300 text-red-700' :
                    'border-gray-300 text-gray-700'
                  }`}
                >
                  {play.impact}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Auto-refresh toggle */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoRefresh"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded"
            />
            <label htmlFor="autoRefresh" className="text-sm">
              Auto-refresh every 30 seconds
            </label>
          </div>
          
          <div className="text-xs text-gray-500">
            Last updated: {lastRefresh.toLocaleTimeString()}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default RealTimeGameTracker;