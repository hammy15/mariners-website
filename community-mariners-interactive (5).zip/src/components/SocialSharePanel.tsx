import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import SocialShareButton from './SocialShareButton';

interface SocialSharePanelProps {
  url?: string;
  title?: string;
  description?: string;
  showTitle?: boolean;
}

const SocialSharePanel: React.FC<SocialSharePanelProps> = ({
  url,
  title,
  description,
  showTitle = true
}) => {
  return (
    <Card className="w-full">
      {showTitle && (
        <CardHeader>
          <CardTitle className="text-lg">Share with Fellow Fans</CardTitle>
        </CardHeader>
      )}
      <CardContent className={showTitle ? '' : 'pt-6'}>
        <div className="flex flex-wrap gap-2">
          <SocialShareButton
            platform="facebook"
            url={url}
            title={title}
            description={description}
          />
          <SocialShareButton
            platform="twitter"
            url={url}
            title={title}
            description={description}
          />
          <SocialShareButton
            platform="reddit"
            url={url}
            title={title}
            description={description}
          />
          <SocialShareButton
            platform="generic"
            url={url}
            title={title}
            description={description}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default SocialSharePanel;