import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Users, MapPin, Calendar } from 'lucide-react';

const TeamProfile: React.FC = () => {
  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Users className="h-5 w-5" />
          Team Profile
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm">T-Mobile Park, Seattle</span>
        </div>
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm">Founded 1977</span>
        </div>
        <div className="flex flex-wrap gap-1 mt-2">
          <Badge variant="secondary" className="text-xs">AL West</Badge>
          <Badge variant="secondary" className="text-xs">47,929 Capacity</Badge>
        </div>
        <div className="text-xs text-muted-foreground mt-2">
          <p>Manager: Scott Servais</p>
          <p>Colors: Navy, Teal, Silver</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TeamProfile;