import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { MessageSquare, Clock, Archive, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

const AutomatedForumManager = () => {
  const [todaysGame, setTodaysGame] = useState({
    opponent: 'Oakland Athletics',
    gameTime: '7:10 PM PST',
    date: new Date().toLocaleDateString(),
    status: 'scheduled',
    threadId: null,
    participants: 0
  });

  const [forumTopics] = useState([
    {
      id: 'todays-game',
      title: "Today's Game Discussion",
      description: 'Auto-generated 1 hour before first pitch',
      type: 'automated',
      status: 'active',
      posts: 23,
      lastActivity: '2 minutes ago'
    },
    {
      id: 'temp-check',
      title: 'Temp Check',
      description: 'How are we feeling about playoff chances?',
      type: 'ongoing',
      status: 'active',
      posts: 156,
      lastActivity: '15 minutes ago'
    },
    {
      id: 'off-my-chest',
      title: 'Off My Chest',
      description: 'Respectfully share your thoughts on team/coaching',
      type: 'ongoing',
      status: 'active',
      posts: 89,
      lastActivity: '1 hour ago'
    }
  ]);

  const [profanityFilter] = useState({
    enabled: true,
    blockedWords: 47,
    autoModeration: true,
    lastUpdate: 'Today'
  });

  const createTodaysGameThread = async () => {
    try {
      // Auto-create game thread 1 hour before first pitch
      const gameThread = {
        title: `Game Day Discussion: Mariners vs ${todaysGame.opponent}`,
        content: `Welcome to today's game discussion! 🎾⚾\n\nGame Info:\n- Opponent: ${todaysGame.opponent}\n- Time: ${todaysGame.gameTime}\n- Date: ${todaysGame.date}\n\nLet's discuss lineups, predictions, and cheer on our M's!`,
        type: 'game-day',
        autoClose: 'midnight PST'
      };
      
      // In real app, would create in database
      console.log('Creating game thread:', gameThread);
      
    } catch (error) {
      console.error('Error creating game thread:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Forum Management</h2>
        <Badge variant="outline">Auto-Moderated</Badge>
      </div>

      {/* Today's Game Status */}
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Today's Game Thread
          </h3>
          <Badge variant={todaysGame.status === 'active' ? 'default' : 'secondary'}>
            {todaysGame.status}
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-sm text-gray-600">Opponent</div>
            <div className="font-semibold">{todaysGame.opponent}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Game Time</div>
            <div className="font-semibold">{todaysGame.gameTime}</div>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <Button onClick={createTodaysGameThread} size="sm">
            Create Game Thread
          </Button>
          <span className="text-sm text-gray-600 flex items-center gap-1">
            <Clock className="h-4 w-4" />
            Auto-creates 1hr before first pitch
          </span>
        </div>
      </Card>

      {/* Forum Topics */}
      <div className="grid gap-4">
        {forumTopics.map(topic => (
          <Card key={topic.id} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold">{topic.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{topic.description}</p>
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span>{topic.posts} posts</span>
                  <span>Last: {topic.lastActivity}</span>
                </div>
              </div>
              <div className="text-right">
                <Badge variant={topic.status === 'active' ? 'default' : 'secondary'}>
                  {topic.status}
                </Badge>
                <div className="text-xs text-gray-500 mt-1">{topic.type}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Profanity Filter Status */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-yellow-500" />
            Content Moderation
          </h3>
          <Badge variant={profanityFilter.enabled ? 'default' : 'destructive'}>
            {profanityFilter.enabled ? 'Active' : 'Disabled'}
          </Badge>
        </div>
        
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-red-600">{profanityFilter.blockedWords}</div>
            <div className="text-sm text-gray-600">Blocked Words</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-green-600">Auto</div>
            <div className="text-sm text-gray-600">Moderation</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-600">{profanityFilter.lastUpdate}</div>
            <div className="text-sm text-gray-600">Last Update</div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default AutomatedForumManager;