import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';

interface ConnectionDiagnostics {
  status: string;
  url?: string;
  hasKey?: boolean;
  responseStatus?: number;
  error?: string;
  timestamp: string;
}

export const ConnectionStatus: React.FC = () => {
  const [status, setStatus] = useState<'checking' | 'connected' | 'error'>('checking');
  const [diagnostics, setDiagnostics] = useState<ConnectionDiagnostics | null>(null);
  const [loading, setLoading] = useState(false);

  const testConnection = async () => {
    setLoading(true);
    setStatus('checking');
    
    try {
      // Test direct Supabase connection
      const { data, error } = await supabase.from('users').select('count').limit(1);
      
      if (error) {
        setStatus('error');
        setDiagnostics({
          status: 'Direct Connection Failed',
          error: error.message,
          timestamp: new Date().toISOString()
        });
      } else {
        setStatus('connected');
        setDiagnostics({
          status: 'Connected',
          timestamp: new Date().toISOString()
        });
      }
    } catch (err) {
      // Fallback to edge function diagnostics
      try {
        const { data: funcData, error: funcError } = await supabase.functions.invoke('system-health-check');
        
        if (funcError) {
          setStatus('error');
          setDiagnostics({
            status: 'Function Test Failed',
            error: funcError.message,
            timestamp: new Date().toISOString()
          });
        } else {
          setStatus(funcData.status === 'Connected' ? 'connected' : 'error');
          setDiagnostics(funcData);
        }
      } catch (finalErr) {
        setStatus('error');
        setDiagnostics({
          status: 'All Tests Failed',
          error: finalErr instanceof Error ? finalErr.message : 'Unknown error',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    setLoading(false);
  };

  useEffect(() => {
    testConnection();
  }, []);

  const getStatusIcon = () => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <RefreshCw className={`h-5 w-5 text-blue-500 ${loading ? 'animate-spin' : ''}`} />;
    }
  };

  const getStatusBadge = () => {
    switch (status) {
      case 'connected':
        return <Badge variant="default" className="bg-green-500">Connected</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Checking...</Badge>;
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          Database Status
          {getStatusBadge()}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {diagnostics && (
          <div className="text-sm space-y-2">
            <div><strong>Status:</strong> {diagnostics.status}</div>
            {diagnostics.url && <div><strong>URL:</strong> {diagnostics.url}</div>}
            {diagnostics.hasKey !== undefined && (
              <div><strong>API Key:</strong> {diagnostics.hasKey ? 'Present' : 'Missing'}</div>
            )}
            {diagnostics.responseStatus && (
              <div><strong>Response:</strong> {diagnostics.responseStatus}</div>
            )}
            {diagnostics.error && (
              <div className="text-red-600"><strong>Error:</strong> {diagnostics.error}</div>
            )}
            <div className="text-xs text-gray-500">
              Last checked: {new Date(diagnostics.timestamp).toLocaleString()}
            </div>
          </div>
        )}
        <Button 
          onClick={testConnection} 
          disabled={loading}
          className="w-full"
          variant="outline"
        >
          {loading ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : null}
          Test Connection
        </Button>
      </CardContent>
    </Card>
  );
};