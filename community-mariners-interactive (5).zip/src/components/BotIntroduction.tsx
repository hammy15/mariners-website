import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bot, Shield, TrendingUp } from 'lucide-react';

const BotIntroduction = () => {
  const bots = [
    {
      name: 'Marty',
      icon: <Bot className="h-6 w-6" />,
      role: 'Site Manager & Organizer',
      personality: 'Funny, helpful, and incredibly knowledgeable about the Mariners and MLB',
      description: 'Your go-to guide for everything Mariners. Marty keeps things fun while providing expert insights and helping you navigate the community.',
      color: 'bg-green-500',
      traits: ['Humorous', 'Knowledgeable', 'Helpful', 'Organized']
    },
    {
      name: 'Captain',
      icon: <Shield className="h-6 w-6" />,
      role: 'Technical Analyst',
      personality: 'Calm, stats-driven, and technical',
      description: 'A lifelong Mariners fan who approaches the game through data and analytics. Captain provides deep statistical insights and technical analysis.',
      color: 'bg-blue-500',
      traits: ['Analytical', 'Calm', 'Technical', 'Data-Driven']
    },
    {
      name: 'Spartan',
      icon: <TrendingUp className="h-6 w-6" />,
      role: 'Strategic Advisor',
      personality: 'Strategic, stats-driven, and tactical',
      description: 'Another devoted Mariners fan who excels at strategic thinking. Spartan works perfectly with Captain, offering complementary perspectives on game strategy.',
      color: 'bg-red-500',
      traits: ['Strategic', 'Tactical', 'Insightful', 'Collaborative']
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">Meet Your AI Companions</h2>
        <p className="text-muted-foreground">
          Three unique personalities ready to chat, analyze, and enhance your Mariners experience
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {bots.map((bot) => (
          <Card key={bot.name} className="glass-effect glow-effect fade-in">
            <CardHeader className="text-center">
              <div className={`w-16 h-16 ${bot.color} rounded-full flex items-center justify-center mx-auto mb-4 text-white`}>
                {bot.icon}
              </div>
              <CardTitle className="text-xl">{bot.name}</CardTitle>
              <Badge variant="secondary" className="mx-auto">
                {bot.role}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground italic">
                "{bot.personality}"
              </p>
              <p className="text-sm leading-relaxed">
                {bot.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {bot.traits.map((trait) => (
                  <Badge key={trait} variant="outline" className="text-xs">
                    {trait}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card className="glass-effect">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <h3 className="text-lg font-semibold">Interactive & Learning</h3>
            <p className="text-sm text-muted-foreground">
              All three bots learn from forum discussions, current events, and real-time game data. 
              Your conversations are stored and remembered, creating personalized interactions that improve over time.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BotIntroduction;