import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Search, TrendingUp, TrendingDown } from 'lucide-react';

interface PlayerStat {
  playerId: string;
  name: string;
  team: string;
  position: string;
  avg: string;
  hr: number;
  rbi: number;
  ops: string;
  trend: 'up' | 'down' | 'stable';
}

const PlayerStats: React.FC = () => {
  const [players, setPlayers] = useState<PlayerStat[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchMarinersPlayers();
  }, []);

  const fetchMarinersPlayers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mlb-live-stats', {
        body: { 
          endpoint: 'getMLBPlayerStats',
          params: { teamID: 'SEA', season: '2024' }
        }
      });

      if (error) throw error;
      
      const playerStats = data?.players?.slice(0, 8).map((player: any) => ({
        playerId: player.playerID,
        name: player.longName || player.name,
        team: 'SEA',
        position: player.pos,
        avg: player.avg || '.000',
        hr: player.hr || 0,
        rbi: player.rbi || 0,
        ops: player.ops || '.000',
        trend: Math.random() > 0.5 ? 'up' : 'down'
      })) || [];

      setPlayers(playerStats);
    } catch (error) {
      console.error('Error fetching player stats:', error);
      // Mock data fallback
      setPlayers([
        { playerId: '1', name: 'Julio Rodríguez', team: 'SEA', position: 'OF', avg: '.284', hr: 28, rbi: 89, ops: '.848', trend: 'up' },
        { playerId: '2', name: 'Cal Raleigh', team: 'SEA', position: 'C', avg: '.220', hr: 30, rbi: 101, ops: '.815', trend: 'up' },
        { playerId: '3', name: 'Eugenio Suárez', team: 'SEA', position: '3B', avg: '.232', hr: 22, rbi: 92, ops: '.756', trend: 'down' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filteredPlayers = players.filter(player =>
    player.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Player Stats & Comparisons
          <Badge variant="outline">2024 Season</Badge>
        </CardTitle>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search players..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">
            {[1,2,3].map(i => <div key={i} className="animate-pulse bg-gray-200 h-16 rounded" />)}
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {filteredPlayers.map((player) => (
              <div key={player.playerId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold">{player.name}</span>
                    <Badge variant="secondary" className="text-xs">{player.position}</Badge>
                    {player.trend === 'up' ? 
                      <TrendingUp className="h-4 w-4 text-green-500" /> : 
                      <TrendingDown className="h-4 w-4 text-red-500" />
                    }
                  </div>
                  <div className="text-sm text-gray-600">
                    AVG: {player.avg} | HR: {player.hr} | RBI: {player.rbi} | OPS: {player.ops}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PlayerStats;