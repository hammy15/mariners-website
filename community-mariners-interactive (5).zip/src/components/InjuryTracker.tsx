import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { AlertTriangle, Clock, Activity } from 'lucide-react';

const InjuryTracker: React.FC = () => {
  const injuries = [
    { player: 'Fernando Tatis Jr.', team: 'SD', injury: 'Shoulder', status: 'Day-to-Day', severity: 'minor', eta: '3-5 days' },
    { player: 'Jacob deGrom', team: 'TEX', injury: 'Elbow', status: 'IL-15', severity: 'major', eta: '4-6 weeks' },
    { player: 'Byron Buxton', team: 'MIN', injury: 'Knee', status: 'IL-10', severity: 'moderate', eta: '1-2 weeks' }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'minor': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'moderate': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400';
      case 'major': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  return (
    <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          Injury Report
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {injuries.map((injury, i) => (
            <div key={i} className="p-3 bg-white/50 dark:bg-gray-800/50 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-medium">{injury.player}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{injury.team}</p>
                </div>
                <Badge className={getSeverityColor(injury.severity)}>
                  {injury.severity}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Activity className="h-3 w-3" />
                  {injury.injury}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {injury.eta}
                </div>
              </div>
              <Badge variant="outline" className="mt-2">
                {injury.status}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default InjuryTracker;