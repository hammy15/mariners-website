# TridentFans Deployment Guide

## Connection Issues Troubleshooting

If you're experiencing connection issues with the web domain, follow these steps:

### 1. Environment Variables Setup

Make sure your `.env.local` file exists in the root directory with:

```
VITE_SUPABASE_URL=https://zsiwvovthbccyhublgch.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpzaXd2b3Z0aGJjY3lodWJsZ2NoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQ5NzY4NjEsImV4cCI6MjA1MDU1Mjg2MX0.iwpoQLs16HxDZpiR566nqQ_aklxvNNF-gZyBmPuCKzU
```

### 2. Build and Deploy

For local development:
```bash
npm install
npm run dev
```

For production build:
```bash
npm run build
npm run preview
```

### 3. Deployment Platforms

#### Vercel Deployment:
1. Connect your GitHub repository to Vercel
2. Add environment variables in Vercel dashboard
3. Deploy automatically on push

#### Netlify Deployment:
1. Connect repository to Netlify
2. Set build command: `npm run build`
3. Set publish directory: `dist`
4. Add environment variables in Netlify settings

### 4. Domain Configuration

If using a custom domain:
1. Update DNS settings to point to your hosting provider
2. Configure SSL certificate
3. Update CORS settings in Supabase if needed

### 5. Connection Status

The app now includes a connection status indicator on the home page that will show:
- ✅ Green: Database connected successfully
- ❌ Red: Connection failed with error details
- 🔄 Loading: Checking connection

### 6. Common Issues

- **CORS Errors**: Check Supabase project settings for allowed origins
- **Environment Variables**: Ensure they're properly set in your deployment platform
- **Build Errors**: Run `npm run build` locally to test before deploying
- **Database Access**: Verify Supabase project is active and accessible

### 7. Testing Connection

Visit your deployed site and check the connection status indicator. If it shows an error, check:
1. Supabase project status
2. Environment variables
3. Network connectivity
4. Browser console for detailed error messages