# GoDaddy DNS Configuration - Step by Step

## Access GoDaddy DNS Management
1. Login to https://account.godaddy.com
2. Go to "My Products" → "All Products and Services"
3. Find your domain `tridentfans.com`
4. Click "DNS" button next to your domain

## Required DNS Records

### Method 1: A Record (Recommended)
**Delete existing A records first, then add:**

| Type | Name | Value | TTL |
|------|------|--------|-----|
| A | @ | 76.76.19.61 | 1 Hour |
| A | www | 76.76.19.61 | 1 Hour |

### Method 2: CNAME (Alternative)
**If A records don't work:**

| Type | Name | Value | TTL |
|------|------|--------|-----|
| CNAME | @ | cname.vercel-dns.com | 1 Hour |
| CNAME | www | cname.vercel-dns.com | 1 Hour |

## Step-by-Step Instructions

### 1. Clear Existing Records
- Delete any existing A records pointing to @ or www
- Delete any CNAME records for @ or www
- Keep MX records (email) if you have them

### 2. Add New Records
- Click "Add Record"
- Select "A" from dropdown
- Name: @ (for root domain)
- Value: 76.76.19.61
- TTL: 1 Hour
- Click "Save"

### 3. Add WWW Record
- Click "Add Record" again
- Select "A" from dropdown  
- Name: www
- Value: 76.76.19.61
- TTL: 1 Hour
- Click "Save"

## Verification
- Wait 10-60 minutes for changes
- Test: `nslookup tridentfans.com`
- Should return: 76.76.19.61