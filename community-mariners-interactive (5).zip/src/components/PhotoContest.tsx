import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, Camera, Trophy, Upload } from 'lucide-react';

interface Photo {
  id: string;
  title: string;
  author: string;
  imageUrl: string;
  likes: number;
  category: string;
  timestamp: string;
}

const PhotoContest: React.FC = () => {
  const [photos] = useState<Photo[]>([
    {
      id: '1',
      title: 'T-Mobile Park Sunset',
      author: 'MarinersFan2024',
      imageUrl: '/placeholder.svg',
      likes: 127,
      category: 'Stadium',
      timestamp: '2 days ago'
    },
    {
      id: '2',
      title: 'Julio\'s Amazing Catch',
      author: 'BaseballPhotog',
      imageUrl: '/placeholder.svg',
      likes: 89,
      category: 'Action',
      timestamp: '1 day ago'
    },
    {
      id: '3',
      title: 'Tailgate Setup',
      author: 'TridentTailgater',
      imageUrl: '/placeholder.svg',
      likes: 56,
      category: 'Fan Life',
      timestamp: '3 hours ago'
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const categories = ['all', 'Stadium', 'Action', 'Fan Life', 'Vintage'];

  const filteredPhotos = photos.filter(photo => 
    selectedCategory === 'all' || photo.category === selectedCategory
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Camera className="mr-2 h-5 w-5" />
            Photo Contest & Fan Art
          </span>
          <Button size="sm" className="bg-teal-600 hover:bg-teal-700">
            <Upload className="mr-2 h-4 w-4" />
            Submit Photo
          </Button>
        </CardTitle>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="capitalize"
            >
              {category}
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredPhotos.map((photo) => (
            <div key={photo.id} className="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video bg-gray-200 flex items-center justify-center">
                <Camera className="h-12 w-12 text-gray-400" />
              </div>
              <div className="p-3">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-sm">{photo.title}</h3>
                  <Badge variant="secondary" className="text-xs">
                    {photo.category}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>by {photo.author}</span>
                  <span>{photo.timestamp}</span>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600">
                    <Heart className="mr-1 h-4 w-4" />
                    {photo.likes}
                  </Button>
                  <div className="flex items-center space-x-1">
                    <Trophy className="h-4 w-4 text-yellow-500" />
                    <span className="text-xs text-gray-600">Contest Entry</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-teal-50 rounded-lg">
          <h4 className="font-semibold text-teal-800 mb-2">Monthly Contest: "Best Stadium Moment"</h4>
          <p className="text-sm text-teal-700 mb-3">
            Share your favorite T-Mobile Park memories! Winner gets season tickets upgrade.
          </p>
          <div className="flex items-center justify-between">
            <span className="text-xs text-teal-600">Ends in 12 days</span>
            <Button size="sm" variant="outline" className="border-teal-300 text-teal-700">
              View Rules
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PhotoContest;