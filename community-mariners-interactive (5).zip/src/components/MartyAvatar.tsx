import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { MessageCircle, X, Bot } from 'lucide-react';

const MartyAvatar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed top-52 right-4 z-50">
      {isOpen && (
        <Card className="w-80 h-96 mb-4 p-4 shadow-lg">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold">Marty BoomStick</h3>
                <p className="text-xs text-muted-foreground">Your Mariners AI Companion</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="h-64 bg-muted/30 rounded-lg p-3 mb-4 overflow-y-auto">
            <div className="space-y-3">
              <div className="bg-teal-100 dark:bg-teal-900 p-2 rounded-lg">
                <p className="text-sm">
                  Hey there, Mariners fan! I'm Marty, your personal baseball companion. 
                  Ask me about stats, games, or just chat about the team!
                </p>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <input
              className="flex-1 px-3 py-2 text-sm border rounded-md"
              placeholder="Chat with Marty..."
            />
            <Button size="sm" className="bg-teal-600 hover:bg-teal-700">Send</Button>
          </div>
        </Card>
      )}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-full w-14 h-14 bg-teal-600 hover:bg-teal-700 shadow-lg"
      >
        <Bot className="h-7 w-7" />
      </Button>
    </div>
  );
};

export default MartyAvatar;