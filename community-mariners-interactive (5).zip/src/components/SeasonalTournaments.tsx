import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Calendar, Users, Star, Award, Crown } from 'lucide-react';

const SeasonalTournaments: React.FC = () => {
  const [selectedTournament, setSelectedTournament] = useState<string | null>(null);

  const tournaments = [
    {
      id: 'spring-training',
      name: 'Spring Training Challenge',
      status: 'completed',
      startDate: '2024-02-15',
      endDate: '2024-03-28',
      participants: 156,
      prize: 'Season Ticket Upgrade',
      winner: 'MarinersOracle',
      description: 'Predict outcomes for all Spring Training games'
    },
    {
      id: 'opening-series',
      name: 'Opening Series Showdown',
      status: 'active',
      startDate: '2024-03-28',
      endDate: '2024-04-03',
      participants: 234,
      prize: 'Autographed Baseball',
      description: 'Perfect predictions for the opening homestand'
    },
    {
      id: 'summer-slam',
      name: 'Summer Slam Tournament',
      status: 'upcoming',
      startDate: '2024-06-01',
      endDate: '2024-08-31',
      participants: 0,
      prize: 'VIP Game Experience',
      description: 'Season-long tournament with monthly eliminations'
    }
  ];

  const leaderboard = [
    { rank: 1, username: 'MarinersOracle', points: 2847, accuracy: 89.2, badge: 'Oracle' },
    { rank: 2, username: 'SeattleSharp', points: 2691, accuracy: 86.7, badge: 'Expert' },
    { rank: 3, username: 'TridentTruth', points: 2534, accuracy: 84.1, badge: 'Expert' },
    { rank: 4, username: 'BaseballBrain', points: 2398, accuracy: 81.5, badge: 'Sharp' },
    { rank: 5, username: 'DiamondDiviner', points: 2287, accuracy: 79.8, badge: 'Sharp' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'completed': return 'bg-gray-500';
      case 'upcoming': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-5 w-5 text-yellow-500" />;
      case 2: return <Award className="h-5 w-5 text-gray-400" />;
      case 3: return <Star className="h-5 w-5 text-amber-600" />;
      default: return <Trophy className="h-5 w-5 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Seasonal Tournaments</h2>
        <Badge variant="outline" className="flex items-center space-x-1">
          <Users className="h-3 w-3" />
          <span>Active Players: 234</span>
        </Badge>
      </div>

      <Tabs defaultValue="tournaments" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="tournaments" className="space-y-4">
          {tournaments.map((tournament) => (
            <Card key={tournament.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5" />
                    <span>{tournament.name}</span>
                  </CardTitle>
                  <Badge className={`${getStatusColor(tournament.status)} text-white`}>
                    {tournament.status.charAt(0).toUpperCase() + tournament.status.slice(1)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-4">{tournament.description}</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Calendar className="h-3 w-3" />
                      <span>Start</span>
                    </div>
                    <div className="font-medium">{new Date(tournament.startDate).toLocaleDateString()}</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Calendar className="h-3 w-3" />
                      <span>End</span>
                    </div>
                    <div className="font-medium">{new Date(tournament.endDate).toLocaleDateString()}</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Users className="h-3 w-3" />
                      <span>Players</span>
                    </div>
                    <div className="font-medium">{tournament.participants}</div>
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Trophy className="h-3 w-3" />
                      <span>Prize</span>
                    </div>
                    <div className="font-medium">{tournament.prize}</div>
                  </div>
                </div>

                {tournament.winner && (
                  <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Crown className="h-4 w-4 text-yellow-600" />
                      <span className="text-sm font-medium">Winner: {tournament.winner}</span>
                    </div>
                  </div>
                )}

                <div className="mt-4 flex justify-end">
                  <Button 
                    variant={tournament.status === 'active' ? 'default' : 'outline'}
                    disabled={tournament.status === 'completed'}
                  >
                    {tournament.status === 'active' ? 'Join Tournament' : 
                     tournament.status === 'upcoming' ? 'Register Interest' : 'View Results'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tournament Champions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((player) => (
                  <div key={player.rank} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
                    <div className="flex items-center space-x-3">
                      {getRankIcon(player.rank)}
                      <div>
                        <div className="font-medium">{player.username}</div>
                        <div className="text-sm text-gray-500">
                          {player.accuracy}% accuracy • {player.badge}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg">{player.points}</div>
                      <div className="text-sm text-gray-500">points</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SeasonalTournaments;