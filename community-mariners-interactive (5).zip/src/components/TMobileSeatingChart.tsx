import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Search, MapPin, Phone } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import StadiumMacroView from './StadiumMacroView';
import SeatPhotoDisplay from './SeatPhotoDisplay';

interface SeatPhoto {
  id: string;
  seat_section: string;
  seat_row: string;
  seat_number: string;
  photo_url: string;
  view_description: string;
  submission_date: string;
}

const TMobileSeatingChart: React.FC = () => {
  const [seatPhotos, setSeatPhotos] = useState<SeatPhoto[]>([]);
  const [searchSeat, setSearchSeat] = useState('');
  const [selectedSeat, setSelectedSeat] = useState<SeatPhoto | null>(null);
  const [hoveredSeat, setHoveredSeat] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSeatPhotos();
  }, []);

  const fetchSeatPhotos = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('seat_photos')
        .select('*')
        .eq('is_approved', true)
        .order('submission_date', { ascending: false });
      
      if (error) throw error;
      setSeatPhotos(data || []);
    } catch (error) {
      console.error('Error fetching seat photos:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchForSeat = () => {
    const seat = seatPhotos.find(photo => 
      `${photo.seat_section}-${photo.seat_row}-${photo.seat_number}`.toLowerCase()
        .includes(searchSeat.toLowerCase()) ||
      photo.seat_section.toLowerCase().includes(searchSeat.toLowerCase())
    );
    setSelectedSeat(seat || null);
    if (!seat) {
      alert('No photos found for that seat. Be the first to submit one!');
    }
  };

  const handleSectionClick = (section: string) => {
    const photo = seatPhotos.find(p => p.seat_section === section);
    setSelectedSeat(photo || null);
  };

  const seatingAreas = [
    { name: 'Home Plate Box', sections: ['136', '137', '138', '139', '140', '141'] },
    { name: 'Infield Box', sections: ['142', '143', '144', '145', '146', '147'] },
    { name: 'Outfield', sections: ['149', '150', '151', '152', '153'] },
    { name: 'Upper Deck', sections: ['300', '301', '302', '303', '304'] },
    { name: 'Bleachers', sections: ['180', '181', '182', '183'] }
  ];

  return (
    <Card className="w-full max-w-6xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-teal-600">
          <MapPin className="h-5 w-5" />
          T-Mobile Park Seat Views
        </CardTitle>
        <div className="flex gap-2">
          <Input
            placeholder="Search seat (e.g., 136 or 136-A-15)"
            value={searchSeat}
            onChange={(e) => setSearchSeat(e.target.value)}
            className="flex-1"
            onKeyPress={(e) => e.key === 'Enter' && searchForSeat()}
          />
          <Button onClick={searchForSeat} size="sm" disabled={loading}>
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* SMS Instructions */}
        <div className="p-4 bg-teal-50 rounded-lg border border-teal-200">
          <div className="flex items-center gap-2 mb-2">
            <Phone className="h-4 w-4 text-teal-600" />
            <span className="font-semibold text-teal-800">Submit Your Seat View!</span>
          </div>
          <p className="text-sm text-teal-700">
            Text a wide-angle photo of the pitcher's mound from your seat to{' '}
            <strong className="text-teal-800">(206) 555-SEAT</strong> with format: 
            "SECTION ROW SEAT" (e.g., "136 A 15")
          </p>
        </div>

        {/* Stadium Macro View */}
        <StadiumMacroView 
          onSectionClick={handleSectionClick}
          seatPhotos={seatPhotos}
        />

        <SeatPhotoDisplay
          selectedSeat={selectedSeat}
          hoveredSeat={hoveredSeat}
          seatPhotos={seatPhotos}
        />

        {/* Recent Submissions */}
        <div>
          <h4 className="font-semibold mb-3 text-gray-800">Recent Seat Views</h4>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading seat photos...</div>
          ) : seatPhotos.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No seat photos yet. Be the first to submit one!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {seatPhotos.slice(0, 6).map((photo) => (
                <div 
                  key={photo.id} 
                  className="border rounded-lg p-3 cursor-pointer hover:shadow-md transition-shadow bg-white"
                  onClick={() => setSelectedSeat(photo)}
                >
                  <Badge variant="outline" className="mb-2 text-teal-600 border-teal-200">
                    {photo.seat_section}-{photo.seat_row}-{photo.seat_number}
                  </Badge>
                  {photo.photo_url && (
                    <img 
                      src={photo.photo_url} 
                      alt={photo.view_description}
                      className="w-full h-24 object-cover rounded mb-2"
                      loading="lazy"
                    />
                  )}
                  <p className="text-xs text-gray-600 truncate">{photo.view_description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TMobileSeatingChart;