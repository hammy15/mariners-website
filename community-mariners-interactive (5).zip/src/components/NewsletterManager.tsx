import React, { useState, useEffect } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { supabase } from '@/lib/supabase';

const NewsletterManager = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    daily: 0,
    weekly: 0,
    gameday: 0,
    total: 0
  });

  useEffect(() => {
    fetchSubscriptions();
  }, []);

  const fetchSubscriptions = async () => {
    try {
      const { data, error } = await supabase
        .from('newsletter_subscriptions')
        .select('*');
      
      if (data) {
        setSubscriptions(data);
        const dailyCount = data.filter(s => s.daily_digest).length;
        const weeklyCount = data.filter(s => s.weekly_wrap).length;
        const gamedayCount = data.filter(s => s.gameday_updates).length;
        
        setStats({
          daily: dailyCount,
          weekly: weeklyCount,
          gameday: gamedayCount,
          total: data.length
        });
      }
    } catch (error) {
      console.error('Error fetching subscriptions:', error);
    }
  };

  const sendNewsletter = async (type: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('newsletter-automation', {
        body: { type, action: 'send' }
      });
      
      if (error) throw error;
      alert(`${type} newsletter sent successfully!`);
    } catch (error) {
      console.error('Error sending newsletter:', error);
      alert('Failed to send newsletter');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Newsletter Management</h2>
        <Badge variant="default">Admin</Badge>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 text-center">
          <div className="text-2xl font-bold text-blue-600">{stats.daily}</div>
          <div className="text-sm text-gray-600">Daily Digest</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl font-bold text-green-600">{stats.weekly}</div>
          <div className="text-sm text-gray-600">Weekly Wrap</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl font-bold text-purple-600">{stats.gameday}</div>
          <div className="text-sm text-gray-600">Game Day</div>
        </Card>
        <Card className="p-4 text-center">
          <div className="text-2xl font-bold text-teal-600">{stats.total}</div>
          <div className="text-sm text-gray-600">Total Subs</div>
        </Card>
      </div>

      {/* Manual Send */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Manual Newsletter Send</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            onClick={() => sendNewsletter('daily')}
            disabled={loading}
            className="w-full"
          >
            Send Daily Digest
          </Button>
          <Button 
            onClick={() => sendNewsletter('weekly')}
            disabled={loading}
            className="w-full"
          >
            Send Weekly Wrap
          </Button>
          <Button 
            onClick={() => sendNewsletter('gameday')}
            disabled={loading}
            className="w-full"
          >
            Send Game Day Update
          </Button>
        </div>
      </Card>

      {/* Automation Status */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Automation Status</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span>Daily Digest (8:00 AM PST)</span>
            <Badge variant="default">Active</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span>Weekly Wrap (Sunday 12:00 AM PST)</span>
            <Badge variant="default">Active</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span>Game Day Updates (Auto)</span>
            <Badge variant="default">Active</Badge>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default NewsletterManager;