import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface LiveScoresProps {
  compact?: boolean;
}

const LiveScores: React.FC<LiveScoresProps> = ({ compact = false }) => {
  const [games, setGames] = useState([
    {
      id: 1,
      homeTeam: 'Seattle Mariners',
      awayTeam: 'Houston Astros',
      homeScore: 4,
      awayScore: 2,
      inning: '7th',
      status: 'Live',
      time: '7:10 PM'
    },
    {
      id: 2,
      homeTeam: 'Angels',
      awayTeam: 'Rangers', 
      homeScore: 1,
      awayScore: 3,
      inning: '5th',
      status: 'Live',
      time: '8:05 PM'
    }
  ]);

  if (compact) {
    return (
      <div className="space-y-3">
        {games.slice(0, 2).map((game) => (
          <div key={game.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="flex items-center space-x-2 text-sm">
              <span className="font-medium">{game.awayTeam}</span>
              <span className="font-bold text-teal-600">{game.awayScore}</span>
              <span className="text-gray-400">@</span>
              <span className="font-medium">{game.homeTeam}</span>
              <span className="font-bold text-blue-600">{game.homeScore}</span>
            </div>
            <Badge variant={game.status === 'Live' ? 'destructive' : 'secondary'} className="text-xs">
              {game.status === 'Live' ? game.inning : game.status}
            </Badge>
          </div>
        ))}
      </div>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-teal-50 dark:from-blue-950 dark:to-teal-950">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-bold flex items-center">
            <TrendingUp className="mr-2 h-6 w-6 text-teal-600" />
            Live Scores
          </CardTitle>
          <Badge variant="secondary" className="bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300">
            <Clock className="mr-1 h-3 w-3" />
            Live
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {games.map((game) => (
          <div 
            key={game.id} 
            className="flex justify-between items-center p-4 bg-white dark:bg-slate-800 rounded-xl shadow-sm"
          >
            <div className="flex items-center space-x-3">
              <div className="text-center">
                <div className="font-bold text-lg">{game.awayTeam}</div>
                <div className="text-2xl font-bold text-teal-600">{game.awayScore}</div>
              </div>
              <div className="text-gray-400 font-semibold">@</div>
              <div className="text-center">
                <div className="font-bold text-lg">{game.homeTeam}</div>
                <div className="text-2xl font-bold text-blue-600">{game.homeScore}</div>
              </div>
            </div>
            <Badge variant={game.status === 'Live' ? 'destructive' : 'secondary'}>
              {game.status === 'Live' ? game.inning : game.status}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default LiveScores;