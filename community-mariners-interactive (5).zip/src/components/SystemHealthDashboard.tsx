import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, RefreshCw, Database, Cloud, Mail, Activity } from 'lucide-react';

interface HealthStatus {
  timestamp: string;
  database: { status: string; details: string };
  edgeFunctions: { status: string; details: string };
  apis: { status: string; details: string };
  storage: { status: string; details: string };
  auth: { status: string; details: string };
}

export const SystemHealthDashboard: React.FC = () => {
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [loading, setLoading] = useState(false);

  const checkSystemHealth = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('system-health-check');
      if (error) throw error;
      setHealth(data);
    } catch (err) {
      console.error('Health check failed:', err);
    }
    setLoading(false);
  };

  useEffect(() => {
    checkSystemHealth();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <RefreshCw className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'healthy':
        return <Badge className="bg-green-500">Healthy</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-500">Warning</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const healthChecks = health ? [
    { name: 'Database', icon: Database, ...health.database },
    { name: 'Edge Functions', icon: Cloud, ...health.edgeFunctions },
    { name: 'APIs', icon: Activity, ...health.apis },
    { name: 'Storage', icon: Database, ...health.storage },
    { name: 'Auth', icon: Mail, ...health.auth }
  ] : [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">System Health Dashboard</h2>
        <Button onClick={checkSystemHealth} disabled={loading}>
          {loading ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : null}
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {healthChecks.map((check) => (
          <Card key={check.name}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <check.icon className="h-5 w-5" />
                  {check.name}
                </div>
                {getStatusBadge(check.status)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-2">
                {getStatusIcon(check.status)}
                <span className="text-sm">{check.details}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {health && (
        <Card>
          <CardHeader>
            <CardTitle>Last Check</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              {new Date(health.timestamp).toLocaleString()}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};