import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'pending';
  message: string;
}

const ButtonFunctionalityTest: React.FC = () => {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [testing, setTesting] = useState(false);

  const updateResult = (name: string, status: 'pass' | 'fail' | 'pending', message: string) => {
    setTestResults(prev => {
      const existing = prev.find(r => r.name === name);
      if (existing) {
        existing.status = status;
        existing.message = message;
        return [...prev];
      }
      return [...prev, { name, status, message }];
    });
  };

  const testDatabaseConnections = async () => {
    const tables = ['forum_posts', 'game_predictions', 'donations', 'users', 'profiles'];
    
    for (const table of tables) {
      try {
        const { data, error } = await supabase.from(table).select('*').limit(1);
        if (error) throw error;
        updateResult(`DB: ${table}`, 'pass', `Connected successfully`);
      } catch (error: any) {
        updateResult(`DB: ${table}`, 'fail', error.message);
      }
    }
  };

  const testEdgeFunctions = async () => {
    const functions = [
      'system-health-check',
      'mlb-news-feed', 
      'real-time-game-data',
      'stripe-payments'
    ];
    
    for (const func of functions) {
      try {
        const { data, error } = await supabase.functions.invoke(func, {
          body: { test: true }
        });
        updateResult(`Function: ${func}`, 'pass', 'Function accessible');
      } catch (error: any) {
        updateResult(`Function: ${func}`, 'fail', error.message);
      }
    }
  };

  const testFormSubmissions = async () => {
    // Test forum post creation
    try {
      const { error } = await supabase.from('forum_posts').insert({
        title: 'Test Post - Button Functionality Check',
        content: 'This is a test post to verify form submissions work.',
        category: 'General Discussion',
        author: 'System Test',
        created_at: new Date().toISOString()
      });
      
      if (error) throw error;
      updateResult('Form: Forum Post', 'pass', 'Forum post creation works');
    } catch (error: any) {
      updateResult('Form: Forum Post', 'fail', error.message);
    }

    // Test prediction submission
    try {
      const { error } = await supabase.from('game_predictions').insert({
        game_id: 999,
        user_id: 'test-user',
        prediction_type: 'win',
        confidence_level: 75,
        created_at: new Date().toISOString()
      });
      
      if (error) throw error;
      updateResult('Form: Predictions', 'pass', 'Prediction submission works');
    } catch (error: any) {
      updateResult('Form: Predictions', 'fail', error.message);
    }
  };

  const runAllTests = async () => {
    setTesting(true);
    setTestResults([]);
    
    toast.info('Running comprehensive button and database tests...');
    
    await testDatabaseConnections();
    await testEdgeFunctions();
    await testFormSubmissions();
    
    setTesting(false);
    toast.success('All tests completed!');
  };

  const getStatusIcon = (status: 'pass' | 'fail' | 'pending') => {
    switch (status) {
      case 'pass': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'fail': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'pending': return <AlertCircle className="w-4 h-4 text-yellow-500" />;
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Button & Database Functionality Test
          <Button onClick={runAllTests} disabled={testing}>
            {testing ? 'Testing...' : 'Run All Tests'}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {testResults.length === 0 && !testing && (
            <p className="text-center text-gray-500">Click "Run All Tests" to verify all functionality</p>
          )}
          
          {testResults.map((result, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                {getStatusIcon(result.status)}
                <span className="font-medium">{result.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">{result.message}</span>
                <Badge variant={result.status === 'pass' ? 'default' : result.status === 'fail' ? 'destructive' : 'secondary'}>
                  {result.status.toUpperCase()}
                </Badge>
              </div>
            </div>
          ))}
          
          {testing && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-2 text-gray-600">Running tests...</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ButtonFunctionalityTest;