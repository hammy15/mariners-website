import React, { useState, useEffect } from 'react';
import { Card, Button } from '@/components/MinimalComponents';
import { GradientCard, AnimatedBadge, GlowButton } from '@/components/EnhancedVisualComponents';
import GameThreadManager from '@/components/GameThreadManager';
import { supabase } from '@/lib/supabase';

interface ForumPost {
  id: string;
  title: string;
  author: string;
  content: string;
  replies: number;
  lastActivity: string;
  category: 'todays-game' | 'temp-check' | 'off-my-chest';
  isSticky?: boolean;
}

const EnhancedForumSection = () => {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [newPost, setNewPost] = useState({ title: '', content: '', category: 'temp-check' });
  const [showNewPostForm, setShowNewPostForm] = useState(false);

  const categories = [
    { id: 'all', name: 'All Posts', icon: '📋', color: 'blue' },
    { id: 'todays-game', name: "Today's Game", icon: '⚾', color: 'green' },
    { id: 'temp-check', name: 'Temp Check', icon: '🌡️', color: 'orange' },
    { id: 'off-my-chest', name: 'Off My Chest', icon: '💭', color: 'purple' }
  ];

  // Mock forum posts with profanity filtering
  useEffect(() => {
    const mockPosts: ForumPost[] = [
      {
        id: '1',
        title: "Today's Game Discussion - Mariners vs Rangers",
        author: 'GameBot',
        content: 'Welcome to today\'s game thread! Share your thoughts, predictions, and reactions here.',
        replies: 89,
        lastActivity: '2 minutes ago',
        category: 'todays-game',
        isSticky: true
      },
      {
        id: '2',
        title: 'How are we feeling about playoff chances?',
        author: 'MarinersFan2024',
        content: 'With the recent wins, I\'m feeling optimistic about our playoff chances. What do you all think?',
        replies: 23,
        lastActivity: '15 minutes ago',
        category: 'temp-check'
      },
      {
        id: '3',
        title: 'Frustrated with the bullpen management',
        author: 'TridentTruth',
        content: 'I need to get this off my chest - the bullpen decisions have been questionable lately.',
        replies: 41,
        lastActivity: '1 hour ago',
        category: 'off-my-chest'
      }
    ];

    setPosts(mockPosts);
  }, []);

  const profanityFilter = (text: string): string => {
    const badWords = ['damn', 'hell', 'crap', 'stupid']; // Basic filter
    let filtered = text;
    badWords.forEach(word => {
      const regex = new RegExp(word, 'gi');
      filtered = filtered.replace(regex, '*'.repeat(word.length));
    });
    return filtered;
  };
  const filteredPosts = selectedCategory === 'all' 
    ? posts 
    : posts.filter(post => post.category === selectedCategory);

  const handleCreatePost = async () => {
    if (!newPost.title.trim() || !newPost.content.trim()) return;

    const filteredTitle = profanityFilter(newPost.title);
    const filteredContent = profanityFilter(newPost.content);

    const post: ForumPost = {
      id: Date.now().toString(),
      title: filteredTitle,
      author: 'CurrentUser',
      content: filteredContent,
      replies: 0,
      lastActivity: 'Just now',
      category: newPost.category as any
    };

    setPosts(prev => [post, ...prev]);
    setNewPost({ title: '', content: '', category: 'temp-check' });
    setShowNewPostForm(false);
  };

  return (
    <div className="space-y-6">
      {/* Game Thread Manager */}
      <GameThreadManager />

      {/* Category Filter */}
      <GradientCard className="p-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          💬 Forum Categories
        </h2>
        
        <div className="flex flex-wrap gap-3 mb-6">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                selectedCategory === category.id
                  ? 'bg-blue-500 text-white shadow-lg'
                  : 'bg-white dark:bg-gray-800 hover:bg-blue-100 dark:hover:bg-gray-700'
              }`}
            >
              <span className="text-lg">{category.icon}</span>
              {category.name}
            </button>
          ))}
        </div>

        {/* New Post Button */}
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {filteredPosts.length} posts • Auto-moderated for family-friendly content
          </div>
          <GlowButton onClick={() => setShowNewPostForm(true)} variant="primary">
            ✏️ New Post
          </GlowButton>
        </div>
      </GradientCard>

      {/* New Post Form */}
      {showNewPostForm && (
        <GradientCard className="p-6" gradient="from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
          <h3 className="text-xl font-bold mb-4">Create New Post</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <select
                value={newPost.category}
                onChange={(e) => setNewPost(prev => ({ ...prev, category: e.target.value }))}
                className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800"
              >
                <option value="temp-check">🌡️ Temp Check</option>
                <option value="off-my-chest">💭 Off My Chest</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Title</label>
              <input
                type="text"
                value={newPost.title}
                onChange={(e) => setNewPost(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter post title..."
                className="w-full p-3 border rounded-lg bg-white dark:bg-gray-800"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Content</label>
              <textarea
                value={newPost.content}
                onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Share your thoughts respectfully..."
                className="w-full p-3 border rounded-lg resize-none h-32 bg-white dark:bg-gray-800"
              />
            </div>

            <div className="flex gap-2">
              <GlowButton onClick={handleCreatePost} variant="success">
                📝 Create Post
              </GlowButton>
              <Button onClick={() => setShowNewPostForm(false)}>Cancel</Button>
            </div>
          </div>
        </GradientCard>
      )}

      {/* Posts List */}
      <div className="space-y-4">
        {filteredPosts.map(post => (
          <GradientCard key={post.id} className="p-6">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                {post.isSticky && <span className="text-xl">📌</span>}
                <div>
                  <h3 className="font-bold text-lg">{post.title}</h3>
                  <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <span>by {post.author}</span>
                    <span>•</span>
                    <span>{post.lastActivity}</span>
                  </div>
                </div>
              </div>
              <AnimatedBadge variant="secondary">
                {categories.find(c => c.id === post.category)?.icon}
              </AnimatedBadge>
            </div>

            <p className="text-gray-700 dark:text-gray-300 mb-4">{post.content}</p>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                <span>💬 {post.replies} replies</span>
              </div>
              <GlowButton variant="primary">View Discussion</GlowButton>
            </div>
          </GradientCard>
        ))}

        {filteredPosts.length === 0 && (
          <GradientCard className="p-8 text-center">
            <div className="text-4xl mb-4">🤔</div>
            <h3 className="text-xl font-bold mb-2">No posts yet</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Be the first to start a discussion in this category!
            </p>
          </GradientCard>
        )}
      </div>
    </div>
  );
};

export default EnhancedForumSection;