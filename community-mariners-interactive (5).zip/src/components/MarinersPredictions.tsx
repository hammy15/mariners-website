import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, MessageSquare, Trophy, Zap, Flame, Users, History, Heart } from 'lucide-react';
import ForumSection from './ForumSection';
import PredictionLeaderboard from './PredictionLeaderboard';
import PredictionHistory from './PredictionHistory';
import PremiumMembership from './PremiumMembership';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
const MarinersPredictions: React.FC = () => {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState('simple');
  const [marinersRoster, setMarinersRoster] = useState<any>(null);
  const [prediction, setPrediction] = useState({
    gameId: '',
    type: 'win_loss',
    data: {},
    confidence: 50
  });

  const [simplePrediction, setSimplePrediction] = useState({
    winner: '',
    confidence: 50
  });

  const [offensivePrediction, setOffensivePrediction] = useState({
    totalHits: '',
    homeRuns: '',
    rbis: '',
    topHitter: '',
    confidence: 50
  });

  const [pitchingPrediction, setPitchingPrediction] = useState({
    strikeouts: '',
    reliever: '',
    earnedRuns: '',
    innings: '',
    confidence: 50
  });

  useEffect(() => {
    fetchMarinersRoster();
  }, []);

  const fetchMarinersRoster = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('mariners-roster');
      if (error) throw error;
      setMarinersRoster(data.roster);
    } catch (error) {
      console.error('Error fetching roster:', error);
    }
  };

  const marinersGames = [
    { id: 'sea_vs_oak', label: 'Mariners vs Athletics - Today 7:10 PM', opponent: 'Athletics' },
    { id: 'sea_vs_tex', label: 'Mariners vs Rangers - Tomorrow 7:05 PM', opponent: 'Rangers' },
    { id: 'sea_vs_hou', label: 'Mariners vs Astros - Friday 7:10 PM', opponent: 'Astros' }
  ];

  const handleSubmitPrediction = async (type: string, data: any) => {
    if (!user) {
      toast.error('Please sign in to make predictions');
      return;
    }

    if (!prediction.gameId) {
      toast.error('Please select a Mariners game');
      return;
    }

    try {
      const { error } = await supabase
        .from('predictions')
        .insert({
          user_id: user.id,
          game_id: prediction.gameId,
          prediction_type: type,
          prediction_data: data,
          confidence_level: data.confidence || 50
        });

      if (error) throw error;
      
      toast.success('Mariners prediction submitted!');
      // Reset forms
      setSimplePrediction({ winner: '', confidence: 50 });
      setOffensivePrediction({ totalHits: '', homeRuns: '', rbis: '', topHitter: '', confidence: 50 });
      setPitchingPrediction({ strikeouts: '', reliever: '', earnedRuns: '', innings: '', confidence: 50 });
    } catch (error: any) {
      toast.error('Error submitting prediction');
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Target className="h-5 w-5 text-blue-600" />
          <span>Mariners Predictions Hub</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <label className="text-sm font-medium mb-2 block">Select Mariners Game</label>
          <Select value={prediction.gameId} onValueChange={(value) => 
            setPrediction(prev => ({ ...prev, gameId: value }))
          }>
            <SelectTrigger>
              <SelectValue placeholder="Choose upcoming Mariners game" />
            </SelectTrigger>
            <SelectContent>
              {marinersGames.map(game => (
                <SelectItem key={game.id} value={game.id}>{game.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="simple" className="flex items-center space-x-1">
              <Trophy className="h-3 w-3" />
              <span className="text-xs">Win/Loss</span>
            </TabsTrigger>
            <TabsTrigger value="offense" className="flex items-center space-x-1">
              <Zap className="h-3 w-3" />
              <span className="text-xs">Offense</span>
            </TabsTrigger>
            <TabsTrigger value="pitching" className="flex items-center space-x-1">
              <Flame className="h-3 w-3" />
              <span className="text-xs">Pitching</span>
            </TabsTrigger>
            <TabsTrigger value="support" className="flex items-center space-x-1">
              <Heart className="h-3 w-3" />
              <span className="text-xs">Support</span>
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="flex items-center space-x-1">
              <Users className="h-3 w-3" />
              <span className="text-xs">Leaders</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center space-x-1">
              <History className="h-3 w-3" />
              <span className="text-xs">History</span>
            </TabsTrigger>
            <TabsTrigger value="forum" className="flex items-center space-x-1">
              <MessageSquare className="h-3 w-3" />
              <span className="text-xs">Forum</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="simple" className="space-y-4">
            <div className="space-y-4">
              <h3 className="font-semibold">Simple Win/Loss Prediction</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Who Will Win?</label>
                  <Select value={simplePrediction.winner} onValueChange={(value) => 
                    setSimplePrediction(prev => ({ ...prev, winner: value }))
                  }>
                    <SelectTrigger>
                      <SelectValue placeholder="Select winner" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mariners">Seattle Mariners</SelectItem>
                      <SelectItem value="opponent">Opponent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Confidence: {simplePrediction.confidence}%
                  </label>
                  <Input
                    type="range"
                    min="1"
                    max="100"
                    value={simplePrediction.confidence}
                    onChange={(e) => setSimplePrediction(prev => ({ 
                      ...prev, 
                      confidence: parseInt(e.target.value) 
                    }))}
                    className="w-full"
                  />
                </div>

                <Button 
                  onClick={() => handleSubmitPrediction('win_loss', simplePrediction)} 
                  className="w-full"
                  disabled={!simplePrediction.winner || !prediction.gameId}
                >
                  Submit Win/Loss Prediction
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="offense" className="space-y-4">
            <div className="space-y-4">
              <h3 className="font-semibold">Offensive Predictions</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Total Team Hits</label>
                  <Input
                    type="number"
                    placeholder="e.g. 8"
                    value={offensivePrediction.totalHits}
                    onChange={(e) => setOffensivePrediction(prev => ({ 
                      ...prev, 
                      totalHits: e.target.value 
                    }))}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Home Runs</label>
                  <Input
                    type="number"
                    placeholder="e.g. 2"
                    value={offensivePrediction.homeRuns}
                    onChange={(e) => setOffensivePrediction(prev => ({ 
                      ...prev, 
                      homeRuns: e.target.value 
                    }))}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">RBIs</label>
                  <Input
                    type="number"
                    placeholder="e.g. 5"
                    value={offensivePrediction.rbis}
                    onChange={(e) => setOffensivePrediction(prev => ({ 
                      ...prev, 
                      rbis: e.target.value 
                    }))}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Top Hitter</label>
                  <Select value={offensivePrediction.topHitter} onValueChange={(value) => 
                    setOffensivePrediction(prev => ({ ...prev, topHitter: value }))
                  }>
                    <SelectTrigger>
                      <SelectValue placeholder="Select player" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rodriguez">Julio Rodríguez</SelectItem>
                      <SelectItem value="france">Ty France</SelectItem>
                      <SelectItem value="suarez">Eugenio Suárez</SelectItem>
                      <SelectItem value="haniger">Mitch Haniger</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Confidence: {offensivePrediction.confidence}%
                </label>
                <Input
                  type="range"
                  min="1"
                  max="100"
                  value={offensivePrediction.confidence}
                  onChange={(e) => setOffensivePrediction(prev => ({ 
                    ...prev, 
                    confidence: parseInt(e.target.value) 
                  }))}
                  className="w-full"
                />
              </div>

              <Button 
                onClick={() => handleSubmitPrediction('offensive', offensivePrediction)} 
                className="w-full"
                disabled={!prediction.gameId}
              >
                Submit Offensive Prediction
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="pitching" className="space-y-4">
            <div className="space-y-4">
              <h3 className="font-semibold">Pitching Predictions</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Total Strikeouts</label>
                  <Input
                    type="number"
                    placeholder="e.g. 9"
                    value={pitchingPrediction.strikeouts}
                    onChange={(e) => setPitchingPrediction(prev => ({ 
                      ...prev, 
                      strikeouts: e.target.value 
                    }))}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Closing Reliever</label>
                  <Select value={pitchingPrediction.reliever} onValueChange={(value) => 
                    setPitchingPrediction(prev => ({ ...prev, reliever: value }))
                  }>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reliever" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="munoz">Andrés Muñoz</SelectItem>
                      <SelectItem value="sewald">Paul Sewald</SelectItem>
                      <SelectItem value="festa">Matt Festa</SelectItem>
                      <SelectItem value="brash">Matt Brash</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Earned Runs Allowed</label>
                  <Input
                    type="number"
                    placeholder="e.g. 3"
                    value={pitchingPrediction.earnedRuns}
                    onChange={(e) => setPitchingPrediction(prev => ({ 
                      ...prev, 
                      earnedRuns: e.target.value 
                    }))}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Starter Innings</label>
                  <Input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 6.2"
                    value={pitchingPrediction.innings}
                    onChange={(e) => setPitchingPrediction(prev => ({ 
                      ...prev, 
                      innings: e.target.value 
                    }))}
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">
                  Confidence: {pitchingPrediction.confidence}%
                </label>
                <Input
                  type="range"
                  min="1"
                  max="100"
                  value={pitchingPrediction.confidence}
                  onChange={(e) => setPitchingPrediction(prev => ({ 
                    ...prev, 
                    confidence: parseInt(e.target.value) 
                  }))}
                  className="w-full"
                />
              </div>

              <Button 
                onClick={() => handleSubmitPrediction('pitching', pitchingPrediction)} 
                className="w-full"
                disabled={!prediction.gameId}
              >
                Submit Pitching Prediction
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="support" className="mt-6">
            <div className="max-w-full overflow-x-auto">
              <PremiumMembership />
            </div>
          </TabsContent>
          <TabsContent value="leaderboard">
            <PredictionLeaderboard />
          </TabsContent>

          <TabsContent value="history">
            <PredictionHistory />
          </TabsContent>

          <TabsContent value="forum">
            <ForumSection category="mariners-predictions" title="Mariners Prediction Discussions" />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default MarinersPredictions;