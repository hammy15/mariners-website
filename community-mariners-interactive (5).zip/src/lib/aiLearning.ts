interface UserPreferences {
  favoriteTopics: string[];
  communicationStyle: 'casual' | 'formal' | 'enthusiastic' | 'analytical';
  responseLength: 'short' | 'medium' | 'long';
  interactionFrequency: number;
  sentimentHistory: number[];
}

interface ConversationMetrics {
  totalConversations: number;
  averageResponseTime: number;
  averageConversationLength: number;
  topicEngagement: Record<string, number>;
  sentimentTrend: number[];
  botPerformance: Record<string, { accuracy: number; satisfaction: number }>;
}

interface Conversation {
  id: string;
  botName: string;
  timestamp: Date;
  duration: number;
  messageCount: number;
  topics: string[];
  sentiment: number;
  userSatisfaction?: number;
  responseTime: number;
}

const marinersTopics = [
  'roster_moves', 'game_predictions', 'player_stats', 'team_standings',
  'trade_rumors', 'injury_reports', 'pitcher_analysis', 'batting_stats',
  'defensive_metrics', 'prospect_updates', 'coaching_staff', 'team_history',
  'stadium_experience', 'fan_traditions', 'playoff_chances', 'season_outlook',
  'draft_picks', 'minor_league', 'hall_of_fame', 'rivalries'
];

const conversationTopics = [
  'weather_impact', 'game_strategy', 'player_development', 'analytics',
  'fantasy_baseball', 'betting_odds', 'social_media', 'merchandise',
  'ticket_prices', 'concessions', 'parking', 'transportation',
  'family_activities', 'group_events', 'season_tickets', 'promotions',
  'community_outreach', 'charity_events', 'youth_programs', 'fan_clubs',
  'tailgating', 'watch_parties', 'radio_coverage', 'tv_broadcasts',
  'podcast_discussions', 'blog_content', 'photo_contests', 'trivia'
];

class AILearningSystem {
  private userPreferences: UserPreferences = {
    favoriteTopics: [],
    communicationStyle: 'casual',
    responseLength: 'medium',
    interactionFrequency: 0,
    sentimentHistory: []
  };

  private conversations: Conversation[] = [];
  private metrics: ConversationMetrics = {
    totalConversations: 0,
    averageResponseTime: 0,
    averageConversationLength: 0,
    topicEngagement: {},
    sentimentTrend: [],
    botPerformance: {}
  };

  recordConversation(conversation: Omit<Conversation, 'id'>) {
    const newConversation: Conversation = {
      ...conversation,
      id: Date.now().toString()
    };
    
    this.conversations.push(newConversation);
    this.updateMetrics();
    this.updateUserPreferences(newConversation);
  }

  private updateMetrics() {
    this.metrics.totalConversations = this.conversations.length;
    
    if (this.conversations.length > 0) {
      this.metrics.averageResponseTime = this.conversations.reduce((sum, conv) => sum + conv.responseTime, 0) / this.conversations.length;
      this.metrics.averageConversationLength = this.conversations.reduce((sum, conv) => sum + conv.duration, 0) / this.conversations.length;
      
      // Update topic engagement
      this.conversations.forEach(conv => {
        conv.topics.forEach(topic => {
          this.metrics.topicEngagement[topic] = (this.metrics.topicEngagement[topic] || 0) + 1;
        });
      });

      // Update sentiment trend (last 10 conversations)
      this.metrics.sentimentTrend = this.conversations
        .slice(-10)
        .map(conv => conv.sentiment);
    }
  }

  private updateUserPreferences(conversation: Conversation) {
    // Update favorite topics based on engagement
    conversation.topics.forEach(topic => {
      if (!this.userPreferences.favoriteTopics.includes(topic)) {
        this.userPreferences.favoriteTopics.push(topic);
      }
    });

    // Keep only top 10 favorite topics
    const topicCounts = this.userPreferences.favoriteTopics.map(topic => ({
      topic,
      count: this.metrics.topicEngagement[topic] || 0
    }));
    
    topicCounts.sort((a, b) => b.count - a.count);
    this.userPreferences.favoriteTopics = topicCounts.slice(0, 10).map(item => item.topic);

    // Update sentiment history
    this.userPreferences.sentimentHistory.push(conversation.sentiment);
    if (this.userPreferences.sentimentHistory.length > 20) {
      this.userPreferences.sentimentHistory.shift();
    }

    this.userPreferences.interactionFrequency++;
  }

  getPersonalizedResponse(botName: string, topic: string): string {
    const responses = this.getResponsesByBot(botName);
    const personalizedResponses = responses.filter(r => 
      this.userPreferences.favoriteTopics.some(favTopic => r.includes(favTopic))
    );
    
    return personalizedResponses.length > 0 
      ? personalizedResponses[Math.floor(Math.random() * personalizedResponses.length)]
      : responses[Math.floor(Math.random() * responses.length)];
  }

  private getResponsesByBot(botName: string): string[] {
    const responses = {
      'Marty BoomStick': [
        'BOOM! That\'s a home run insight!',
        'Ka-pow! The M\'s are looking strong!',
        'Wham! Great question about the team!',
        'Bam! Let me break that down for you!'
      ],
      'Wes Tillwaiting': [
        'Well, that\'s a mighty fine question!',
        'Harvest time for some baseball wisdom!',
        'That\'s as solid as a cornfield in summer!',
        'Let me plant some knowledge for you!'
      ],
      'Don Tlose': [
        'Ay! That\'s the fighting spirit!',
        'Rally time! Let\'s go M\'s!',
        'Victory is within our grasp!',
        'Never give up, never surrender!'
      ]
    };
    
    return responses[botName as keyof typeof responses] || responses['Marty BoomStick'];
  }

  getConversationStarters(botName: string): string[] {
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
    
    const starters = {
      'Marty BoomStick': [
        `BOOM! Day ${dayOfYear} and the M's are still swinging for the fences!`,
        'Ka-pow! Ready to talk some serious baseball strategy?',
        'Wham! What\'s your take on today\'s lineup?'
      ],
      'Wes Tillwaiting': [
        `Well howdy! Day ${dayOfYear} in the baseball season - what\'s growing in your mind?`,
        'Mighty fine day to discuss some Mariners wisdom!',
        'Let\'s harvest some insights about the team!'
      ],
      'Don Tlose': [
        `Ay! Day ${dayOfYear} - another chance for victory!`,
        'Rally time! What battle shall we discuss today?',
        'Never surrender! What\'s your game plan?'
      ]
    };
    
    return starters[botName as keyof typeof starters] || starters['Marty BoomStick'];
  }

  getMetrics(): ConversationMetrics {
    return { ...this.metrics };
  }

  getUserPreferences(): UserPreferences {
    return { ...this.userPreferences };
  }

  extractTopics(message: string): string[] {
    const allTopics = [...marinersTopics, ...conversationTopics];
    const foundTopics: string[] = [];
    
    allTopics.forEach(topic => {
      const keywords = topic.split('_');
      if (keywords.some(keyword => message.toLowerCase().includes(keyword))) {
        foundTopics.push(topic);
      }
    });
    
    return foundTopics.length > 0 ? foundTopics : ['general_discussion'];
  }

  analyzeSentiment(message: string): number {
    const positiveWords = ['great', 'awesome', 'love', 'amazing', 'fantastic', 'excellent', 'good', 'win', 'victory'];
    const negativeWords = ['bad', 'terrible', 'hate', 'awful', 'horrible', 'lose', 'defeat', 'disappointing'];
    
    const words = message.toLowerCase().split(' ');
    let score = 0;
    
    words.forEach(word => {
      if (positiveWords.includes(word)) score += 1;
      if (negativeWords.includes(word)) score -= 1;
    });
    
    return Math.max(-1, Math.min(1, score / words.length));
  }
}

export const aiLearningSystem = new AILearningSystem();