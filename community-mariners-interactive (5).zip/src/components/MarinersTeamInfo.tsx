import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trophy, Calendar, MapPin } from 'lucide-react';

const MarinersTeamInfo: React.FC = () => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg text-teal-600 flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          Seattle Mariners
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 rounded-lg bg-gradient-to-r from-teal-600 to-blue-900 text-white text-center">
          <h3 className="font-bold text-lg">Seattle Mariners</h3>
          <p className="text-sm opacity-90">America's Team of the Pacific Northwest</p>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-teal-600" />
            <span className="text-sm">T-Mobile Park, Seattle, WA</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-teal-600" />
            <span className="text-sm">Founded: 1977</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="bg-teal-50">AL West</Badge>
          <Badge variant="outline" className="bg-blue-50">Since 1977</Badge>
          <Badge variant="outline" className="bg-green-50">Go M's!</Badge>
        </div>

        <div className="text-center text-sm text-gray-600">
          <p>🌊 Refuse to Lose 🌊</p>
          <p className="text-xs mt-1">True to the Blue since day one!</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarinersTeamInfo;