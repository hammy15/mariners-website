import React, { useState, useEffect } from 'react';
import { Card, Button } from '@/components/MinimalComponents';
import { GradientCard, GlowButton, AnimatedBadge } from '@/components/EnhancedVisualComponents';
import SeventhInningPopup from '@/components/SeventhInningPopup';
import { supabase } from '@/lib/supabase';

interface PredictionModalProps {
  isOpen: boolean;
  onClose: () => void;
  gameId: string;
  gameTime: string;
}

const EnhancedPredictionModal: React.FC<PredictionModalProps> = ({ 
  isOpen, 
  onClose, 
  gameId, 
  gameTime 
}) => {
  const [predictions, setPredictions] = useState({
    winLose: '',
    pitcherInnings: '',
    homeRunPlayer: '',
    reliefPitchers: [] as string[],
    pitchCount: '',
    extraInnings: '',
    forumTossup: ''
  });

  const [showSeventhInning, setShowSeventhInning] = useState(false);
  const [tossupWinner, setTossupWinner] = useState<'Marty' | 'Captain' | 'Spartan'>('Marty');
  const [marinersRoster, setMarinersRoster] = useState([]);
  const [bullpenRoster, setBullpenRoster] = useState([]);
  const [gameInning, setGameInning] = useState(1);

  // Mock roster data - in real app would fetch from API
  const mockRoster = [
    'Julio Rodríguez', 'Cal Raleigh', 'Eugenio Suárez', 'J.P. Crawford',
    'Teoscar Hernández', 'Ty France', 'George Kirby', 'Logan Gilbert'
  ];

  const mockBullpen = [
    'Paul Sewald', 'Matt Festa', 'Andrés Muñoz', 'Justin Topa',
    'Tayler Saucedo', 'Matt Brash', 'Gabe Speier', 'Isaiah Campbell'
  ];

  useEffect(() => {
    setMarinersRoster(mockRoster);
    setBullpenRoster(mockBullpen);
    
    // Simulate 7th inning popup for demo
    const timer = setTimeout(() => {
      if (gameInning === 7) {
        const winners = ['Marty', 'Captain', 'Spartan'] as const;
        const randomWinner = winners[Math.floor(Math.random() * winners.length)];
        setTossupWinner(randomWinner);
        setShowSeventhInning(true);
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, [gameInning]);

  const handleReliefPitcherToggle = (pitcher: string) => {
    setPredictions(prev => ({
      ...prev,
      reliefPitchers: prev.reliefPitchers.includes(pitcher)
        ? prev.reliefPitchers.filter(p => p !== pitcher)
        : prev.reliefPitchers.length < 2 
          ? [...prev.reliefPitchers, pitcher]
          : prev.reliefPitchers
    }));
  };
  const handleSubmitPredictions = async () => {
    try {
      const { data, error } = await supabase
        .from('game_predictions')
        .insert([{
          game_id: gameId,
          user_id: 'current-user',
          predictions: predictions,
          created_at: new Date().toISOString()
        }]);

      if (!error) {
        onClose();
      }
    } catch (error) {
      console.error('Error submitting predictions:', error);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <GradientCard className="w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              🎯 Make Your Predictions
            </h2>
            <Button onClick={onClose}>×</Button>
          </div>

          <div className="space-y-6">
            {/* 1. Win/Lose */}
            <GradientCard className="p-4" gradient="from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                ⚾ 1. Mariners Win or Lose?
              </h4>
              <div className="flex gap-2">
                {['Win', 'Lose'].map(option => (
                  <GlowButton
                    key={option}
                    onClick={() => setPredictions(prev => ({ ...prev, winLose: option }))}
                    variant={predictions.winLose === option ? 'success' : 'primary'}
                  >
                    {option}
                  </GlowButton>
                ))}
              </div>
            </GradientCard>

            {/* 2. Pitcher Innings */}
            <GradientCard className="p-4" gradient="from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                🥎 2. Starting Pitcher Innings
              </h4>
              <div className="flex gap-2">
                {['5+ innings', 'Under 5 innings'].map(option => (
                  <GlowButton
                    key={option}
                    onClick={() => setPredictions(prev => ({ ...prev, pitcherInnings: option }))}
                    variant={predictions.pitcherInnings === option ? 'success' : 'primary'}
                  >
                    {option}
                  </GlowButton>
                ))}
              </div>
            </GradientCard>

            {/* 3. Home Run Player */}
            <GradientCard className="p-4" gradient="from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                💥 3. Who hits a home run?
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {marinersRoster.map(player => (
                  <button
                    key={player}
                    onClick={() => setPredictions(prev => ({ ...prev, homeRunPlayer: player }))}
                    className={`p-2 rounded-lg text-sm font-medium transition-all ${
                      predictions.homeRunPlayer === player
                        ? 'bg-orange-500 text-white shadow-lg'
                        : 'bg-white dark:bg-gray-800 hover:bg-orange-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    {player}
                  </button>
                ))}
              </div>
            </GradientCard>

            {/* 4. Relief Pitchers */}
            <GradientCard className="p-4" gradient="from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                🎯 4. Relief Pitchers (Pick 2)
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {bullpenRoster.map(pitcher => (
                  <button
                    key={pitcher}
                    onClick={() => handleReliefPitcherToggle(pitcher)}
                    className={`p-2 rounded-lg text-sm font-medium transition-all ${
                      predictions.reliefPitchers.includes(pitcher)
                        ? 'bg-red-500 text-white shadow-lg'
                        : 'bg-white dark:bg-gray-800 hover:bg-red-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    {pitcher}
                  </button>
                ))}
              </div>
              <div className="mt-2">
                <AnimatedBadge variant="secondary">
                  Selected: {predictions.reliefPitchers.length}/2
                </AnimatedBadge>
              </div>
            </GradientCard>

            {/* 5. Pitch Count */}
            <GradientCard className="p-4" gradient="from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                📊 5. Starter Pitch Count
              </h4>
              <div className="flex gap-2">
                {['Over 80', 'Under 80'].map(option => (
                  <GlowButton
                    key={option}
                    onClick={() => setPredictions(prev => ({ ...prev, pitchCount: option }))}
                    variant={predictions.pitchCount === option ? 'success' : 'primary'}
                  >
                    {option}
                  </GlowButton>
                ))}
              </div>
            </GradientCard>

            {/* 6. Extra Innings */}
            <GradientCard className="p-4" gradient="from-teal-50 to-cyan-50 dark:from-teal-900/20 dark:to-cyan-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                ⏰ 6. Extra Innings?
              </h4>
              <div className="flex gap-2">
                {['Yes', 'No'].map(option => (
                  <GlowButton
                    key={option}
                    onClick={() => setPredictions(prev => ({ ...prev, extraInnings: option }))}
                    variant={predictions.extraInnings === option ? 'success' : 'primary'}
                  >
                    {option}
                  </GlowButton>
                ))}
              </div>
            </GradientCard>

            {/* 7. Forum Tossup */}
            <GradientCard className="p-4" gradient="from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                🎲 7. Forum Tossup Winner
              </h4>
              <div className="flex gap-2">
                {[
                  { name: 'Spartan', emoji: '🛡️' },
                  { name: 'Captain', emoji: '⚓' },
                  { name: 'Marty', emoji: '🤖' }
                ].map(bot => (
                  <button
                    key={bot.name}
                    onClick={() => setPredictions(prev => ({ ...prev, forumTossup: bot.name }))}
                    className={`p-3 rounded-lg font-medium transition-all flex items-center gap-2 ${
                      predictions.forumTossup === bot.name
                        ? 'bg-emerald-500 text-white shadow-lg transform scale-105'
                        : 'bg-white dark:bg-gray-800 hover:bg-emerald-100 dark:hover:bg-gray-700'
                    }`}
                  >
                    <span className="text-xl">{bot.emoji}</span>
                    {bot.name}
                  </button>
                ))}
              </div>
            </GradientCard>
          </div>

          <div className="mt-6 flex gap-2">
            <GlowButton
              onClick={handleSubmitPredictions}
              variant="success"
            >
              🚀 Submit Predictions
            </GlowButton>
            <Button onClick={onClose}>Cancel</Button>
          </div>
        </GradientCard>
      </div>

      {showSeventhInning && (
        <SeventhInningPopup
          winner={tossupWinner}
          onClose={() => setShowSeventhInning(false)}
        />
      )}
    </>
  );
};

export default EnhancedPredictionModal;