import React, { useState } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import EnhancedSeatingChart from '@/components/EnhancedSeatingChart';
const SeatingPage = () => {
  const [selectedSection, setSelectedSection] = useState(null);

  const seatingAreas = [
    {
      id: 1,
      name: "Diamond Club",
      price: "$85-150",
      description: "Premium seating behind home plate",
      features: ["Climate controlled", "Exclusive dining", "Valet parking"]
    },
    {
      id: 2,
      name: "Field Level",
      price: "$25-75",
      description: "Close to the action field level seats",
      features: ["Great views", "Easy concession access", "Family friendly"]
    },
    {
      id: 3,
      name: "Upper Deck",
      price: "$15-35",
      description: "Affordable seats with full stadium view",
      features: ["Budget friendly", "Full field view", "Great atmosphere"]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">T-Mobile Park Seating</h1>
        <Button>Buy Tickets</Button>
      </div>

      {/* Enhanced Seating Chart */}
      <EnhancedSeatingChart />

      {/* Stadium Overview */}
      <Card className="p-6 bg-gradient-to-r from-blue-900 to-teal-600 text-white">
        <h2 className="text-2xl font-bold mb-4">T-Mobile Park</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <div className="text-xl font-bold">47,929</div>
            <div className="text-sm opacity-90">Capacity</div>
          </div>
          <div>
            <div className="text-xl font-bold">1999</div>
            <div className="text-sm opacity-90">Opened</div>
          </div>
          <div>
            <div className="text-xl font-bold">Retractable</div>
            <div className="text-sm opacity-90">Roof</div>
          </div>
          <div>
            <div className="text-xl font-bold">Natural</div>
            <div className="text-sm opacity-90">Grass</div>
          </div>
        </div>
      </Card>

      {/* Seating Areas */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Seating Options</h2>
        <div className="grid gap-6">
          {seatingAreas.map((area) => (
            <Card key={area.id} className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold">{area.name}</h3>
                  <p className="text-gray-600">{area.description}</p>
                </div>
                <Badge variant="secondary">{area.price}</Badge>
              </div>
              
              <div className="mb-4">
                <h4 className="font-medium mb-2">Features:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  {area.features.map((feature, index) => (
                    <li key={index}>• {feature}</li>
                  ))}
                </ul>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline">View Section</Button>
                <Button>Select Seats</Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Stadium Map Placeholder */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Interactive Stadium Map</h2>
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg h-64 flex items-center justify-center">
          <div className="text-center text-gray-500">
            <div className="text-4xl mb-2">🏟️</div>
            <p>Interactive seating chart coming soon</p>
            <Button variant="outline" className="mt-2">
              View Full Stadium Map
            </Button>
          </div>
        </div>
      </Card>

      {/* Tips */}
      <Card className="p-6 bg-green-50 dark:bg-green-900/20">
        <h3 className="text-lg font-semibold mb-2">Seating Tips</h3>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Arrive early for batting practice</li>
          <li>• Check weather for roof status</li>
          <li>• Consider sun position for day games</li>
          <li>• Explore different concession areas</li>
        </ul>
      </Card>
    </div>
  );
};

export default SeatingPage;