import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Ticket, DollarSign, Calendar, MapPin, Shield } from 'lucide-react';
import PaymentModal from './PaymentModal';

interface TicketListing {
  id: string;
  seller: string;
  game: string;
  date: string;
  section: string;
  row: string;
  seats: string;
  price: number;
  faceValue: number;
  verified: boolean;
  type: 'sell' | 'buy';
}

const TicketExchange: React.FC = () => {
  const [listings] = useState<TicketListing[]>([
    {
      id: '1',
      seller: 'SeasonTicketHolder',
      game: 'vs Angels',
      date: '2024-08-15',
      section: '136',
      row: '12',
      seats: '15-16',
      price: 85,
      faceValue: 95,
      verified: true,
      type: 'sell'
    },
    {
      id: '2',
      seller: 'MarinersFamily',
      game: 'vs Astros',
      date: '2024-08-18',
      section: '215',
      row: '8',
      seats: '1-4',
      price: 180,
      faceValue: 200,
      verified: true,
      type: 'sell'
    },
    {
      id: '3',
      seller: 'LookingForTickets',
      game: 'vs Rangers',
      date: '2024-08-22',
      section: 'Any',
      row: 'Any',
      seats: '2 tickets',
      price: 120,
      faceValue: 0,
      verified: false,
      type: 'buy'
    }
  ]);

  const [filter, setFilter] = useState<'all' | 'sell' | 'buy'>('all');
  const [paymentModal, setPaymentModal] = useState<{
    isOpen: boolean;
    listing?: TicketListing;
  }>({ isOpen: false });

  const handlePurchase = (listing: TicketListing) => {
    setPaymentModal({ isOpen: true, listing });
  };

  const handlePaymentSuccess = () => {
    alert('Ticket purchase successful! Check your email for details.');
    setPaymentModal({ isOpen: false });
  };

  const filteredListings = listings.filter(listing => 
    filter === 'all' || listing.type === filter
  );

  const getPriceColor = (price: number, faceValue: number) => {
    if (faceValue === 0) return 'text-blue-600'; // Buy requests
    if (price < faceValue) return 'text-green-600';
    if (price === faceValue) return 'text-gray-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Ticket className="mr-2 h-5 w-5" />
            Season Ticket Exchange
          </span>
          <div className="flex space-x-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'sell' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('sell')}
            >
              For Sale
            </Button>
            <Button
              variant={filter === 'buy' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('buy')}
            >
              Wanted
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4 p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center text-blue-800 mb-1">
            <Shield className="mr-2 h-4 w-4" />
            <span className="font-semibold text-sm">Safe Exchange Tips</span>
          </div>
          <p className="text-xs text-blue-700">
            Only trade with verified users • Meet at the stadium • Use secure payment methods
          </p>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filteredListings.map((listing) => (
            <div key={listing.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <h3 className="font-semibold">{listing.game}</h3>
                    <Badge variant={listing.type === 'sell' ? 'default' : 'secondary'}>
                      {listing.type === 'sell' ? 'For Sale' : 'Wanted'}
                    </Badge>
                    {listing.verified && (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        <Shield className="mr-1 h-3 w-3" />
                        Verified
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 space-x-4">
                    <span className="flex items-center">
                      <Calendar className="mr-1 h-3 w-3" />
                      {new Date(listing.date).toLocaleDateString()}
                    </span>
                    <span className="flex items-center">
                      <MapPin className="mr-1 h-3 w-3" />
                      Sec {listing.section}, Row {listing.row}, Seats {listing.seats}
                    </span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className={`text-lg font-bold ${getPriceColor(listing.price, listing.faceValue)}`}>
                    ${listing.price}
                    {listing.type === 'sell' && listing.faceValue > 0 && (
                      <span className="text-xs text-gray-500 block">
                        Face: ${listing.faceValue}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  Posted by {listing.seller}
                </span>
                <div className="flex gap-2">
                  {listing.type === 'sell' && (
                    <Button 
                      size="sm" 
                      className="bg-teal-600 hover:bg-teal-700"
                      onClick={() => handlePurchase(listing)}
                    >
                      Buy Now
                    </Button>
                  )}
                  <Button size="sm" variant="outline">
                    {listing.type === 'sell' ? 'Contact Seller' : 'Contact Buyer'}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t">
          <Button className="w-full bg-teal-600 hover:bg-teal-700">
            <Ticket className="mr-2 h-4 w-4" />
            List Your Tickets
          </Button>
        </div>

        {paymentModal.listing && (
          <PaymentModal
            isOpen={paymentModal.isOpen}
            onClose={() => setPaymentModal({ isOpen: false })}
            title={`Purchase Tickets: ${paymentModal.listing.game}`}
            description={`Section ${paymentModal.listing.section}, Row ${paymentModal.listing.row}, Seats ${paymentModal.listing.seats}`}
            amount={paymentModal.listing.price}
            onSuccess={handlePaymentSuccess}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default TicketExchange;