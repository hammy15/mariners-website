import React, { useState } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';

const SupportPage = () => {
  const [selectedCategory, setSelectedCategory] = useState('general');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const faqCategories = [
    { id: 'general', name: 'General' },
    { id: 'account', name: 'Account' },
    { id: 'predictions', name: 'Predictions' },
    { id: 'technical', name: 'Technical' }
  ];

  const faqs = {
    general: [
      { q: "How do I join the forum?", a: "Click 'Sign Up' and create an account to start participating." },
      { q: "Is the site free to use?", a: "Yes, basic features are free. Premium features require subscription." }
    ],
    account: [
      { q: "How do I reset my password?", a: "Click 'Forgot Password' on the login page." },
      { q: "Can I change my username?", a: "Contact support to request a username change." }
    ],
    predictions: [
      { q: "How do predictions work?", a: "Make predictions before games start to earn points." },
      { q: "When are predictions locked?", a: "Predictions lock at first pitch of each game." }
    ],
    technical: [
      { q: "Site won't load properly", a: "Try clearing your browser cache and cookies." },
      { q: "Mobile app issues", a: "Update to the latest version or reinstall the app." }
    ]
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">Support Center</h1>
        <p className="text-gray-600">
          Get help with your account, find answers to common questions, or contact our support team.
        </p>
      </div>

      {/* Contact Form */}
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Contact Support</h2>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="your@email.com"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Subject</label>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData({...formData, subject: e.target.value})}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Brief description of your issue"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Message</label>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              rows={4}
              className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Describe your issue in detail..."
            />
          </div>
          
          <Button className="w-full">Send Message</Button>
        </div>
      </Card>

      {/* FAQ Section */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Frequently Asked Questions</h2>
        
        {/* FAQ Categories */}
        <div className="flex flex-wrap gap-2 mb-6">
          {faqCategories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.name}
            </Button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs[selectedCategory]?.map((faq, index) => (
            <Card key={index} className="p-4">
              <h3 className="font-semibold mb-2">{faq.q}</h3>
              <p className="text-gray-600">{faq.a}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Support Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 text-center">
          <div className="text-3xl mb-3">📧</div>
          <h3 className="font-semibold mb-2">Email Support</h3>
          <p className="text-sm text-gray-600 mb-3">Get help via email</p>
          <Badge variant="secondary">24-48 hours</Badge>
        </Card>
        
        <Card className="p-6 text-center">
          <div className="text-3xl mb-3">💬</div>
          <h3 className="font-semibold mb-2">Live Chat</h3>
          <p className="text-sm text-gray-600 mb-3">Chat with support</p>
          <Badge variant="secondary">Coming Soon</Badge>
        </Card>
        
        <Card className="p-6 text-center">
          <div className="text-3xl mb-3">📚</div>
          <h3 className="font-semibold mb-2">Help Docs</h3>
          <p className="text-sm text-gray-600 mb-3">Browse documentation</p>
          <Button variant="outline" size="sm">View Docs</Button>
        </Card>
      </div>
    </div>
  );
};

export default SupportPage;