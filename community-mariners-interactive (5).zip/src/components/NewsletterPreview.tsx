import React, { useState, useEffect } from 'react';
import { GradientCard, AnimatedBadge, GlowButton } from '@/components/EnhancedVisualComponents';
import { supabase } from '@/lib/supabase';

const NewsletterPreview = () => {
  const [newsletter, setNewsletter] = useState({
    date: new Date().toLocaleDateString(),
    headlines: [
      'Mariners Sweep Series Against Angels',
      'Julio Rodríguez Named Player of the Week',
      'T-Mobile Park Hosting All-Star Game Preview'
    ],
    predictions: {
      weeklyWinner: 'Captain',
      topPredictors: ['MarinersFan2024', 'SeattleSupporter', 'TridentTruth']
    },
    forumHighlights: [
      'Heated debate about playoff chances in Temp Check',
      'Amazing seat photos from Section 149',
      'Trade deadline speculation heating up'
    ],
    upcomingGames: [
      { opponent: 'vs Rangers', date: 'Aug 15', time: '7:10 PM' },
      { opponent: 'vs Astros', date: 'Aug 17', time: '1:10 PM' }
    ]
  });

  const [subscriberCount, setSubscriberCount] = useState(1247);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Newsletter Header */}
      <GradientCard className="p-6" gradient="from-blue-600 to-teal-600 text-white">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">⚾ Mariners Weekly Digest</h1>
          <p className="text-lg opacity-90">{newsletter.date}</p>
          <AnimatedBadge variant="secondary" pulse>
            {subscriberCount.toLocaleString()} Subscribers
          </AnimatedBadge>
        </div>
      </GradientCard>

      {/* Top Headlines */}
      <GradientCard className="p-6" gradient="from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          📰 Top Headlines
        </h2>
        <div className="space-y-3">
          {newsletter.headlines.map((headline, index) => (
            <div key={index} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <span className="text-2xl">🔥</span>
              <span className="font-medium">{headline}</span>
            </div>
          ))}
        </div>
      </GradientCard>

      {/* Prediction Leaderboard */}
      <GradientCard className="p-6" gradient="from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          🏆 Weekly Prediction Champions
        </h2>
        
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              🤖 Bot Winner
            </h3>
            <div className="flex items-center gap-2">
              <span className="text-2xl">⚓</span>
              <span className="font-bold text-lg">{newsletter.predictions.weeklyWinner}</span>
              <AnimatedBadge variant="success">74% Accuracy</AnimatedBadge>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              👥 Top Members
            </h3>
            <div className="space-y-1">
              {newsletter.predictions.topPredictors.map((predictor, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="text-lg">{index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}</span>
                  <span className="font-medium">{predictor}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </GradientCard>

      {/* Forum Highlights */}
      <GradientCard className="p-6" gradient="from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          💬 Forum Buzz
        </h2>
        <div className="space-y-3">
          {newsletter.forumHighlights.map((highlight, index) => (
            <div key={index} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <span className="text-2xl">💭</span>
              <span className="font-medium">{highlight}</span>
            </div>
          ))}
        </div>
      </GradientCard>

      {/* Upcoming Games */}
      <GradientCard className="p-6" gradient="from-indigo-50 to-blue-50 dark:from-indigo-900/20 dark:to-blue-900/20">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          📅 Upcoming Games
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {newsletter.upcomingGames.map((game, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-lg">{game.opponent}</div>
                  <div className="text-gray-600 dark:text-gray-400">{game.date} • {game.time}</div>
                </div>
                <span className="text-3xl">⚾</span>
              </div>
            </div>
          ))}
        </div>
      </GradientCard>

      {/* Newsletter Actions */}
      <GradientCard className="p-6" gradient="from-gray-50 to-slate-50 dark:from-gray-800 dark:to-slate-800">
        <div className="text-center space-y-4">
          <h3 className="text-xl font-bold">Stay Connected</h3>
          <div className="flex justify-center gap-4">
            <GlowButton variant="primary">
              📧 Subscribe
            </GlowButton>
            <GlowButton variant="success">
              📤 Share Newsletter
            </GlowButton>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Get the latest Mariners news, predictions, and forum highlights delivered weekly
          </p>
        </div>
      </GradientCard>
    </div>
  );
};

export default NewsletterPreview;