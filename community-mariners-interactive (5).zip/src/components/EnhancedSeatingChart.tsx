import React, { useState } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import { MapPin, Star, BarChart3, Users } from 'lucide-react';

const EnhancedSeatingChart = () => {
  const [selectedSection, setSelectedSection] = useState('');
  const [pollResults, setPollResults] = useState({
    'Lower Bowl': 342,
    'Club Level': 156,
    'Upper Deck': 89,
    'Outfield Bleachers': 234,
    'Diamond Club': 67,
    'Terrace Club': 123
  });

  const [userVote, setUserVote] = useState('');

  const handleVote = (section: string) => {
    if (!userVote) {
      setPollResults(prev => ({
        ...prev,
        [section]: prev[section] + 1
      }));
      setUserVote(section);
    }
  };

  const totalVotes = Object.values(pollResults).reduce((sum, votes) => sum + votes, 0);

  const getPercentage = (votes: number) => {
    return ((votes / totalVotes) * 100).toFixed(1);
  };

  const sections = [
    { name: 'Lower Bowl', description: 'Close to action, premium view', color: 'bg-green-500' },
    { name: 'Club Level', description: 'Great amenities, covered seating', color: 'bg-blue-500' },
    { name: 'Upper Deck', description: 'Full stadium view, budget-friendly', color: 'bg-purple-500' },
    { name: 'Outfield Bleachers', description: 'Fun atmosphere, home run territory', color: 'bg-orange-500' },
    { name: 'Diamond Club', description: 'Luxury experience, field level', color: 'bg-yellow-500' },
    { name: 'Terrace Club', description: 'Premium dining, great views', color: 'bg-red-500' }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold mb-4">T-Mobile Park Seating</h2>
        
        {/* Stadium Image Placeholder */}
        <Card className="p-8 bg-gradient-to-b from-green-100 to-green-200 dark:from-green-900/20 dark:to-green-800/20">
          <div className="relative mx-auto max-w-2xl">
            <div className="text-6xl mb-4">🏟️</div>
            <div className="text-lg font-semibold text-green-800 dark:text-green-200">
              T-Mobile Park Stadium View
            </div>
            <div className="text-sm text-green-600 dark:text-green-300 mt-2">
              Interactive seating chart showing all sections and views
            </div>
            
            {/* Field representation */}
            <div className="mt-6 relative">
              <div className="w-48 h-32 mx-auto bg-green-400 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">⚾ FIELD ⚾</span>
              </div>
              
              {/* Seating sections around field */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="grid grid-cols-3 gap-2 w-full max-w-md">
                  {sections.slice(0, 6).map((section, index) => (
                    <div
                      key={section.name}
                      className={`${section.color} text-white text-xs p-2 rounded cursor-pointer hover:opacity-80 transition-opacity`}
                      onClick={() => setSelectedSection(section.name)}
                    >
                      {section.name}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Best View Poll */}
      <Card className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="h-6 w-6 text-blue-600" />
          <h3 className="text-xl font-bold">Which section has the best view?</h3>
          <Badge variant="outline">{totalVotes} votes</Badge>
        </div>

        <div className="space-y-3">
          {sections.map(section => (
            <div key={section.name} className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <Button
                    size="sm"
                    onClick={() => handleVote(section.name)}
                    disabled={!!userVote}
                    variant={userVote === section.name ? "default" : "outline"}
                  >
                    {userVote === section.name ? '✓ Voted' : 'Vote'}
                  </Button>
                  <span className="font-medium">{section.name}</span>
                  <span className="text-sm text-gray-600">{section.description}</span>
                </div>
                <div className="text-right">
                  <div className="font-bold">{getPercentage(pollResults[section.name])}%</div>
                  <div className="text-sm text-gray-600">{pollResults[section.name]} votes</div>
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`${section.color} h-2 rounded-full transition-all duration-500`}
                  style={{ width: `${getPercentage(pollResults[section.name])}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {userVote && (
          <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
              <Star className="h-4 w-4" />
              <span className="text-sm">Thanks for voting! You chose: <strong>{userVote}</strong></span>
            </div>
          </div>
        )}
      </Card>

      {/* Section Details */}
      {selectedSection && (
        <Card className="p-6 bg-blue-50 dark:bg-blue-900/20">
          <div className="flex items-center gap-3 mb-3">
            <MapPin className="h-5 w-5 text-blue-600" />
            <h4 className="text-lg font-bold">{selectedSection}</h4>
          </div>
          <p className="text-gray-600 mb-3">
            {sections.find(s => s.name === selectedSection)?.description}
          </p>
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {pollResults[selectedSection]} fans prefer this section
            </span>
            <span className="flex items-center gap-1">
              <Star className="h-4 w-4" />
              {getPercentage(pollResults[selectedSection])}% of total votes
            </span>
          </div>
        </Card>
      )}
    </div>
  );
};

export default EnhancedSeatingChart;