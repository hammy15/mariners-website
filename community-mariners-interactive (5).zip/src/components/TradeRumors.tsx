import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ThumbsUp, ThumbsDown, MessageCircle, TrendingUp } from 'lucide-react';

interface TradeRumor {
  id: string;
  title: string;
  content: string;
  source: string;
  timestamp: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  reliability: number;
  upvotes: number;
  comments: number;
}

const TradeRumors: React.FC = () => {
  const [rumors, setRumors] = useState<TradeRumor[]>([]);
  const [filter, setFilter] = useState<'all' | 'positive' | 'negative'>('all');

  useEffect(() => {
    // Mock trade rumors data
    setRumors([
      {
        id: '1',
        title: 'Mariners eyeing veteran starter for playoff push',
        content: 'Sources suggest Seattle is in talks with multiple teams for rotation help...',
        source: 'MLB Insider',
        timestamp: '2 hours ago',
        sentiment: 'positive',
        reliability: 85,
        upvotes: 42,
        comments: 18
      },
      {
        id: '2',
        title: 'Potential outfield trade could shake up lineup',
        content: 'Reports indicate the M\'s are exploring options to upgrade the corner outfield...',
        source: 'Seattle Sports Radio',
        timestamp: '4 hours ago',
        sentiment: 'neutral',
        reliability: 70,
        upvotes: 28,
        comments: 12
      },
      {
        id: '3',
        title: 'Bullpen reinforcements on Jerry Dipoto\'s radar',
        content: 'With the trade deadline approaching, Seattle looking at late-inning help...',
        source: 'The Athletic',
        timestamp: '6 hours ago',
        sentiment: 'positive',
        reliability: 92,
        upvotes: 67,
        comments: 31
      }
    ]);
  }, []);

  const filteredRumors = rumors.filter(rumor => 
    filter === 'all' || rumor.sentiment === filter
  );

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-green-100 text-green-800';
      case 'negative': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getReliabilityColor = (reliability: number) => {
    if (reliability >= 80) return 'text-green-600';
    if (reliability >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <TrendingUp className="mr-2 h-5 w-5" />
            Trade Rumors Tracker
          </span>
          <div className="flex space-x-1">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'positive' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('positive')}
            >
              Positive
            </Button>
            <Button
              variant={filter === 'negative' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('negative')}
            >
              Negative
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {filteredRumors.map((rumor) => (
            <div key={rumor.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-sm">{rumor.title}</h3>
                <Badge className={getSentimentColor(rumor.sentiment)}>
                  {rumor.sentiment}
                </Badge>
              </div>
              
              <p className="text-sm text-gray-600 mb-3">{rumor.content}</p>
              
              <div className="flex items-center justify-between text-xs text-gray-500">
                <div className="flex items-center space-x-3">
                  <span>{rumor.source}</span>
                  <span>{rumor.timestamp}</span>
                  <span className={`font-semibold ${getReliabilityColor(rumor.reliability)}`}>
                    {rumor.reliability}% reliable
                  </span>
                </div>
                
                <div className="flex items-center space-x-3">
                  <button className="flex items-center space-x-1 hover:text-green-600">
                    <ThumbsUp className="h-3 w-3" />
                    <span>{rumor.upvotes}</span>
                  </button>
                  <button className="flex items-center space-x-1 hover:text-blue-600">
                    <MessageCircle className="h-3 w-3" />
                    <span>{rumor.comments}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TradeRumors;