import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { aiLearning } from '@/lib/aiLearning';
import { BarChart3, TrendingUp, Users, MessageSquare } from 'lucide-react';

interface ConversationAnalyticsProps {
  userId?: string;
}

export function ConversationAnalytics({ userId }: ConversationAnalyticsProps) {
  const analytics = aiLearning.getAnalytics();
  const userPrefs = userId ? aiLearning.getUserPreferences(userId) : null;

  return (
    <div className="space-y-4">
      {/* Overall Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Conversations</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.totalConversations}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.activeUsers}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Most Popular Bot</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold capitalize">{analytics.mostPopularBot}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trending Topics</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-medium">
              {analytics.topTopics[0]?.[0] || 'None yet'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Topic Popularity */}
      <Card>
        <CardHeader>
          <CardTitle>Popular Topics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {analytics.topTopics.slice(0, 8).map(([topic, count]) => (
              <div key={topic} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary" className="capitalize">
                    {topic.replace('-', ' ')}
                  </Badge>
                  <span className="text-sm text-muted-foreground">{count} mentions</span>
                </div>
                <Progress 
                  value={(count / analytics.topTopics[0][1]) * 100} 
                  className="w-20" 
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* User Preferences (if userId provided) */}
      {userPrefs && (
        <Card>
          <CardHeader>
            <CardTitle>Your Conversation Profile</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium mb-2">Favorite Topics</h4>
                <div className="flex flex-wrap gap-1">
                  {userPrefs.favoriteTopics.map(topic => (
                    <Badge key={topic} variant="outline" className="text-xs">
                      {topic.replace('-', ' ')}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Chat Statistics</h4>
                <div className="space-y-1 text-sm">
                  <div>Total Chats: {userPrefs.interactionHistory.totalChats}</div>
                  <div>Favorite Bot: {userPrefs.interactionHistory.favoriteBot}</div>
                  <div>Preferred Tone: {userPrefs.preferredTone}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bot Engagement */}
      <Card>
        <CardHeader>
          <CardTitle>Bot Engagement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Object.entries(analytics.botEngagement).map(([botId, count]) => (
              <div key={botId} className="flex items-center justify-between">
                <div className="capitalize font-medium">{botId}</div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">{count} chats</span>
                  <Progress 
                    value={(count / Math.max(...Object.values(analytics.botEngagement))) * 100} 
                    className="w-24" 
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}