import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Clock, TrendingUp } from 'lucide-react';

interface PredictionOption {
  id: string;
  question: string;
  options: string[];
  memberAvg: number[];
}

interface Game {
  id: string;
  homeTeam: string;
  awayTeam: string;
  startTime: string;
  status: 'upcoming' | 'live' | 'completed';
}

const predictionQuestions: PredictionOption[] = [
  { id: '1', question: 'Who will win?', options: ['Home Team', 'Away Team'], memberAvg: [65, 35] },
  { id: '2', question: 'Total runs scored?', options: ['Under 8.5', 'Over 8.5'], memberAvg: [45, 55] },
  { id: '3', question: 'First inning runs?', options: ['0 runs', '1+ runs'], memberAvg: [60, 40] },
  { id: '4', question: 'Home runs hit?', options: ['0-1', '2-3', '4+'], memberAvg: [30, 50, 20] },
  { id: '5', question: 'Winning margin?', options: ['1 run', '2-3 runs', '4+ runs'], memberAvg: [25, 45, 30] },
  { id: '6', question: 'Strikeouts by starter?', options: ['Under 6.5', 'Over 6.5'], memberAvg: [55, 45] },
  { id: '7', question: 'Extra innings?', options: ['Yes', 'No'], memberAvg: [15, 85] },
  { id: '8', question: 'Double plays?', options: ['0-1', '2+'], memberAvg: [70, 30] },
  { id: '9', question: 'Stolen bases?', options: ['0', '1+'], memberAvg: [60, 40] },
  { id: '10', question: 'Game duration?', options: ['Under 3h', 'Over 3h'], memberAvg: [40, 60] }
];

export const EnhancedGamePredictions: React.FC = () => {
  const [currentGame] = useState<Game>({
    id: '1',
    homeTeam: 'Seattle Mariners',
    awayTeam: 'Houston Astros',
    startTime: '2024-01-15T19:10:00Z',
    status: 'upcoming'
  });

  const [predictions, setPredictions] = useState<Record<string, string>>({});
  const [timeUntilGame, setTimeUntilGame] = useState<number>(0);
  const [canPredict, setCanPredict] = useState(true);

  useEffect(() => {
    const updateTimer = () => {
      const gameTime = new Date(currentGame.startTime).getTime();
      const now = new Date().getTime();
      const timeDiff = gameTime - now;
      const minutesUntil = Math.floor(timeDiff / (1000 * 60));
      
      setTimeUntilGame(minutesUntil);
      setCanPredict(minutesUntil > 30);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 60000);
    return () => clearInterval(interval);
  }, [currentGame.startTime]);

  const handlePrediction = (questionId: string, option: string) => {
    if (!canPredict) return;
    setPredictions(prev => ({ ...prev, [questionId]: option }));
  };

  const getTimeDisplay = () => {
    if (timeUntilGame <= 0) return 'Game Started';
    if (timeUntilGame < 60) return `${timeUntilGame}m until game`;
    const hours = Math.floor(timeUntilGame / 60);
    const minutes = timeUntilGame % 60;
    return `${hours}h ${minutes}m until game`;
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg">Game Predictions</CardTitle>
          <Badge variant={canPredict ? "default" : "secondary"} className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {getTimeDisplay()}
          </Badge>
        </div>
        <div className="text-center py-2">
          <p className="font-semibold">{currentGame.awayTeam} @ {currentGame.homeTeam}</p>
          <p className="text-sm text-gray-600">
            {new Date(currentGame.startTime).toLocaleDateString()} at {new Date(currentGame.startTime).toLocaleTimeString()}
          </p>
        </div>
      </CardHeader>
      
      <CardContent>
        {!canPredict && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4 text-center">
            <p className="text-yellow-800 text-sm">Predictions closed - game starts in less than 30 minutes</p>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {predictionQuestions.map((question) => (
            <div key={question.id} className="border rounded-lg p-3">
              <h4 className="font-medium text-sm mb-2">{question.question}</h4>
              <div className="space-y-2">
                {question.options.map((option, idx) => (
                  <div key={idx}>
                    <Button
                      variant={predictions[question.id] === option ? "default" : "outline"}
                      size="sm"
                      className="w-full justify-between text-xs h-8"
                      onClick={() => handlePrediction(question.id, option)}
                      disabled={!canPredict}
                    >
                      <span>{option}</span>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        <span>{question.memberAvg[idx]}%</span>
                      </div>
                    </Button>
                    <Progress value={question.memberAvg[idx]} className="h-1 mt-1" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        {canPredict && Object.keys(predictions).length > 0 && (
          <div className="mt-4 text-center">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Submit Predictions ({Object.keys(predictions).length}/10)
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};