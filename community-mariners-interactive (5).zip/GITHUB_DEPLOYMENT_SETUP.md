# GitHub Repository Setup for TridentFans

## Step 1: Create GitHub Repository
1. Go to [github.com](https://github.com) and create new repository
2. Name it `tridentfans` or `tridentfans-app`
3. Make it public (required for free Vercel deployment)
4. Don't initialize with README (we have existing code)

## Step 2: Push Your Code
In your local project directory:
```bash
# Initialize git if not already done
git init

# Add GitHub remote
git remote add origin https://github.com/yourusername/tridentfans.git

# Add all files
git add .

# Commit
git commit -m "Initial TridentFans deployment"

# Push to GitHub
git push -u origin main
```

## Step 3: Connect to Vercel
1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import from GitHub
4. Select your `tridentfans` repository
5. Configure as shown in VERCEL_PROJECT_SETUP.md

## Important Files for Deployment
Ensure these files are in your repository:
- `package.json` ✓
- `vite.config.ts` ✓
- `vercel.json` ✓
- `src/` directory with all components ✓
- `public/` directory ✓

## Troubleshooting
- If build fails, check package.json dependencies
- Ensure all import paths use proper aliases (@/)
- Verify environment variables are set in Vercel dashboard