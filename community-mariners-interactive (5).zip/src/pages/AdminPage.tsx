import React, { useState } from 'react';
import { Card, Button, Badge } from '@/components/MinimalComponents';
import AdminBotSettings from '@/components/AdminBotSettings';
import NewsletterManager from '@/components/NewsletterManager';
import BotOnlyLeaderboard from '@/components/BotOnlyLeaderboard';
import ButtonFunctionalityTest from '@/components/ButtonFunctionalityTest';
import ComprehensiveButtonTest from '@/components/ComprehensiveButtonTest';
const AdminPage = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const stats = {
    users: 1247,
    posts: 856,
    predictions: 2341,
    newsletters: 892
  };

  const recentActivity = [
    { id: 1, action: "New user registered", user: "MarinersFan2024", time: "5 min ago" },
    { id: 2, action: "Forum post created", user: "SeattleBaseball", time: "12 min ago" },
    { id: 3, action: "Prediction submitted", user: "TridentPower", time: "18 min ago" }
  ];

  const tabs = [
    { id: 'overview', name: 'Overview' },
    { id: 'bots', name: 'AI Bots' },
    { id: 'bot-leaderboard', name: 'Bot Leaderboard' },
    { id: 'newsletters', name: 'Newsletters' },
    { id: 'users', name: 'Users' },
    { id: 'content', name: 'Content' },
    { id: 'settings', name: 'Settings' },
    { id: 'test', name: 'System Test' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <Badge variant="destructive">Admin Only</Badge>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
        {tabs.map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? "default" : "ghost"}
            onClick={() => setActiveTab(tab.id)}
            className="flex-1"
          >
            {tab.name}
          </Button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.users}</div>
              <div className="text-sm text-gray-600">Total Users</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.posts}</div>
              <div className="text-sm text-gray-600">Forum Posts</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.predictions}</div>
              <div className="text-sm text-gray-600">Predictions</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-teal-600">{stats.newsletters}</div>
              <div className="text-sm text-gray-600">Subscribers</div>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-800 rounded">
                  <div>
                    <span className="font-medium">{activity.action}</span>
                    <span className="text-gray-600 ml-2">by {activity.user}</span>
                  </div>
                  <span className="text-sm text-gray-500">{activity.time}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {activeTab === 'bots' && <AdminBotSettings />}
      
      {activeTab === 'bot-leaderboard' && <BotOnlyLeaderboard />}
      
      {activeTab === 'newsletters' && <NewsletterManager />}

      {activeTab === 'users' && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">User Management</h2>
          <p className="text-gray-600 mb-4">Manage user accounts, permissions, and moderation.</p>
          <div className="space-y-2">
            <Button variant="outline">View All Users</Button>
            <Button variant="outline">Banned Users</Button>
            <Button variant="outline">Moderator Tools</Button>
          </div>
        </Card>
      )}

      {activeTab === 'content' && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Content Management</h2>
          <p className="text-gray-600 mb-4">Manage forum posts, news articles, and site content.</p>
          <div className="space-y-2">
            <Button variant="outline">Moderate Posts</Button>
            <Button variant="outline">Manage News</Button>
            <Button variant="outline">Update Roster</Button>
          </div>
        </Card>
      )}

      {activeTab === 'settings' && (
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">System Settings</h2>
          <p className="text-gray-600 mb-4">Configure site settings and preferences.</p>
          <div className="space-y-2">
            <Button variant="outline">Site Configuration</Button>
            <Button variant="outline">Email Settings</Button>
            <Button variant="outline">API Management</Button>
          </div>
        </Card>
      )}

      {activeTab === 'test' && (
        <div className="space-y-6">
          <ButtonFunctionalityTest />
          <ComprehensiveButtonTest />
        </div>
      )}

      {/* Quick Actions */}
      <Card className="p-6 bg-red-50 dark:bg-red-900/20">
        <h3 className="text-lg font-semibold mb-2">Quick Actions</h3>
        <div className="flex flex-wrap gap-2">
          <Button variant="destructive" size="sm">Emergency Maintenance</Button>
          <Button variant="outline" size="sm">Backup Database</Button>
          <Button variant="outline" size="sm">Clear Cache</Button>
        </div>
      </Card>
    </div>
  );
};

export default AdminPage;